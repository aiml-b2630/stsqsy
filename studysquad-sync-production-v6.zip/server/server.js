import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.js';
import roomRoutes from './routes/rooms.js';
import squadRoutes from './routes/squads.js';
import { startHoldCleanupWorker } from './workers/holdCleanupWorker.js';
import logger from './logger.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/squads', squadRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', service: 'StudySquad Sync API', version: '6.0.0' });
});

// Start background cron worker for hold cleanup
const cleanupInterval = Number(process.env.HOLD_CLEANUP_INTERVAL_MS) || 10000;
startHoldCleanupWorker(cleanupInterval);

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    logger.info(`StudySquad Sync server listening on port ${PORT}`);
  });
}

export default app;
