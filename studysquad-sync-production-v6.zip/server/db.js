import logger from './logger.js';

class MockDB {
  constructor() {
    this.rooms = [
      { id: 1, name: "Library Pod A1", building: "Central Library", floor: "3rd Floor", capacity: 4, occupied_chairs: 1, noise_db: 38, amenities: ["Whiteboard", "Power Sockets", "Silent Zone"], status: "available", version: 1, hold_until: null },
      { id: 2, name: "Eng Discussion Room 102", building: "Engineering Block", floor: "1st Floor", capacity: 6, occupied_chairs: 4, noise_db: 62, amenities: ["Whiteboard", "Dual Monitors", "Group Discussion"], status: "available", version: 1, hold_until: null },
      { id: 3, name: "Silent Study Alcove 3", building: "Central Library", floor: "2nd Floor", capacity: 2, occupied_chairs: 2, noise_db: 32, amenities: ["Power Sockets", "Silent Zone"], status: "occupied", version: 1, hold_until: null },
      { id: 4, name: "Innovation Lab Suite", building: "Student Center", floor: "Ground", capacity: 8, occupied_chairs: 3, noise_db: 58, amenities: ["Whiteboard", "Power Sockets", "Dual Monitors", "Group Discussion"], status: "available", version: 1, hold_until: null },
      { id: 5, name: "Math Finals Cell 5", building: "Science Tower", floor: "4th Floor", capacity: 4, occupied_chairs: 0, noise_db: 35, amenities: ["Whiteboard", "Power Sockets"], status: "available", version: 1, hold_until: null },
      { id: 6, name: "Media Commons Room B", building: "Student Center", floor: "2nd Floor", capacity: 5, occupied_chairs: 1, noise_db: 48, amenities: ["Dual Monitors", "Group Discussion"], status: "available", version: 1, hold_until: null }
    ];

    this.squads = [
      { id: 1, title: "Linear Algebra Exam Prep", subject: "Mathematics", creator: "Alex Chen", max_members: 4, current_members: 3, schedule: "Afternoon", target_goal: "Solve Chapter 5-7 Practice Problems", room_name: "Library Pod A1" },
      { id: 2, title: "Operating Systems Finals Squad", subject: "Computer Science", creator: "Elena Rostova", max_members: 5, current_members: 2, schedule: "Late Night", target_goal: "Concurrency & Process Scheduling", room_name: "Eng Discussion Room 102" },
      { id: 3, title: "GATE Mechanical Revision", subject: "Engineering", creator: "Marcus Vance", max_members: 3, current_members: 2, schedule: "Morning", target_goal: "Thermodynamics Mock Test", room_name: "Silent Study Alcove 3" }
    ];

    this.indexes = ["idx_rooms_status", "idx_rooms_building", "idx_squads_subject", "idx_squad_members_squad_id"];
    logger.info("Database initialized with performance SQL indexes", { indexes: this.indexes });
  }

  getRooms() { return this.rooms; }
  getRoomById(id) { return this.rooms.find(r => r.id === Number(id)); }
  
  reserveRoom(id, currentVersion, holdUntilMs) {
    const room = this.getRoomById(id);
    if (!room) return { success: false, error: "Room not found" };
    if (room.version !== currentVersion) {
      return { success: false, error: "Concurrency conflict: room status was modified by another user." };
    }
    if (room.status !== 'available') {
      return { success: false, error: "Room is not available." };
    }
    room.status = 'reserved';
    room.version += 1;
    room.hold_until = holdUntilMs;
    logger.info("Room reserved successfully with OCC lock", { roomId: id, newVersion: room.version, holdUntil: new Date(holdUntilMs).toISOString() });
    return { success: true, room };
  }

  releaseExpiredHolds() {
    const now = Date.now();
    let releasedCount = 0;
    this.rooms.forEach(r => {
      if (r.status === 'reserved' && r.hold_until && r.hold_until <= now) {
        r.status = 'available';
        r.hold_until = null;
        r.version += 1;
        releasedCount += 1;
        logger.info("Background worker auto-released expired room hold", { roomId: r.id, newVersion: r.version });
      }
    });
    return releasedCount;
  }

  getSquads() { return this.squads; }
  createSquad(squadData) {
    const newSquad = {
      id: this.squads.length + 1,
      current_members: 1,
      ...squadData
    };
    this.squads.push(newSquad);
    logger.info("Squad created successfully", { squadId: newSquad.id, title: newSquad.title });
    return newSquad;
  }
}

export const db = new MockDB();
export default db;
