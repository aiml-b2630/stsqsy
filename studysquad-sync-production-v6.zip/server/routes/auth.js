import express from 'express';
import jwt from 'jsonwebtoken';
import logger from '../logger.js';

const router = express.Router();

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ success: false, error: "Username and password required" });
  }

  const jwtSecret = process.env.JWT_SECRET || 'super_secret_production_key_studysquad_2026_x99!';
  
  const token = jwt.sign(
    { id: 101, username, role: 'student', student_id: 'STUD-2026-99' },
    jwtSecret,
    { expiresIn: '8h' }
  );

  logger.info("User logged in successfully", { username });
  res.json({
    success: true,
    token,
    user: { id: 101, username, role: 'student', student_id: 'STUD-2026-99' }
  });
});

export default router;
