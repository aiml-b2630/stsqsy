import jwt from 'jsonwebtoken';
import logger from '../logger.js';

export function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    logger.warn("Authentication failed: No token provided", { path: req.path });
    return res.status(401).json({ success: false, error: "Access denied. Authentication token required." });
  }

  const jwtSecret = process.env.JWT_SECRET;
  if (!jwtSecret) {
    logger.error("CRITICAL SECURITY ERROR: JWT_SECRET environment variable is missing!");
    return res.status(500).json({ success: false, error: "Server security misconfiguration." });
  }

  try {
    const decoded = jwt.verify(token, jwtSecret);
    req.user = decoded;
    next();
  } catch (err) {
    logger.warn("Invalid or expired JWT token", { error: err.message });
    return res.status(403).json({ success: false, error: "Invalid or expired session token." });
  }
}
