# StudySquad Sync — v6.0.0 (Production Release)

StudySquad Sync is a 3-Tier Student & Campus Life smart study platform addressing library room crowding and study squad partner matching.

## Key Features & Upgrades in v6.0.0:
- **3-Tier Architecture**: Express REST backend + SQLite3 relational database + React 18 frontend.
- **Background Auto-Release Worker**: Server-side cron worker (`server/workers/holdCleanupWorker.js`) automatically clearing expired 20-minute holds in SQLite.
- **Strict Cryptographic Auth**: HMAC-SHA256 JWT auth with strictly enforced environment secret validation (`process.env.JWT_SECRET`).
- **Database Indexing & Optimistic Concurrency**: SQL indexes on `status`, `building`, `subject`, and version column concurrency locking for reservations.
- **IoT Telemetry Simulation**: Real-world PIR motion sensor and decibel noise meter simulation (30–75 dB).
- **Heuristic Squad Matcher**: Weighted Jaccard similarity vector & multi-dimensional schedule matrix pairing engine.
- **Testing Suite**: Unit tests with Vitest + Full API integration tests with Supertest.
