import React, { createContext, useContext, useState } from 'react';
import { useIoTSensorSim } from '../hooks/useIoTSensorSim';

const SquadContext = createContext();

export function SquadProvider({ children }) {
  const [rooms, setRooms] = useState([
    { id: 1, name: "Library Pod A1", building: "Central Library", floor: "3rd Floor", capacity: 4, occupied_chairs: 1, noise_db: 38, amenities: ["Whiteboard", "Power Sockets", "Silent Zone"], status: "available", version: 1, hold_until: null },
    { id: 2, name: "Eng Discussion Room 102", building: "Engineering Block", floor: "1st Floor", capacity: 6, occupied_chairs: 4, noise_db: 62, amenities: ["Whiteboard", "Dual Monitors", "Group Discussion"], status: "available", version: 1, hold_until: null },
    { id: 3, name: "Silent Study Alcove 3", building: "Central Library", floor: "2nd Floor", capacity: 2, occupied_chairs: 2, noise_db: 32, amenities: ["Power Sockets", "Silent Zone"], status: "occupied", version: 1, hold_until: null },
    { id: 4, name: "Innovation Lab Suite", building: "Student Center", floor: "Ground", capacity: 8, occupied_chairs: 3, noise_db: 58, amenities: ["Whiteboard", "Power Sockets", "Dual Monitors", "Group Discussion"], status: "available", version: 1, hold_until: null }
  ]);

  const [squads, setSquads] = useState([
    { id: 1, title: "Linear Algebra Exam Prep", subject: "Mathematics", creator: "Alex Chen", max_members: 4, current_members: 3, schedule: "Afternoon", target_goal: "Solve Chapter 5-7 Practice Problems", room_name: "Library Pod A1" },
    { id: 2, title: "Operating Systems Finals Squad", subject: "Computer Science", creator: "Elena Rostova", max_members: 5, current_members: 2, schedule: "Late Night", target_goal: "Concurrency & Process Scheduling", room_name: "Eng Discussion Room 102" }
  ]);

  const [activeHold, setActiveHold] = useState(null);

  useIoTSensorSim(rooms, setRooms);

  const reserveRoomHold = (roomId, durationMin = 20) => {
    const targetRoom = rooms.find(r => r.id === roomId);
    if (!targetRoom || targetRoom.status !== 'available') return false;

    const holdUntil = Date.now() + (durationMin * 60 * 1000);
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, status: 'reserved', hold_until: holdUntil, version: r.version + 1 } : r));
    setActiveHold({ roomId, roomName: targetRoom.name, holdUntil });
    return true;
  };

  const releaseHold = (roomId) => {
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, status: 'available', hold_until: null, version: r.version + 1 } : r));
    setActiveHold(null);
  };

  const createSquad = (squadData) => {
    const newSquad = { id: squads.length + 1, current_members: 1, ...squadData };
    setSquads(prev => [newSquad, ...prev]);
    return newSquad;
  };

  return (
    <SquadContext.Provider value={{ rooms, squads, activeHold, reserveRoomHold, releaseHold, createSquad }}>
      {children}
    </SquadContext.Provider>
  );
}

export const useSquad = () => useContext(SquadContext);
