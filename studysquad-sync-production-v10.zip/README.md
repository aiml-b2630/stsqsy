# StudySquad Sync (v10.0.0 Production Release)

StudySquad Sync is a 3-tier campus productivity platform featuring real-time room occupancy visualization, 20-minute temporary room holds, an automated peer study squad matching engine, and synchronized focus workspaces.

## Key Features & Architectural Highlights
- **Persistent SQLite3 Database**: Built with `better-sqlite3`, explicit performance indexes (`idx_rooms_status`, `idx_rooms_building`, `idx_squads_subject`), foreign keys, and Optimistic Concurrency Control (`version` column).
- **Creator-Based Authorization Levels**: Resource authorization middleware enforcing that only squad/hold creators can release, edit, or terminate their bookings (`403 Forbidden` protection).
- **5-Factor Weighted Matching Heuristics**: Jaccard subject vector similarity, schedule time-block compatibility, amenity scoring, study streaks, and peer ratings.
- **Node.js Resource Lifecycle Worker**: Automated 20-minute hold expiration worker (`holdCleanupWorker.js`).
- **Real-Time Telemetry Stream**: Server-Sent Events (SSE) broadcasting live PIR sensor occupancy and decibel noise fluctuations (30–75 dB).
- **CI/CD Pipeline**: GitHub Actions workflow (`.github/workflows/ci.yml`) for automated linting, testing, and production builds.

## Setup & Execution
1. Install dependencies: `npm install`
2. Start server & client: `npm run server` / `npm run dev`
3. Execute test suite: `npm test`
