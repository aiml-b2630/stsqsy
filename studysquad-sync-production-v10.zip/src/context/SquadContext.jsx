import React, { createContext, useState } from 'react';

export const SquadContext = createContext();

export function SquadProvider({ children }) {
  const [activeHoldRoom, setActiveHoldRoom] = useState(null);
  const [joinedSquad, setJoinedSquad] = useState(null);
  const [toastMessage, setToastMessage] = useState(null);

  const showToast = (msg, type = 'info') => {
    setToastMessage({ msg, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  return (
    <SquadContext.Provider value={{ activeHoldRoom, setActiveHoldRoom, joinedSquad, setJoinedSquad, toastMessage, showToast }}>
      {children}
    </SquadContext.Provider>
  );
}
