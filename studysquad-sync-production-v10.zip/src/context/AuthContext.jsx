import React, { createContext, useState, useEffect } from 'react';

export const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('studysquad_jwt') || '');

  useEffect(() => {
    if (token) {
      setUser({ id: 'u_student', name: 'Alex Student', role: 'student' });
    }
  }, [token]);

  const loginUser = (userToken, userData) => {
    localStorage.setItem('studysquad_jwt', userToken);
    setToken(userToken);
    setUser(userData);
  };

  const logoutUser = () => {
    localStorage.removeItem('studysquad_jwt');
    setToken('');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, loginUser, logoutUser }}>
      {children}
    </AuthContext.Provider>
  );
}
