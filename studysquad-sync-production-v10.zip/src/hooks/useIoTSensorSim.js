import { useState, useEffect } from 'react';

export function useIoTSensorSim(initialRooms = []) {
  const [rooms, setRooms] = useState(initialRooms);

  useEffect(() => {
    setRooms(initialRooms);
  }, [initialRooms]);

  useEffect(() => {
    const interval = setInterval(() => {
      setRooms(prevRooms =>
        prevRooms.map(room => {
          if (room.status !== 'Available') return room;
          const noiseDelta = Math.floor(Math.random() * 7) - 3;
          const newNoise = Math.max(30, Math.min(75, room.noise_db + noiseDelta));
          return { ...room, noise_db: newNoise };
        })
      );
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  return rooms;
}
