import React from 'react';
import { Users, Clock, Award, Star, ArrowRight } from 'lucide-react';

export function SquadCard({ squad, matchScore, onJoin }) {
  return (
    <div className="squad-card">
      <div className="squad-card-header">
        <div>
          <h3>{squad.name}</h3>
          <span className="subject-badge">{squad.subject}</span>
        </div>
        {matchScore && (
          <div className="match-score-pill">
            <Star size={14} /> {matchScore}% Match
          </div>
        )}
      </div>

      <div className="squad-card-body">
        <p className="topic-text"><strong>Topic:</strong> {squad.topic}</p>
        <div className="squad-meta-row">
          <span><Clock size={14} /> {squad.schedule}</span>
          <span><Users size={14} /> {squad.members ? squad.members.length : 1}/{squad.max_members} Members</span>
        </div>

        <div className="streak-row">
          <span><Award size={14} /> {squad.streak || 1} Day Streak</span>
          <span>★ {squad.rating || 4.8} Peer Rating</span>
        </div>
      </div>

      <div className="squad-card-footer">
        <button className="join-squad-btn" onClick={() => onJoin(squad)}>
          Join Squad <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
}
