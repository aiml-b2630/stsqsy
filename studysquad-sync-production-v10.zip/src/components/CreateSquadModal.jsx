import React, { useState } from 'react';
import { validateSquadForm } from '../utils/validation';
import { PlusCircle, XCircle } from 'lucide-react';

export function CreateSquadModal({ onClose, onSubmit }) {
  const [formData, setFormData] = useState({ name: '', subject: '', topic: '', schedule: 'Afternoon', maxMembers: 4 });
  const [errors, setErrors] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();
    const validation = validateSquadForm(formData);
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }
    onSubmit(formData);
  };

  return (
    <div className="modal-overlay">
      <div className="modal-card">
        <div className="modal-header">
          <PlusCircle size={22} />
          <h2>Launch Study Squad</h2>
        </div>

        <form onSubmit={handleSubmit} className="modal-form">
          <div className="form-group">
            <label>Squad Title:</label>
            <input 
              type="text" 
              value={formData.name} 
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. OS Finals Exam Group"
            />
            {errors.name && <span className="error-text">{errors.name}</span>}
          </div>

          <div className="form-group">
            <label>Subject:</label>
            <input 
              type="text" 
              value={formData.subject} 
              onChange={e => setFormData({ ...formData, subject: e.target.value })}
              placeholder="e.g. Computer Science"
            />
            {errors.subject && <span className="error-text">{errors.subject}</span>}
          </div>

          <div className="form-group">
            <label>Session Target Goal / Topic:</label>
            <input 
              type="text" 
              value={formData.topic} 
              onChange={e => setFormData({ ...formData, topic: e.target.value })}
              placeholder="e.g. Process Locks & Threading"
            />
            {errors.topic && <span className="error-text">{errors.topic}</span>}
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Schedule Block:</label>
              <select value={formData.schedule} onChange={e => setFormData({ ...formData, schedule: e.target.value })}>
                <option value="Morning">Morning</option>
                <option value="Afternoon">Afternoon</option>
                <option value="Late Night">Late Night</option>
              </select>
            </div>

            <div className="form-group">
              <label>Max Capacity:</label>
              <input 
                type="number" 
                value={formData.maxMembers} 
                onChange={e => setFormData({ ...formData, maxMembers: Number(e.target.value) })}
                min="2" max="10"
              />
            </div>
          </div>

          <div className="modal-footer">
            <button type="submit" className="confirm-btn">Create Squad</button>
            <button type="button" className="cancel-btn" onClick={onClose}><XCircle size={16} /> Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
