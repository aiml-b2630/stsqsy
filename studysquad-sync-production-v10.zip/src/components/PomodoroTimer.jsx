import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

export function PomodoroTimer() {
  const [seconds, setSeconds] = useState(1500); // 25 mins
  const [isActive, setIsActive] = useState(false);
  const [isBreak, setIsBreak] = useState(false);

  useEffect(() => {
    let interval = null;
    if (isActive && seconds > 0) {
      interval = setInterval(() => setSeconds(s => s - 1), 1000);
    } else if (seconds === 0) {
      if (!isBreak) {
        alert('Focus Session Complete! 5-Minute Break Started.');
        setIsBreak(true);
        setSeconds(300);
      } else {
        alert('Break Complete! Back to Focus.');
        setIsBreak(false);
        setSeconds(1500);
      }
    }
    return () => clearInterval(interval);
  }, [isActive, seconds, isBreak]);

  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  const display = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

  return (
    <div className="pomodoro-card">
      <h4>{isBreak ? '☕ Squad Break Time' : '🎯 Synchronized Focus Timer'}</h4>
      <div className="pomodoro-digits">{display}</div>
      <div className="pomodoro-controls">
        <button onClick={() => setIsActive(!isActive)} className="pomo-btn">
          {isActive ? <Pause size={16} /> : <Play size={16} />}
        </button>
        <button onClick={() => { setIsActive(false); setSeconds(1500); setIsBreak(false); }} className="pomo-btn secondary">
          <RotateCcw size={16} />
        </button>
      </div>
    </div>
  );
}
