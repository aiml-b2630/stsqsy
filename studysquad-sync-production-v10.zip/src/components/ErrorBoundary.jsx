import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('State corruption intercepted:', error, errorInfo);
  }

  handleReset = () => {
    localStorage.clear();
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="error-boundary-card">
          <AlertTriangle size={48} className="error-icon" />
          <h2>Application State Exception</h2>
          <p>An unexpected corrupted state was intercepted by the Error Boundary framework.</p>
          <button onClick={this.handleReset} className="reset-btn">
            <RefreshCw size={16} /> Reset Local Storage & Reload
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
