import React from 'react';
import { MapPin, Clock, Users, ShieldCheck } from 'lucide-react';

export function HowItWorks() {
  return (
    <div className="how-it-works-view">
      <h2>How StudySquad Sync Works</h2>
      <p className="subtitle">Eliminating wasted campus study hours through real-time telemetry and peer matching.</p>

      <div className="steps-grid">
        <div className="step-card">
          <MapPin size={32} className="step-icon" />
          <h3>1. RoomRadar Grid</h3>
          <p>Explore real-time occupancy, noise decibel telemetry (30–75 dB), and facility amenities across 12 campus study spaces.</p>
        </div>

        <div className="step-card">
          <Clock size={32} className="step-icon" />
          <h3>2. 20-Min Space Hold</h3>
          <p>Lock a temporary desk hold while walking across campus. Ghost bookings auto-release if unconfirmed within 20 minutes.</p>
        </div>

        <div className="step-card">
          <Users size={32} className="step-icon" />
          <h3>3. Squad Matcher</h3>
          <p>Match with compatible peers using our 5-factor weighted Jaccard similarity engine for shared subjects and schedules.</p>
        </div>

        <div className="step-card">
          <ShieldCheck size={32} className="step-icon" />
          <h3>4. Focus Workspace</h3>
          <p>Execute structured study sessions using a synchronized Pomodoro timer, goal checklists, and study streak badges.</p>
        </div>
      </div>
    </div>
  );
}
