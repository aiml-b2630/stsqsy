import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { BookOpen, MapPin, Users, Clock, ShieldCheck, Sun, Moon } from 'lucide-react';

export function Header({ activeTab, setActiveTab, isDark, setIsDark }) {
  const { user, token, logoutUser } = useContext(AuthContext);

  return (
    <header className="header-bar">
      <div className="header-content">
        <div className="logo-group" onClick={() => setActiveTab('radar')}>
          <BookOpen className="logo-icon" />
          <span className="logo-text">StudySquad <span className="logo-badge">Sync</span></span>
        </div>

        <nav className="nav-links">
          <button className={`nav-btn ${activeTab === 'radar' ? 'active' : ''}`} onClick={() => setActiveTab('radar')}>
            <MapPin className="nav-icon" /> RoomRadar
          </button>

          <button className={`nav-btn ${activeTab === 'matcher' ? 'active' : ''}`} onClick={() => setActiveTab('matcher')}>
            <Users className="nav-icon" /> Squad Matcher
          </button>

          <button className={`nav-btn ${activeTab === 'workspace' ? 'active' : ''}`} onClick={() => setActiveTab('workspace')}>
            <Clock className="nav-icon" /> Focus Workspace
          </button>

          <button className={`nav-btn ${activeTab === 'how' ? 'active' : ''}`} onClick={() => setActiveTab('how')}>
            How It Works
          </button>
        </nav>

        <div className="header-actions">
          <button className="theme-toggle" onClick={() => setIsDark(!isDark)}>
            {isDark ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          {user ? (
            <div className="user-profile">
              <ShieldCheck size={16} className="user-icon" />
              <span>{user.name}</span>
              <button className="logout-btn" onClick={logoutUser}>Logout</button>
            </div>
          ) : (
            <span className="guest-badge">Demo Guest</span>
          )}
        </div>
      </div>
    </header>
  );
}
