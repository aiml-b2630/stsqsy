import React, { useState } from 'react';
import { SquadCard } from './SquadCard';
import { calculateSquadMatchScore } from '../utils/matchingEngine';
import { Users, PlusCircle, Search } from 'lucide-react';

export function SquadMatcher({ squads, onJoinSquad, onCreateTrigger }) {
  const [userPref, setUserPref] = useState({ subject: 'Mathematics', schedule: 'Afternoon', amenity: 'Whiteboard' });

  const matchedSquads = squads.map(squad => ({
    ...squad,
    matchScore: calculateSquadMatchScore(userPref, squad)
  })).sort((a, b) => b.matchScore - a.matchScore);

  return (
    <div className="squad-matcher-view">
      <div className="matcher-header">
        <div>
          <h2><Users size={22} /> Subject Study Squad Matcher</h2>
          <p>Find peer study groups based on subject topics and matching schedule blocks.</p>
        </div>

        <button className="create-squad-btn" onClick={onCreateTrigger}>
          <PlusCircle size={18} /> Launch New Squad
        </button>
      </div>

      <div className="preference-bar">
        <div className="pref-group">
          <label>Your Study Subject:</label>
          <input 
            type="text" 
            value={userPref.subject} 
            onChange={(e) => setUserPref({ ...userPref, subject: e.target.value })}
            placeholder="e.g. Mathematics, Computer Science"
          />
        </div>

        <div className="pref-group">
          <label>Schedule Block:</label>
          <select value={userPref.schedule} onChange={(e) => setUserPref({ ...userPref, schedule: e.target.value })}>
            <option value="Morning">Morning (8 AM - 12 PM)</option>
            <option value="Afternoon">Afternoon (12 PM - 5 PM)</option>
            <option value="Late Night">Late Night (8 PM - Midnight)</option>
          </select>
        </div>
      </div>

      <div className="squads-grid">
        {matchedSquads.map(squad => (
          <SquadCard key={squad.id} squad={squad} matchScore={squad.matchScore} onJoin={onJoinSquad} />
        ))}
      </div>
    </div>
  );
}
