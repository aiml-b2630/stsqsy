import React, { useContext } from 'react';
import { SquadContext } from '../context/SquadContext';
import { PomodoroTimer } from './PomodoroTimer';
import { StreakTracker } from './StreakTracker';
import { Users, CheckSquare, Clock, MapPin } from 'lucide-react';

export function SquadWorkspace() {
  const { joinedSquad } = useContext(SquadContext);

  const squad = joinedSquad || {
    name: 'Linear Algebra Finals Group',
    subject: 'Mathematics',
    topic: 'Eigenvalues & Matrix Transformations',
    schedule: 'Afternoon (2:00 PM - 4:30 PM)',
    room_id: 'Central Library Pod #3',
    members: ['Alex Student', 'Devon Miller', 'Priya Sharma']
  };

  return (
    <div className="squad-workspace-view">
      <div className="workspace-header">
        <div>
          <h2><Clock size={22} /> Synchronized Focus Workspace</h2>
          <p>Group study dashboard with member roster, focus timer, and session goals.</p>
        </div>

        <div className="active-squad-badge">
          <span>Active Squad: <strong>{squad.name}</strong></span>
        </div>
      </div>

      <div className="workspace-grid">
        <div className="workspace-main">
          <div className="info-card">
            <h3>Session Focus Agenda</h3>
            <p className="topic-highlight"><strong>Topic:</strong> {squad.topic}</p>
            <div className="meta-list">
              <span><MapPin size={16} /> Meeting Location: {squad.room_id}</span>
              <span><Clock size={16} /> Schedule: {squad.schedule}</span>
            </div>
          </div>

          <div className="checklist-card">
            <h3><CheckSquare size={18} /> Session Target Checklist</h3>
            <ul className="goal-list">
              <li><input type="checkbox" defaultChecked /> Review Chapter 4 Lecture Notes</li>
              <li><input type="checkbox" defaultChecked /> Solve Problem Set #3 Matrix Transformations</li>
              <li><input type="checkbox" /> Practice Past Exam Questions</li>
            </ul>
          </div>
        </div>

        <div className="workspace-sidebar">
          <PomodoroTimer />
          <StreakTracker streakDays={5} />

          <div className="roster-card">
            <h4><Users size={18} /> Member Roster</h4>
            <ul className="member-list">
              {squad.members.map((member, idx) => (
                <li key={idx}>
                  <span className="user-avatar">👤</span>
                  <span>{typeof member === 'string' ? member : `Member #${idx+1}`}</span>
                  {idx === 0 && <span className="leader-tag">Leader</span>}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
