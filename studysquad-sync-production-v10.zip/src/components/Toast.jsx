import React, { useContext } from 'react';
import { SquadContext } from '../context/SquadContext';
import { Info, AlertTriangle, CheckCircle } from 'lucide-react';

export function Toast() {
  const { toastMessage } = useContext(SquadContext);
  if (!toastMessage) return null;

  return (
    <div className={`toast-notification ${toastMessage.type}`}>
      {toastMessage.type === 'warning' ? <AlertTriangle size={18} /> : <CheckCircle size={18} />}
      <span>{toastMessage.msg}</span>
    </div>
  );
}
