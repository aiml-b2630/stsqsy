import React, { useContext } from 'react';
import { SquadContext } from '../context/SquadContext';
import { MapPin, Users, Volume2, ShieldCheck, Clock } from 'lucide-react';

export function RoomCard({ room, onHoldTrigger }) {
  const { activeHoldRoom } = useContext(SquadContext);

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Available': return <span className="status-badge available">● Available</span>;
      case 'Reserved': return <span className="status-badge reserved">⏳ 20-Min Hold</span>;
      case 'Occupied': return <span className="status-badge occupied">■ Occupied</span>;
      default: return null;
    }
  };

  return (
    <div className={`room-card ${room.status.toLowerCase()}`}>
      <div className="card-header">
        <div>
          <h3>{room.name}</h3>
          <p className="building-text"><MapPin size={14} /> {room.building}</p>
        </div>
        {getStatusBadge(room.status)}
      </div>

      <div className="card-body">
        <div className="telemetry-row">
          <span><Users size={16} /> Capacity: {room.occupied}/{room.capacity} seats</span>
          <span className="noise-meter"><Volume2 size={16} /> {room.noise_db} dB</span>
        </div>

        <div className="amenities-tags">
          {room.amenities.split(',').map((amenity, idx) => (
            <span key={idx} className="tag">{amenity.trim()}</span>
          ))}
        </div>
      </div>

      <div className="card-footer">
        {room.status === 'Available' && (
          <button className="hold-action-btn" onClick={() => onHoldTrigger(room)}>
            <Clock size={16} /> Hold Desk (20 Mins)
          </button>
        )}
        {room.status === 'Reserved' && (
          <span className="holding-label"><ShieldCheck size={14} /> Hold Reserved</span>
        )}
        {room.status === 'Occupied' && (
          <button className="disabled-btn" disabled>Full Capacity</button>
        )}
      </div>
    </div>
  );
}
