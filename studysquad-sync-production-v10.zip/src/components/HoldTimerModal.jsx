import React, { useContext } from 'react';
import { useHoldTimer } from '../hooks/useHoldTimer';
import { SquadContext } from '../context/SquadContext';
import { Clock, CheckCircle2, XCircle } from 'lucide-react';

export function HoldTimerModal({ room, onClose, onConfirmArrival }) {
  const { showToast } = useContext(SquadContext);
  const { formattedTime } = useHoldTimer(1200, () => {
    showToast('20-Minute Hold Expired. Room released back to public status.', 'warning');
    onClose();
  });

  return (
    <div className="modal-overlay">
      <div className="modal-card">
        <div className="modal-header">
          <Clock className="timer-icon pulse" />
          <h2>Temporary Space Hold</h2>
        </div>

        <div className="modal-body">
          <p>You have an active 20-minute reservation for:</p>
          <div className="room-summary">
            <h3>{room.name}</h3>
            <p>{room.building}</p>
          </div>

          <div className="countdown-display">
            <span className="time-digits">{formattedTime}</span>
            <span className="timer-subtext">Remaining to confirm physical arrival</span>
          </div>
        </div>

        <div className="modal-footer">
          <button className="confirm-btn" onClick={() => onConfirmArrival(room)}>
            <CheckCircle2 size={18} /> Confirm Campus Arrival
          </button>
          <button className="cancel-btn" onClick={onClose}>
            <XCircle size={18} /> Release Hold
          </button>
        </div>
      </div>
    </div>
  );
}
