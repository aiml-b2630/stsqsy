import React from 'react';
import { Award, Flame } from 'lucide-react';

export function StreakTracker({ streakDays = 5 }) {
  return (
    <div className="streak-card">
      <div className="streak-header">
        <Flame className="flame-icon" />
        <div>
          <h4>Study Streak</h4>
          <span className="streak-count">{streakDays} Consecutive Days</span>
        </div>
      </div>
      <p className="streak-desc">Daily badge awarded for completing scheduled group sessions together.</p>
    </div>
  );
}
