import React, { useState } from 'react';
import { RoomCard } from './RoomCard';
import { HoldTimerModal } from './HoldTimerModal';
import { useIoTSensorSim } from '../hooks/useIoTSensorSim';
import { Filter, Search } from 'lucide-react';

export function RoomVisualizer({ initialRooms }) {
  const rooms = useIoTSensorSim(initialRooms);
  const [selectedAmenity, setSelectedAmenity] = useState('All');
  const [activeModalRoom, setActiveModalRoom] = useState(null);

  const filteredRooms = rooms.filter(room => {
    if (selectedAmenity === 'All') return true;
    return room.amenities.includes(selectedAmenity);
  });

  return (
    <div className="room-visualizer-view">
      <div className="view-toolbar">
        <h2><Filter size={20} /> Campus Room Occupancy Radar</h2>
        
        <div className="filter-controls">
          <label>Filter Amenity:</label>
          <select value={selectedAmenity} onChange={(e) => setSelectedAmenity(e.target.value)}>
            <option value="All">All Amenities</option>
            <option value="Whiteboard">Whiteboard</option>
            <option value="Silent Zone">Silent Zone</option>
            <option value="Dual Monitors">Dual Monitors</option>
            <option value="Power Sockets">Power Sockets</option>
          </select>
        </div>
      </div>

      <div className="room-grid">
        {filteredRooms.map(room => (
          <RoomCard key={room.id} room={room} onHoldTrigger={setActiveModalRoom} />
        ))}
      </div>

      {activeModalRoom && (
        <HoldTimerModal 
          room={activeModalRoom}
          onClose={() => setActiveModalRoom(null)}
          onConfirmArrival={(r) => {
            alert(`Arrival confirmed at ${r.name}! Space locked.`);
            setActiveModalRoom(null);
          }}
        />
      )}
    </div>
  );
}
