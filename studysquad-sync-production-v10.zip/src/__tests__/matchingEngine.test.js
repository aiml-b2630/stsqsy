import { describe, it, expect } from 'vitest';
import { calculateJaccardIndex, calculateSquadMatchScore } from '../utils/matchingEngine';

describe('StudySquad Matching Engine', () => {
  it('calculateJaccardIndex should compute set intersection over union correctly', () => {
    const tokensA = ['Linear', 'Algebra', 'Finals'];
    const tokensB = ['Linear', 'Algebra', 'Homework'];
    const index = calculateJaccardIndex(tokensA, tokensB);
    expect(index).toBeCloseTo(0.5);
  });

  it('calculateSquadMatchScore should evaluate 5-factor weighted score correctly', () => {
    const userPref = { subject: 'Mathematics', schedule: 'Afternoon', amenity: 'Whiteboard' };
    const squad = { subject: 'Mathematics', schedule: 'Afternoon', amenities: 'Whiteboard, Quiet Zone', streak: 5, rating: 4.8 };
    
    const score = calculateSquadMatchScore(userPref, squad);
    expect(score).toBeGreaterThan(70);
  });
});
