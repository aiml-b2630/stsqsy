export function sanitizeString(str) {
  if (typeof str !== 'string') return '';
  return str.replace(/[<>]/g, '').trim();
}

export function validateSquadForm(data) {
  const errors = {};
  if (!data.name || data.name.trim().length < 3) {
    errors.name = 'Squad name must be at least 3 characters.';
  }
  if (!data.subject || data.subject.trim().length === 0) {
    errors.subject = 'Subject selection is required.';
  }
  if (!data.topic || data.topic.trim().length === 0) {
    errors.topic = 'Study topic focus is required.';
  }
  return { isValid: Object.keys(errors).length === 0, errors };
}
