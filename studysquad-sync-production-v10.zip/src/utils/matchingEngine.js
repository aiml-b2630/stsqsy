export function calculateJaccardIndex(tokensA, tokensB) {
  const setA = new Set(tokensA.map(t => t.toLowerCase()));
  const setB = new Set(tokensB.map(t => t.toLowerCase()));
  const intersection = new Set([...setA].filter(x => setB.has(x)));
  const union = new Set([...setA, ...setB]);
  return union.size === 0 ? 0 : intersection.size / union.size;
}

export function calculateSquadMatchScore(userPref, squad) {
  let score = 0;
  
  // 1. Schedule compatibility (35%)
  if (userPref.schedule === squad.schedule) score += 0.35;
  
  // 2. Subject similarity Jaccard index (30%)
  const userTokens = userPref.subject.split(/\s+/);
  const squadTokens = squad.subject.split(/\s+/);
  score += calculateJaccardIndex(userTokens, squadTokens) * 0.30;
  
  // 3. Amenity match (15%)
  if (userPref.amenity && squad.amenities && squad.amenities.includes(userPref.amenity)) {
    score += 0.15;
  }
  
  // 4. Study streak weight (10%)
  const streakWeight = Math.min((squad.streak || 1) / 10, 1) * 0.10;
  score += streakWeight;
  
  // 5. Peer rating weight (10%)
  const ratingWeight = ((squad.rating || 4.5) / 5.0) * 0.10;
  score += ratingWeight;

  return Math.round(score * 100);
}
