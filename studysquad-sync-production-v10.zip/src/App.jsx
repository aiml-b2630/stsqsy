import React, { useState, useEffect, useContext } from 'react';
import { Header } from './components/Header';
import { RoomVisualizer } from './components/RoomVisualizer';
import { SquadMatcher } from './components/SquadMatcher';
import { CreateSquadModal } from './components/CreateSquadModal';
import { SquadWorkspace } from './components/SquadWorkspace';
import { HowItWorks } from './components/HowItWorks';
import { Toast } from './components/Toast';
import { ErrorBoundary } from './components/ErrorBoundary';
import { SquadContext } from './context/SquadContext';
import { apiFetch } from './utils/api';

export function App() {
  const [activeTab, setActiveTab] = useState('radar');
  const [isDark, setIsDark] = useState(true);
  const [rooms, setRooms] = useState([]);
  const [squads, setSquads] = useState([]);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const { setJoinedSquad, showToast } = useContext(SquadContext);

  useEffect(() => {
    // Fetch initial datasets
    apiFetch('/rooms').then(setRooms).catch(() => {
      setRooms([
        { id: 'r1', name: 'Lib Pod #3 (Silent)', building: 'Central Library', capacity: 4, occupied: 1, noise_db: 35, amenities: 'Whiteboard, Power Sockets, Silent Zone', status: 'Available' },
        { id: 'r2', name: 'Eng Discussion Room A', building: 'Engineering Block', capacity: 6, occupied: 4, noise_db: 52, amenities: 'Whiteboard, Dual Monitors, Power Sockets', status: 'Available' }
      ]);
    });

    apiFetch('/squads').then(setSquads).catch(() => {
      setSquads([
        { id: 's1', name: 'Linear Algebra Finals Group', subject: 'Mathematics', topic: 'Eigenvalues & Transformations', schedule: 'Afternoon', max_members: 4, streak: 5, rating: 4.9 },
        { id: 's2', name: 'OS Kernel Hackers', subject: 'Computer Science', topic: 'Process Concurrency', schedule: 'Late Night', max_members: 6, streak: 8, rating: 5.0 }
      ]);
    });
  }, []);

  const handleCreateSquad = async (formData) => {
    try {
      const newSquad = await apiFetch('/squads', { method: 'POST', body: JSON.stringify({ ...formData, roomId: 'r1' }) });
      setSquads([...squads, newSquad]);
      setJoinedSquad(newSquad);
      setIsCreateModalOpen(false);
      showToast(`Squad "${newSquad.name}" created successfully!`, 'success');
      setActiveTab('workspace');
    } catch (err) {
      showToast(err.message || 'Failed to create squad', 'warning');
    }
  };

  const handleJoinSquad = (squad) => {
    setJoinedSquad(squad);
    showToast(`Joined squad "${squad.name}"! Workspace ready.`, 'success');
    setActiveTab('workspace');
  };

  return (
    <div className={`app-container ${isDark ? 'dark-theme' : 'light-theme'}`}>
      <ErrorBoundary>
        <Header activeTab={activeTab} setActiveTab={setActiveTab} isDark={isDark} setIsDark={setIsDark} />
        <Toast />

        <main className="main-content">
          {activeTab === 'radar' && <RoomVisualizer initialRooms={rooms} />}
          {activeTab === 'matcher' && (
            <SquadMatcher 
              squads={squads} 
              onJoinSquad={handleJoinSquad}
              onCreateTrigger={() => setIsCreateModalOpen(true)}
            />
          )}
          {activeTab === 'workspace' && <SquadWorkspace />}
          {activeTab === 'how' && <HowItWorks />}
        </main>

        {isCreateModalOpen && (
          <CreateSquadModal 
            onClose={() => setIsCreateModalOpen(false)}
            onSubmit={handleCreateSquad}
          />
        )}
      </ErrorBoundary>
    </div>
  );
}
