import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import { AuthProvider } from './context/AuthContext';
import { SquadProvider } from './context/SquadContext';
import './index.css';
import './custom.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthProvider>
      <SquadProvider>
        <App />
      </SquadProvider>
    </AuthProvider>
  </React.StrictMode>
);
