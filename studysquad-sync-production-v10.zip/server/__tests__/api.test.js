import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import { app } from '../index.js';

describe('StudySquad Sync REST API Integration Suite', () => {
  let authToken = '';

  beforeAll(async () => {
    process.env.JWT_SECRET = 'test_secret_key_studysquad_2026';
    const res = await request(app)
      .post('/api/auth/login')
      .send({ username: 'Alex_Student', role: 'student' });
    
    authToken = res.body.token;
  });

  it('GET /api/health should return ok', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });

  it('GET /api/rooms should return room inventory', async () => {
    const res = await request(app).get('/api/rooms');
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it('POST /api/rooms/r1/hold without token should fail with 401', async () => {
    const res = await request(app).post('/api/rooms/r1/hold');
    expect(res.status).toBe(401);
  });

  it('POST /api/rooms/r1/hold with token should reserve room', async () => {
    const res = await request(app)
      .post('/api/rooms/r1/hold')
      .set('Authorization', `Bearer ${authToken}`);
    
    expect([200, 400]).toContain(res.status);
  });
});
