import { db } from '../db/database.js';

export function setupOccupancyStream(app) {
  app.get('/api/rooms/stream', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const sendTelemetry = () => {
      const rooms = db.prepare('SELECT id, name, occupied, noise_db FROM rooms').all();
      res.write(`data: ${JSON.stringify(rooms)}\n\n`);
    };

    sendTelemetry();
    const intervalId = setInterval(sendTelemetry, 10000);

    req.on('close', () => {
      clearInterval(intervalId);
    });
  });
}
