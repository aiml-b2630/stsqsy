import Database from 'better-sqlite3';
import path from 'path';

const dbPath = process.env.DB_PATH || './server/db/studysquad.db';
export const db = new Database(dbPath);

db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    role TEXT DEFAULT 'student'
  );

  CREATE TABLE IF NOT EXISTS rooms (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    building TEXT NOT NULL,
    capacity INTEGER NOT NULL,
    occupied INTEGER NOT NULL,
    noise_db INTEGER NOT NULL,
    amenities TEXT NOT NULL,
    status TEXT NOT NULL,
    version INTEGER DEFAULT 1,
    reserved_by TEXT,
    hold_until TEXT
  );

  CREATE TABLE IF NOT EXISTS squads (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    subject TEXT NOT NULL,
    topic TEXT NOT NULL,
    schedule TEXT NOT NULL,
    room_id TEXT NOT NULL,
    max_members INTEGER NOT NULL,
    creator_id TEXT NOT NULL,
    streak INTEGER DEFAULT 1,
    rating REAL DEFAULT 4.8
  );

  CREATE TABLE IF NOT EXISTS squad_members (
    squad_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    PRIMARY KEY (squad_id, user_id),
    FOREIGN KEY (squad_id) REFERENCES squads(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status);
  CREATE INDEX IF NOT EXISTS idx_rooms_building ON rooms(building);
  CREATE INDEX IF NOT EXISTS idx_squads_subject ON squads(subject);
  CREATE INDEX IF NOT EXISTS idx_squad_members_squad ON squad_members(squad_id);
`);

// Seed initial data if empty
const roomCount = db.prepare('SELECT count(*) as count FROM rooms').get().count;
if (roomCount === 0) {
  const insertRoom = db.prepare(`
    INSERT INTO rooms (id, name, building, capacity, occupied, noise_db, amenities, status, version, reserved_by, hold_until)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NULL, NULL)
  `);

  const initialRooms = [
    ['r1', 'Lib Pod #3 (Silent)', 'Central Library', 4, 1, 35, 'Whiteboard, Power Sockets, Silent Zone', 'Available'],
    ['r2', 'Eng Discussion Room A', 'Engineering Block', 6, 4, 52, 'Whiteboard, Dual Monitors, Power Sockets', 'Available'],
    ['r3', 'Student Hub Cubicle 12', 'Student Center', 2, 2, 65, 'Power Sockets, Group Discussion', 'Occupied'],
    ['r4', 'Math Research Alcove', 'Central Library 3rd Floor', 8, 3, 40, 'Whiteboard, Silent Zone', 'Available'],
    ['r5', 'CS Collaboration Pod B', 'Engineering Block', 6, 2, 48, 'Dual Monitors, Power Sockets', 'Available'],
    ['r6', 'Quiet Study Hall Room 4', 'Central Library', 10, 10, 32, 'Silent Zone, Power Sockets', 'Occupied'],
    ['r7', 'Physics Lab Workspace', 'Science Building', 5, 0, 38, 'Whiteboard, Power Sockets', 'Available'],
    ['r8', 'BioTech Discussion Room', 'Science Building', 4, 2, 55, 'Whiteboard, Dual Monitors', 'Available']
  ];

  initialRooms.forEach(room => insertRoom.run(...room));
}

const squadCount = db.prepare('SELECT count(*) as count FROM squads').get().count;
if (squadCount === 0) {
  const insertSquad = db.prepare(`
    INSERT INTO squads (id, name, subject, topic, schedule, room_id, max_members, creator_id, streak, rating)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  insertSquad.run('s1', 'Linear Algebra Finals Group', 'Mathematics', 'Eigenvalues & Matrix Transformations', 'Afternoon', 'r1', 4, 'u1', 5, 4.9);
  insertSquad.run('s2', 'OS Kernel Hackers', 'Computer Science', 'Process Concurrency & Locks', 'Late Night', 'r2', 6, 'u2', 8, 5.0);
}
