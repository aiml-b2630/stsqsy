import { db } from '../db/database.js';
import { log } from '../utils/logger.js';

export function startHoldCleanupWorker(intervalMs = 30000) {
  log('info', 'Background hold cleanup worker started', { intervalMs });

  setInterval(() => {
    try {
      const nowISO = new Date().toISOString();
      const expiredRooms = db.prepare(`
        SELECT id, name FROM rooms
        WHERE status = 'Reserved' AND hold_until IS NOT NULL AND hold_until <= ?
      `).all(nowISO);

      if (expiredRooms.length > 0) {
        const stmt = db.prepare(`
          UPDATE rooms
          SET status = 'Available', version = version + 1, reserved_by = NULL, hold_until = NULL
          WHERE status = 'Reserved' AND hold_until IS NOT NULL AND hold_until <= ?
        `);
        const result = stmt.run(nowISO);
        log('info', `Auto-released ${result.changes} ghost room booking(s)`, { expiredRooms });
      }
    } catch (err) {
      log('error', 'Error running hold cleanup worker', { error: err.message });
    }
  }, intervalMs);
}
