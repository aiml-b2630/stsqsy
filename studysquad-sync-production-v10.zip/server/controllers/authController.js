import jwt from 'jsonwebtoken';
import { log } from '../utils/logger.js';

export function login(req, res) {
  const { username, role } = req.body;
  if (!username) {
    return res.status(400).json({ error: 'Username is required.' });
  }

  const user = { id: `u_${username.toLowerCase()}`, name: username, role: role || 'student' };
  const token = jwt.sign(user, process.env.JWT_SECRET, { expiresIn: '8h' });

  log('info', 'User authenticated successfully', { userId: user.id });
  return res.json({ token, user });
}
