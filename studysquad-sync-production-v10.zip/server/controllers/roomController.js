import { db } from '../db/database.js';
import { log } from '../utils/logger.js';

export function getRooms(req, res) {
  const rooms = db.prepare('SELECT * FROM rooms').all();
  return res.json(rooms);
}

export function holdRoom(req, res) {
  const { id } = req.params;
  const room = db.prepare('SELECT * FROM rooms WHERE id = ?').get(id);

  if (!room) {
    return res.status(404).json({ error: 'Room facility not found.' });
  }

  if (room.status !== 'Available') {
    return res.status(400).json({ error: `Room cannot be held. Current status: ${room.status}` });
  }

  const holdUntil = new Date(Date.now() + 20 * 60 * 1000).toISOString();
  const userId = req.user.id;

  // Optimistic Concurrency Control (OCC) using version lock
  const stmt = db.prepare(`
    UPDATE rooms
    SET status = 'Reserved', version = version + 1, reserved_by = ?, hold_until = ?
    WHERE id = ? AND version = ?
  `);

  const result = stmt.run(userId, holdUntil, id, room.version);

  if (result.changes === 0) {
    log('warn', 'OCC reservation conflict detected', { roomId: id, requestedVersion: room.version });
    return res.status(409).json({ error: 'Conflict: This room space was modified by another user simultaneously.' });
  }

  log('info', 'Room hold placed successfully', { roomId: id, reservedBy: userId, holdUntil });
  const updatedRoom = db.prepare('SELECT * FROM rooms WHERE id = ?').get(id);
  return res.json(updatedRoom);
}

export function releaseRoom(req, res) {
  const { id } = req.params;
  // req.targetRoom passed by authorizeRoomRelease middleware!
  
  const stmt = db.prepare(`
    UPDATE rooms
    SET status = 'Available', version = version + 1, reserved_by = NULL, hold_until = NULL
    WHERE id = ?
  `);

  stmt.run(id);
  log('info', 'Room hold released', { roomId: id, releasedBy: req.user.id });
  const updatedRoom = db.prepare('SELECT * FROM rooms WHERE id = ?').get(id);
  return res.json(updatedRoom);
}
