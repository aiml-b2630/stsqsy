import { db } from '../db/database.js';
import { log } from '../utils/logger.js';

export function getSquads(req, res) {
  const squads = db.prepare('SELECT * FROM squads').all();
  const squadMembers = db.prepare('SELECT * FROM squad_members').all();
  
  const squadList = squads.map(s => {
    const members = squadMembers.filter(m => m.squad_id === s.id).map(m => m.user_id);
    return { ...s, members: [s.creator_id, ...members] };
  });

  return res.json(squadList);
}

export function createSquad(req, res) {
  const { name, subject, topic, schedule, roomId, maxMembers } = req.body;
  if (!name || !subject || !topic || !roomId) {
    return res.status(400).json({ error: 'Missing required squad fields.' });
  }

  const id = `s_${Date.now()}`;
  const creatorId = req.user.id;

  const stmt = db.prepare(`
    INSERT INTO squads (id, name, subject, topic, schedule, room_id, max_members, creator_id, streak, rating)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 5.0)
  `);

  stmt.run(id, name, subject, topic, schedule || 'Afternoon', roomId, maxMembers || 4, creatorId);

  db.prepare('INSERT INTO squad_members (squad_id, user_id) VALUES (?, ?)').run(id, creatorId);

  log('info', 'Study squad created', { squadId: id, creatorId });
  return res.status(201).json({ id, name, subject, topic, schedule, room_id: roomId, max_members: maxMembers, creator_id: creatorId, members: [creatorId] });
}

export function joinSquad(req, res) {
  const { id } = req.params;
  const userId = req.user.id;

  const squad = db.prepare('SELECT * FROM squads WHERE id = ?').get(id);
  if (!squad) {
    return res.status(404).json({ error: 'Squad not found.' });
  }

  const members = db.prepare('SELECT user_id FROM squad_members WHERE squad_id = ?').all(id).map(m => m.user_id);
  if (members.includes(userId)) {
    return res.status(400).json({ error: 'User is already a member of this squad.' });
  }

  if (members.length >= squad.max_members) {
    return res.status(400).json({ error: 'Squad is already at maximum capacity.' });
  }

  db.prepare('INSERT INTO squad_members (squad_id, user_id) VALUES (?, ?)').run(id, userId);
  log('info', 'User joined study squad', { squadId: id, userId });

  return res.json({ message: 'Successfully joined squad.', squadId: id, members: [...members, userId] });
}
