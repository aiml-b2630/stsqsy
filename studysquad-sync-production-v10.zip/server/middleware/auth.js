import jwt from 'jsonwebtoken';
import { log } from '../utils/logger.js';

export function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Authentication required. No token provided.' });
  }
  
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    log('error', 'JWT_SECRET environment variable is missing.');
    return res.status(500).json({ error: 'Server security misconfiguration.' });
  }

  try {
    const decoded = jwt.verify(token, secret);
    req.user = decoded;
    next();
  } catch (err) {
    log('warn', 'Invalid or expired JWT token', { error: err.message });
    return res.status(403).json({ error: 'Invalid or expired token.' });
  }
}
