import { db } from '../db/database.js';
import { log } from '../utils/logger.js';

export function authorizeRoomRelease(req, res, next) {
  const { id } = req.params;
  const room = db.prepare('SELECT * FROM rooms WHERE id = ?').get(id);
  
  if (!room) {
    return res.status(404).json({ error: 'Room facility not found.' });
  }

  // If room is reserved, check if current user is creator/reserver or admin
  if (room.status === 'Reserved' && room.reserved_by) {
    if (room.reserved_by !== req.user.id && req.user.role !== 'admin') {
      log('warn', 'Unauthorized room release attempt', { roomId: id, userId: req.user.id, reservedBy: room.reserved_by });
      return res.status(403).json({ error: 'Forbidden: Only the student who reserved this space or an admin can release it.' });
    }
  }
  req.targetRoom = room;
  next();
}

export function authorizeSquadOwner(req, res, next) {
  const { id } = req.params;
  const squad = db.prepare('SELECT * FROM squads WHERE id = ?').get(id);

  if (!squad) {
    return res.status(404).json({ error: 'Squad not found.' });
  }

  if (squad.creator_id !== req.user.id && req.user.role !== 'admin') {
    log('warn', 'Unauthorized squad management attempt', { squadId: id, userId: req.user.id, creatorId: squad.creator_id });
    return res.status(403).json({ error: 'Forbidden: Only the squad creator or an admin can perform this action.' });
  }
  req.targetSquad = squad;
  next();
}
