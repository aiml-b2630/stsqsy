export function log(level, message, meta = {}) {
  const timestamp = new Date().toISOString();
  const logPayload = { timestamp, level: level.toUpperCase(), message, ...meta };
  console.log(JSON.stringify(logPayload));
}
