import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';

dotenv.config();

import { login } from './controllers/authController.js';
import { getRooms, holdRoom, releaseRoom } from './controllers/roomController.js';
import { getSquads, createSquad, joinSquad } from './controllers/squadController.js';
import { authenticateToken } from './middleware/auth.js';
import { authorizeRoomRelease } from './middleware/authorize.js';
import { startHoldCleanupWorker } from './workers/holdCleanupWorker.js';
import { setupOccupancyStream } from './events/occupancyStream.js';
import { log } from './utils/logger.js';

export const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ status: 'ok', version: '10.0.0' }));
app.post('/api/auth/login', login);

app.get('/api/rooms', getRooms);
app.post('/api/rooms/:id/hold', authenticateToken, holdRoom);
app.post('/api/rooms/:id/release', authenticateToken, authorizeRoomRelease, releaseRoom);

app.get('/api/squads', getSquads);
app.post('/api/squads', authenticateToken, createSquad);
app.post('/api/squads/:id/join', authenticateToken, joinSquad);

setupOccupancyStream(app);

app.get('/api/docs', (req, res) => {
  const swaggerPath = path.join(process.cwd(), 'server', 'docs', 'swagger.json');
  if (fs.existsSync(swaggerPath)) {
    return res.sendFile(swaggerPath);
  }
  res.json({ title: 'StudySquad Sync API v10 Docs' });
});

const PORT = process.env.PORT || 5000;
if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    log('info', `StudySquad Sync API server running on port ${PORT}`);
    startHoldCleanupWorker(30000);
  });
}
