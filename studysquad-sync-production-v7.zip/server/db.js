import Database from 'better-sqlite3';
import { logger } from './logger.js';

const dbPath = process.env.DATABASE_URL || './server/studysquad.db';
const db = new Database(dbPath);

// Enable foreign keys
db.pragma('foreign_keys = ON');

// Schema setup with explicit indexes
db.exec(`
  CREATE TABLE IF NOT EXISTS rooms (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    building TEXT NOT NULL,
    capacity INTEGER NOT NULL,
    occupied_chairs INTEGER DEFAULT 0,
    noise_db INTEGER DEFAULT 40,
    status TEXT DEFAULT 'available',
    amenities TEXT,
    hold_until DATETIME,
    held_by TEXT,
    version INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS squads (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    subject TEXT NOT NULL,
    creator TEXT NOT NULL,
    max_members INTEGER NOT NULL,
    meeting_time TEXT NOT NULL,
    room_id TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(room_id) REFERENCES rooms(id)
  );

  CREATE TABLE IF NOT EXISTS squad_members (
    squad_id TEXT NOT NULL,
    user_name TEXT NOT NULL,
    joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(squad_id, user_name),
    FOREIGN KEY(squad_id) REFERENCES squads(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status);
  CREATE INDEX IF NOT EXISTS idx_rooms_building ON rooms(building);
  CREATE INDEX IF NOT EXISTS idx_squads_subject ON squads(subject);
  CREATE INDEX IF NOT EXISTS idx_squad_members_squad ON squad_members(squad_id);
`);

// Seed initial rooms if empty
const count = db.prepare('SELECT count(*) as cnt FROM rooms').get().cnt;
if (count === 0) {
  logger.info('Seeding 12 campus study rooms into SQLite3...');
  const insert = db.prepare(`
    INSERT INTO rooms (id, name, building, capacity, occupied_chairs, noise_db, status, amenities, version)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
  `);
  
  const seedRooms = [
    ['room-1', 'Central Pod A', 'Central Library 3rd Floor', 4, 1, 38, 'available', 'Whiteboard,Power Sockets,Silent Zone'],
    ['room-2', 'Central Pod B', 'Central Library 3rd Floor', 6, 6, 62, 'occupied', 'Whiteboard,Dual Monitors'],
    ['room-3', 'Eng Discussion Room 101', 'Engineering Block', 8, 3, 45, 'available', 'Whiteboard,Power Sockets,Group Discussion'],
    ['room-4', 'Eng Quiet Room 102', 'Engineering Block', 4, 0, 32, 'available', 'Silent Zone,Power Sockets'],
    ['room-5', 'Student Union Hub 1', 'Student Center', 10, 8, 68, 'occupied', 'Group Discussion,Whiteboard,Power Sockets'],
    ['room-6', 'Student Union Hub 2', 'Student Center', 6, 2, 42, 'available', 'Whiteboard,Dual Monitors'],
    ['room-7', 'Science Lab Study 3A', 'Science Complex', 4, 0, 35, 'available', 'Silent Zone,Dual Monitors,Power Sockets'],
    ['room-8', 'Science Lab Study 3B', 'Science Complex', 6, 6, 70, 'occupied', 'Group Discussion,Whiteboard'],
    ['room-9', 'Law Silent Library Nook', 'Law Wing', 2, 1, 30, 'available', 'Silent Zone,Power Sockets'],
    ['room-10', 'Law Seminar Alcove', 'Law Wing', 6, 0, 36, 'available', 'Whiteboard,Group Discussion'],
    ['room-11', 'Med Health Discussion Pod', 'Medical Building', 4, 4, 58, 'occupied', 'Dual Monitors,Power Sockets'],
    ['room-12', 'Med Learning Commons 4', 'Medical Building', 8, 2, 40, 'available', 'Whiteboard,Power Sockets,Silent Zone']
  ];

  for (const r of seedRooms) {
    insert.run(...r);
  }
}

export default db;
