import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import db from './db.js';
import { logger } from './logger.js';
import { authenticateToken } from './middleware/auth.js';
import { validateSquadInput } from './middleware/validate.js';
import { startHoldCleanupWorker } from './workers/holdCleanupWorker.js';
import { handleOccupancyStream, broadcastOccupancyUpdate } from './events/occupancyStream.js';

dotenv.config();

export const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;

// API Documentation & Health
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), version: '7.0.0' });
});

app.get('/api/docs', (req, res) => {
  res.sendFile(new URL('./docs/swagger.json', import.meta.url).pathname);
});

// Authentication
app.post('/api/auth/login', (req, res) => {
  const { username, role } = req.body;
  if (!username) return res.status(400).json({ error: 'Username is required' });
  
  const secret = process.env.JWT_SECRET || 'super_secret_jwt_key_production_v7';
  const token = jwt.sign({ username, role: role || 'student' }, secret, { expiresIn: '8h' });
  
  logger.info(`User logged in: ${username} (${role || 'student'})`);
  res.json({ token, username, role: role || 'student' });
});

// Real-Time Occupancy Telemetry Stream (SSE)
app.get('/api/rooms/stream', handleOccupancyStream);

// Rooms API
app.get('/api/rooms', (req, res) => {
  const rooms = db.prepare('SELECT * FROM rooms').all();
  const formatted = rooms.map(r => ({
    ...r,
    amenities: r.amenities ? r.amenities.split(',') : []
  }));
  res.json(formatted);
});

// Optimistic Concurrency Room Hold (20 Minutes)
app.post('/api/rooms/:id/hold', authenticateToken, (req, res) => {
  const { id } = req.params;
  const { expectedVersion } = req.body;
  const username = req.user.username;

  const room = db.prepare('SELECT * FROM rooms WHERE id = ?').get(id);
  if (!room) return res.status(404).json({ error: 'Room not found' });
  if (room.status !== 'available') return res.status(400).json({ error: `Room is currently ${room.status}` });

  // Optimistic Concurrency Lock Check
  if (expectedVersion !== undefined && room.version !== expectedVersion) {
    logger.warn(`OCC Conflict on room ${id}: client version ${expectedVersion} vs db version ${room.version}`);
    return res.status(409).json({ error: 'Reservation collision: Room state changed by another student. Please refresh.' });
  }

  const holdUntil = new Date(Date.now() + 20 * 60 * 1000).toISOString();
  
  const update = db.prepare(`
    UPDATE rooms 
    SET status = 'reserved', hold_until = ?, held_by = ?, version = version + 1
    WHERE id = ? AND version = ?
  `).run(holdUntil, username, id, room.version);

  if (update.changes === 0) {
    return res.status(409).json({ error: 'Concurrent booking collision occurred.' });
  }

  const updatedRoom = db.prepare('SELECT * FROM rooms WHERE id = ?').get(id);
  logger.info(`Room ${id} successfully held by ${username} for 20 minutes.`);
  
  broadcastOccupancyUpdate({ type: 'ROOM_HELD', room: updatedRoom });

  res.json({ message: '20-Minute Hold Confirmed', room: updatedRoom });
});

// Squads API
app.get('/api/squads', (req, res) => {
  const squads = db.prepare('SELECT * FROM squads ORDER BY created_at DESC').all();
  const getMembers = db.prepare('SELECT user_name FROM squad_members WHERE squad_id = ?');
  
  const enriched = squads.map(s => ({
    ...s,
    members: getMembers.all(s.id).map(m => m.user_name)
  }));

  res.json(enriched);
});

app.post('/api/squads', authenticateToken, validateSquadInput, (req, res) => {
  const { title, subject, max_members, meeting_time, room_id } = req.body;
  const creator = req.user.username;
  const id = 'squad-' + Date.now();

  const insertSquad = db.prepare(`
    INSERT INTO squads (id, title, subject, creator, max_members, meeting_time, room_id)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const insertMember = db.prepare('INSERT INTO squad_members (squad_id, user_name) VALUES (?, ?)');

  db.transaction(() => {
    insertSquad.run(id, title, subject, creator, max_members, meeting_time, room_id || null);
    insertMember.run(id, creator);
  })();

  logger.info(`New Study Squad created: ${title} (${subject}) by ${creator}`);
  res.status(201).json({ message: 'Squad Created Successfully', squadId: id });
});

// Background worker initiation
if (process.env.NODE_ENV !== 'test') {
  startHoldCleanupWorker();
  app.listen(PORT, () => {
    logger.info(`StudySquad Sync v7.0.0 Server running on port ${PORT}`);
  });
}
