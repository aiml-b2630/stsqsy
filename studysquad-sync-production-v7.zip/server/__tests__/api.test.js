import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import { app } from '../index.js';

describe('StudySquad Sync REST API & Security Test Suite', () => {
  let authToken = '';

  beforeAll(async () => {
    process.env.JWT_SECRET = 'super_secret_jwt_key_production_v7';
    const res = await request(app)
      .post('/api/auth/login')
      .send({ username: 'test_student', role: 'student' });
    authToken = res.body.token;
  });

  it('GET /api/health - should return 200 OK', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
    expect(res.body.version).toBe('7.0.0');
  });

  it('GET /api/rooms - should fetch list of campus rooms', async () => {
    const res = await request(app).get('/api/rooms');
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it('POST /api/rooms/:id/hold - should reject without authorization token', async () => {
    const res = await request(app)
      .post('/api/rooms/room-1/hold')
      .send({ expectedVersion: 1 });
    expect(res.status).toBe(401);
  });

  it('POST /api/rooms/:id/hold - should place a 20-minute hold with valid token', async () => {
    const res = await request(app)
      .post('/api/rooms/room-1/hold')
      .set('Authorization', `Bearer ${authToken}`)
      .send({ expectedVersion: 1 });
    
    expect([200, 400, 409]).toContain(res.status);
    if (res.status === 200) {
      expect(res.body.room.status).toBe('reserved');
    }
  });
});
