export function validateSquadInput(req, res, next) {
  const { title, subject, max_members, meeting_time } = req.body;
  
  if (!title || typeof title !== 'string' || title.trim().length < 3) {
    return res.status(400).json({ error: 'Validation Error: Squad title must be at least 3 characters.' });
  }
  if (!subject || typeof subject !== 'string') {
    return res.status(400).json({ error: 'Validation Error: Subject is required.' });
  }
  if (!max_members || typeof max_members !== 'number' || max_members < 2 || max_members > 20) {
    return res.status(400).json({ error: 'Validation Error: Max members must be a number between 2 and 20.' });
  }
  if (!meeting_time || typeof meeting_time !== 'string') {
    return res.status(400).json({ error: 'Validation Error: Meeting time is required.' });
  }

  next();
}
