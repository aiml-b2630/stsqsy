import jwt from 'jsonwebtoken';
import { logger } from '../logger.js';

export function authenticateToken(req, res, next) {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    logger.error('CRITICAL: JWT_SECRET environment variable is missing.');
    return res.status(500).json({ error: 'Server security misconfiguration: missing secret key.' });
  }

  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Access denied: Token required.' });
  }

  try {
    const verified = jwt.verify(token, secret);
    req.user = verified;
    next();
  } catch (err) {
    logger.warn('Unauthorized request: Invalid or expired JWT token', { error: err.message });
    return res.status(403).json({ error: 'Invalid or expired authentication token.' });
  }
}
