import db from '../db.js';
import { logger } from '../logger.js';

export function startHoldCleanupWorker(intervalMs = 15000) {
  logger.info(`Starting background hold cleanup worker running every ${intervalMs}ms...`);
  
  setInterval(() => {
    try {
      const now = new Date().toISOString();
      const stmt = db.prepare(`
        UPDATE rooms 
        SET status = 'available', hold_until = NULL, held_by = NULL, version = version + 1
        WHERE status = 'reserved' AND hold_until IS NOT NULL AND hold_until <= ?
      `);
      
      const result = stmt.run(now);
      if (result.changes > 0) {
        logger.info(`Background Worker: Auto-released ${result.changes} expired 20-minute room hold(s).`);
      }
    } catch (err) {
      logger.error('Error in hold cleanup worker', { error: err.message });
    }
  }, intervalMs);
}
