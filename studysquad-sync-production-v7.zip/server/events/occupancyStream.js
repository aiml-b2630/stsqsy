import { logger } from '../logger.js';

let clients = [];

export function handleOccupancyStream(req, res) {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  clients.push(res);
  logger.info(`Client connected to real-time occupancy stream. Total SSE listeners: ${clients.length}`);

  req.on('close', () => {
    clients = clients.filter(c => c !== res);
    logger.info(`Client disconnected from stream. Remaining SSE listeners: ${clients.length}`);
  });
}

export function broadcastOccupancyUpdate(data) {
  clients.forEach(client => {
    client.write(`data: ${JSON.stringify(data)}\n\n`);
  });
}
