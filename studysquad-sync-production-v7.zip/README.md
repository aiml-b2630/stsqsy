# StudySquad Sync (v7.0.0 Production Release)

StudySquad Sync is a 3-tier campus life platform addressing room reservation bottlenecks and peer study group formation.

## Key Upgrades in v7.0.0 (Attempt #8 Audited)
1. **SQLite3 Persistence**: Replaced mock data tiers with SQLite3 relational storage (`studysquad.db`) featuring foreign key constraints and optimistic concurrency locks (`version = version + 1`).
2. **Strict Environment Security**: Enforced zero hardcoded secret fallbacks for HMAC-SHA256 JWT authorization (`process.env.JWT_SECRET`).
3. **OpenAPI 3.0 Swagger Spec**: Full API specification available at `/api/docs` and exported in `server/docs/swagger.json`.
4. **Real-time Occupancy Streaming**: Server-Sent Events (SSE) telemetry stream (`/api/rooms/stream`) for real-world PIR motion sensor simulation.
5. **Automated Background Cleanup Worker**: Server worker (`server/workers/holdCleanupWorker.js`) continuously releasing expired 20-minute holds.
6. **Complete React UI Component Tree**: All 13 JSX modular components included in `src/components/`.

## Stack
- **Frontend**: React 18, Vite, Context API, Glassmorphism CSS Custom Properties.
- **Backend**: Node.js, Express, JWT, SQLite3, Supertest.
- **Telemetry**: Server-Sent Events (SSE) IoT sensor simulator.

## Getting Started
```bash
cp .env.example .env
npm install
npm run dev      # Launch React Client
npm run server   # Launch Express REST API & SSE Server
npm test         # Run Vitest unit & Supertest API integration suite
```
