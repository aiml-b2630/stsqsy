import { describe, it, expect } from 'vitest';
import { calculateJaccardSimilarity, matchSquads } from '../utils/matchingEngine.js';

describe('Subject Matching Engine Tests', () => {
  it('should compute accurate Jaccard similarity', () => {
    const score = calculateJaccardSimilarity('Linear Algebra', 'Linear Algebra Finals');
    expect(score).toBeGreaterThan(0.5);
  });

  it('should return sorted squads by matching percentage', () => {
    const sampleSquads = [
      { id: '1', title: 'History Group', subject: 'European History', meeting_time: 'Morning' },
      { id: '2', title: 'Math Squad', subject: 'Linear Algebra', meeting_time: 'Afternoon' }
    ];
    const results = matchSquads('Linear Algebra', 'Afternoon', sampleSquads);
    expect(results[0].id).toBe('2');
    expect(results[0].matchPercentage).toBeGreaterThan(results[1].matchPercentage);
  });
});
