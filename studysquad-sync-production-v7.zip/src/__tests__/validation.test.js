import { describe, it, expect } from 'vitest';
import { sanitizeString, validateSquadForm } from '../utils/validationSchemas.js';

describe('Validation Utilities Test Suite', () => {
  it('should sanitize script tags to prevent XSS', () => {
    const raw = '<script>alert("xss")</script>';
    const clean = sanitizeString(raw);
    expect(clean).not.toContain('<script>');
    expect(clean).toContain('&lt;script&gt;');
  });

  it('should catch short squad titles in form validation', () => {
    const errors = validateSquadForm({ title: 'ab', subject: 'Math', max_members: 4 });
    expect(errors.title).toBeDefined();
  });
});
