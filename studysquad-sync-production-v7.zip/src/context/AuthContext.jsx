import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('studysquad_user');
    return saved ? JSON.parse(saved) : { username: 'Alex Student', role: 'student', token: 'mock-jwt-token' };
  });

  const login = (username, role = 'student') => {
    const userObj = { username, role, token: 'jwt-auth-' + Date.now() };
    setUser(userObj);
    localStorage.setItem('studysquad_user', JSON.stringify(userObj));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('studysquad_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
