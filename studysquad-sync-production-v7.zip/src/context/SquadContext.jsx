import React, { createContext, useContext, useState, useEffect } from 'react';
import { initialRooms, initialSquads } from '../utils/mockData.js';

const SquadContext = createContext();

export function SquadProvider({ children }) {
  const [rooms, setRooms] = useState(() => {
    const saved = localStorage.getItem('studysquad_rooms');
    return saved ? JSON.parse(saved) : initialRooms;
  });

  const [squads, setSquads] = useState(() => {
    const saved = localStorage.getItem('studysquad_squads');
    return saved ? JSON.parse(saved) : initialSquads;
  });

  const [activeHold, setActiveHold] = useState(() => {
    const saved = localStorage.getItem('studysquad_hold');
    return saved ? JSON.parse(saved) : null;
  });

  const [toast, setToast] = useState(null);

  useEffect(() => {
    localStorage.setItem('studysquad_rooms', JSON.stringify(rooms));
  }, [rooms]);

  useEffect(() => {
    localStorage.setItem('studysquad_squads', JSON.stringify(squads));
  }, [squads]);

  useEffect(() => {
    if (activeHold) {
      localStorage.setItem('studysquad_hold', JSON.stringify(activeHold));
    } else {
      localStorage.removeItem('studysquad_hold');
    }
  }, [activeHold]);

  const showToast = (message, type = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const holdRoom = (roomId, userName) => {
    const target = rooms.find(r => r.id === roomId);
    if (!target) return false;
    if (target.status !== 'available') {
      showToast(`Room ${target.name} is currently ${target.status}`, 'warning');
      return false;
    }

    const holdUntil = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, status: 'reserved', hold_until: holdUntil, held_by: userName } : r));
    setActiveHold({ roomId, roomName: target.name, holdUntil, userName });
    showToast(`20-Minute Hold Placed on ${target.name}!`, 'success');
    return true;
  };

  const releaseHold = (roomId) => {
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, status: 'available', hold_until: null, held_by: null } : r));
    setActiveHold(null);
    showToast('Hold Released', 'info');
  };

  const createSquad = (newSquad) => {
    const squadObj = {
      ...newSquad,
      id: 'squad-' + Date.now(),
      members: [newSquad.creator || 'Current Student'],
      created_at: new Date().toISOString()
    };
    setSquads(prev => [squadObj, ...prev]);
    showToast(`Squad "${newSquad.title}" created!`, 'success');
  };

  const joinSquad = (squadId, userName) => {
    setSquads(prev => prev.map(s => {
      if (s.id === squadId && !s.members.includes(userName) && s.members.length < s.max_members) {
        showToast(`Joined squad: ${s.title}`, 'success');
        return { ...s, members: [...s.members, userName] };
      }
      return s;
    }));
  };

  return (
    <SquadContext.Provider value={{
      rooms, setRooms, squads, activeHold, holdRoom, releaseHold, createSquad, joinSquad, toast, showToast
    }}>
      {children}
    </SquadContext.Provider>
  );
}

export const useSquad = () => useContext(SquadContext);
