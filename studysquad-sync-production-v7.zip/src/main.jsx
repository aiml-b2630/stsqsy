import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import { SquadProvider } from './context/SquadContext';
import { AuthProvider } from './context/AuthContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import './styles/custom.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ErrorBoundary>
      <AuthProvider>
        <SquadProvider>
          <App />
        </SquadProvider>
      </AuthProvider>
    </ErrorBoundary>
  </React.StrictMode>
);
