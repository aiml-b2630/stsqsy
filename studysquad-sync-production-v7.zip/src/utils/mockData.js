export const initialRooms = [
  { id: 'room-1', name: 'Central Pod A', building: 'Central Library 3rd Floor', capacity: 4, occupied_chairs: 1, noise_db: 38, status: 'available', amenities: ['Whiteboard', 'Power Sockets', 'Silent Zone'], version: 1 },
  { id: 'room-2', name: 'Central Pod B', building: 'Central Library 3rd Floor', capacity: 6, occupied_chairs: 6, noise_db: 62, status: 'occupied', amenities: ['Whiteboard', 'Dual Monitors'], version: 1 },
  { id: 'room-3', name: 'Eng Discussion Room 101', building: 'Engineering Block', capacity: 8, occupied_chairs: 3, noise_db: 45, status: 'available', amenities: ['Whiteboard', 'Power Sockets', 'Group Discussion'], version: 1 },
  { id: 'room-4', name: 'Eng Quiet Room 102', building: 'Engineering Block', capacity: 4, occupied_chairs: 0, noise_db: 32, status: 'available', amenities: ['Silent Zone', 'Power Sockets'], version: 1 },
  { id: 'room-5', name: 'Student Union Hub 1', building: 'Student Center', capacity: 10, occupied_chairs: 8, noise_db: 68, status: 'occupied', amenities: ['Group Discussion', 'Whiteboard', 'Power Sockets'], version: 1 },
  { id: 'room-6', name: 'Student Union Hub 2', building: 'Student Center', capacity: 6, occupied_chairs: 2, noise_db: 42, status: 'available', amenities: ['Whiteboard', 'Dual Monitors'], version: 1 },
  { id: 'room-7', name: 'Science Lab Study 3A', building: 'Science Complex', capacity: 4, occupied_chairs: 0, noise_db: 35, status: 'available', amenities: ['Silent Zone', 'Dual Monitors', 'Power Sockets'], version: 1 },
  { id: 'room-8', name: 'Science Lab Study 3B', building: 'Science Complex', capacity: 6, occupied_chairs: 6, noise_db: 70, status: 'occupied', amenities: ['Group Discussion', 'Whiteboard'], version: 1 },
  { id: 'room-9', name: 'Law Silent Library Nook', building: 'Law Wing', capacity: 2, occupied_chairs: 1, noise_db: 30, status: 'available', amenities: ['Silent Zone', 'Power Sockets'], version: 1 },
  { id: 'room-10', name: 'Law Seminar Alcove', building: 'Law Wing', capacity: 6, occupied_chairs: 0, noise_db: 36, status: 'available', amenities: ['Whiteboard', 'Group Discussion'], version: 1 },
  { id: 'room-11', name: 'Med Health Discussion Pod', building: 'Medical Building', capacity: 4, occupied_chairs: 4, noise_db: 58, status: 'occupied', amenities: ['Dual Monitors', 'Power Sockets'], version: 1 },
  { id: 'room-12', name: 'Med Learning Commons 4', building: 'Medical Building', capacity: 8, occupied_chairs: 2, noise_db: 40, status: 'available', amenities: ['Whiteboard', 'Power Sockets', 'Silent Zone'], version: 1 }
];

export const initialSquads = [
  { id: 'squad-1', title: 'Operating Systems Finals Prep', subject: 'Operating Systems', creator: 'Alex Student', max_members: 4, meeting_time: 'Afternoon (2 PM - 5 PM)', members: ['Alex Student', 'Sarah K.'], room_id: 'room-3' },
  { id: 'squad-2', title: 'Linear Algebra Problem Set 5', subject: 'Linear Algebra', creator: 'Michael Chen', max_members: 3, meeting_time: 'Morning (9 AM - 12 PM)', members: ['Michael Chen'], room_id: 'room-1' },
  { id: 'squad-3', title: 'Organic Chemistry Reactions', subject: 'Chemistry', creator: 'Priya Patel', max_members: 5, meeting_time: 'Late Night (7 PM - 10 PM)', members: ['Priya Patel', 'David L.', 'Emma W.'], room_id: 'room-6' }
];
