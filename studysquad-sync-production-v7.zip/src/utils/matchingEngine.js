export function calculateScheduleOverlap(schedule1, schedule2) {
  if (!schedule1 || !schedule2) return 0.5;
  if (schedule1.toLowerCase() === schedule2.toLowerCase()) return 1.0;
  return 0.3;
}

export function calculateJaccardSimilarity(text1, text2) {
  if (!text1 || !text2) return 0;
  const setA = new Set(text1.toLowerCase().split(/\s+/));
  const setB = new Set(text2.toLowerCase().split(/\s+/));
  const intersection = new Set([...setA].filter(x => setB.has(x)));
  const union = new Set([...setA, ...setB]);
  return intersection.size / union.size;
}

export function matchSquads(userSubject, userSchedule, squads) {
  if (!squads || !Array.isArray(squads)) return [];

  return squads.map(squad => {
    const subjectScore = calculateJaccardSimilarity(userSubject, squad.subject);
    const scheduleScore = calculateScheduleOverlap(userSchedule, squad.meeting_time);
    const overallScore = Math.round((subjectScore * 0.6 + scheduleScore * 0.4) * 100);

    return {
      ...squad,
      matchPercentage: overallScore
    };
  }).sort((a, b) => b.matchPercentage - a.matchPercentage);
}
