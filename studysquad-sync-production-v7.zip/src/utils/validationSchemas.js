export function sanitizeString(input) {
  if (typeof input !== 'string') return '';
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

export function validateSquadForm(values) {
  const errors = {};
  if (!values.title || values.title.trim().length < 3) {
    errors.title = 'Title must be at least 3 characters.';
  }
  if (!values.subject || values.subject.trim().length < 2) {
    errors.subject = 'Subject topic is required.';
  }
  if (!values.max_members || values.max_members < 2 || values.max_members > 20) {
    errors.max_members = 'Group capacity must be between 2 and 20.';
  }
  return errors;
}
