const API_BASE = '/api';

export async function fetchRooms() {
  const res = await fetch(`${API_BASE}/rooms`);
  if (!res.ok) throw new Error('Failed to fetch rooms');
  return res.json();
}

export async function placeHold(roomId, expectedVersion, token) {
  const res = await fetch(`${API_BASE}/rooms/${roomId}/hold`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ expectedVersion })
  });
  if (!res.ok) {
    const errData = await res.json();
    throw new Error(errData.error || 'Failed to place hold');
  }
  return res.json();
}

export async function fetchSquads() {
  const res = await fetch(`${API_BASE}/squads`);
  if (!res.ok) throw new Error('Failed to fetch squads');
  return res.json();
}
