import React, { useState } from 'react';
import { Header } from './components/Header';
import { RoomVisualizer } from './components/RoomVisualizer';
import { SquadMatcher } from './components/SquadMatcher';
import { HoldTimerModal } from './components/HoldTimerModal';
import { CreateSquadModal } from './components/CreateSquadModal';
import { HowItWorks } from './components/HowItWorks';
import { Toast } from './components/Toast';
import { useSquad } from './context/SquadContext';
import { useIoTSensorSim } from './hooks/useIoTSensorSim';

export function App() {
  const [activeTab, setActiveTab] = useState('radar');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { rooms, squads, activeHold, holdRoom, releaseHold, createSquad, joinSquad, toast } = useSquad();
  
  const liveRooms = useIoTSensorSim(rooms);

  return (
    <div>
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main style={{ padding: '0 24px 40px 24px' }}>
        {activeTab === 'radar' && <RoomVisualizer rooms={liveRooms} onHoldRoom={holdRoom} />}
        {activeTab === 'squads' && <SquadMatcher squads={squads} onJoinSquad={(id) => joinSquad(id, 'Current Student')} onCreateClick={() => setIsModalOpen(true)} />}
        {activeTab === 'how' && <HowItWorks />}
      </main>

      <HoldTimerModal hold={activeHold} onRelease={releaseHold} />
      <CreateSquadModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onCreate={createSquad} />
      <Toast toast={toast} />
    </div>
  );
}
