import { useState, useEffect } from 'react';

export function useHoldTimer(expiryTimestamp, onExpired) {
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (!expiryTimestamp) return;

    const calculateRemaining = () => {
      const diff = Math.floor((new Date(expiryTimestamp).getTime() - Date.now()) / 1000);
      if (diff <= 0) {
        setTimeLeft(0);
        if (onExpired) onExpired();
      } else {
        setTimeLeft(diff);
      }
    };

    calculateRemaining();
    const interval = setInterval(calculateRemaining, 1000);
    return () => clearInterval(interval);
  }, [expiryTimestamp]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  return { timeLeft, formattedTime, isExpired: timeLeft === 0 };
}
