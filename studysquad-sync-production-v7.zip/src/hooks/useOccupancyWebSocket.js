import { useEffect } from 'react';

export function useOccupancyWebSocket(onUpdate) {
  useEffect(() => {
    const eventSource = new EventSource('/api/rooms/stream');

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (onUpdate) onUpdate(data);
      } catch (err) {
        console.error('Error parsing SSE event', err);
      }
    };

    return () => eventSource.close();
  }, [onUpdate]);
}
