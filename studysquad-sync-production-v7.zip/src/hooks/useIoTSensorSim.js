import { useState, useEffect } from 'react';

export function useIoTSensorSim(initialRooms) {
  const [rooms, setRooms] = useState(initialRooms || []);

  useEffect(() => {
    if (initialRooms && initialRooms.length > 0 && rooms.length === 0) {
      setRooms(initialRooms);
    }
  }, [initialRooms]);

  useEffect(() => {
    const interval = setInterval(() => {
      setRooms(prevRooms => 
        prevRooms.map(room => {
          if (room.status === 'reserved') return room;
          
          // Toggles noise levels dynamically between 30 and 72 dB
          const noiseDelta = Math.floor(Math.random() * 7) - 3;
          const newNoise = Math.max(30, Math.min(75, (room.noise_db || 40) + noiseDelta));
          
          return {
            ...room,
            noise_db: newNoise
          };
        })
      );
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  return rooms;
}
