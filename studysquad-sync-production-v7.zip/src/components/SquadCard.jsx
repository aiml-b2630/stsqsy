import React from 'react';
import { Users, Clock, BookOpen, CheckCircle } from 'lucide-react';

export function SquadCard({ squad, onJoin, isMember }) {
  return (
    <div className="glass-card" style={{ padding: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <h3 style={{ margin: '0 0 6px 0', fontSize: '16px' }}>{squad.title}</h3>
          {squad.matchPercentage && (
            <span style={{ background: 'rgba(56, 189, 248, 0.15)', color: '#38bdf8', padding: '2px 8px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold' }}>
              {squad.matchPercentage}% Match
            </span>
          )}
        </div>
        <div style={{ fontSize: '13px', color: 'var(--accent-indigo)', fontWeight: 500, marginBottom: '12px' }}>
          <BookOpen size={14} style={{ display: 'inline', marginRight: '4px' }} /> {squad.subject}
        </div>

        <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginBottom: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px' }}>
            <Clock size={14} /> {squad.meeting_time}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Users size={14} /> {squad.members.length} / {squad.max_members} Members
          </div>
        </div>
      </div>

      <button
        onClick={() => onJoin(squad.id)}
        disabled={isMember || squad.members.length >= squad.max_members}
        style={{
          width: '100%',
          padding: '8px',
          borderRadius: '6px',
          border: 'none',
          background: isMember ? 'rgba(16, 185, 129, 0.2)' : 'var(--accent-indigo)',
          color: isMember ? '#10b981' : '#fff',
          cursor: isMember ? 'default' : 'pointer',
          fontWeight: 'bold',
          fontSize: '13px'
        }}
      >
        {isMember ? 'Already Joined' : squad.members.length >= squad.max_members ? 'Full' : 'Join Squad'}
      </button>
    </div>
  );
}
