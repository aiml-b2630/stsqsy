import React from 'react';
import { Volume2, Users, CheckCircle2, Clock, ShieldAlert } from 'lucide-react';

export function RoomCard({ room, onHold }) {
  const statusColors = {
    available: '#10b981',
    occupied: '#ef4444',
    reserved: '#f59e0b'
  };

  return (
    <div className="glass-card" style={{ padding: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
          <h3 style={{ margin: 0, fontSize: '18px' }}>{room.name}</h3>
          <span style={{
            background: `${statusColors[room.status]}20`,
            color: statusColors[room.status],
            padding: '4px 8px',
            borderRadius: '4px',
            fontSize: '12px',
            fontWeight: 'bold',
            textTransform: 'uppercase'
          }}>
            {room.status}
          </span>
        </div>
        <p style={{ margin: '0 0 12px 0', fontSize: '13px', color: 'var(--text-secondary)' }}>{room.building}</p>

        <div style={{ display: 'flex', gap: '16px', marginBottom: '14px', fontSize: '13px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Users size={16} color="var(--accent-blue)" />
            <span>{room.occupied_chairs} / {room.capacity} Seats</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Volume2 size={16} color={room.noise_db > 55 ? '#ef4444' : '#10b981'} />
            <span>{room.noise_db} dB</span>
          </div>
        </div>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '16px' }}>
          {(room.amenities || []).map((amenity, idx) => (
            <span key={idx} style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid var(--border-glass)', fontSize: '11px', padding: '3px 8px', borderRadius: '4px' }}>
              {amenity}
            </span>
          ))}
        </div>
      </div>

      <button
        onClick={() => onHold(room)}
        disabled={room.status !== 'available'}
        style={{
          width: '100%',
          padding: '10px',
          borderRadius: '6px',
          border: 'none',
          background: room.status === 'available' ? 'var(--accent-blue)' : 'rgba(255,255,255,0.1)',
          color: room.status === 'available' ? '#fff' : 'var(--text-secondary)',
          cursor: room.status === 'available' ? 'pointer' : 'not-allowed',
          fontWeight: 'bold',
          fontSize: '14px'
        }}
      >
        {room.status === 'available' ? 'Hold for 20 Mins' : room.status === 'reserved' ? 'On Hold' : 'Fully Occupied'}
      </button>
    </div>
  );
}
