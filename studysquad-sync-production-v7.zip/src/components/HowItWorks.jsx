import React from 'react';
import { MapPin, Users, Clock, ShieldCheck } from 'lucide-react';

export function HowItWorks() {
  return (
    <div style={{ maxWidth: '800px', margin: '0 auto' }}>
      <h2 style={{ textAlign: 'center', marginBottom: '24px' }}>How StudySquad Sync Works</h2>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px' }}>
        <div className="glass-card" style={{ padding: '20px', textAlign: 'center' }}>
          <MapPin size={32} color="var(--accent-blue)" style={{ marginBottom: '12px' }} />
          <h4>1. Room Radar Telemetry</h4>
          <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>Visualizes real-time decibel noise meters and seat availability across 12 campus discussion pods.</p>
        </div>

        <div className="glass-card" style={{ padding: '20px', textAlign: 'center' }}>
          <Clock size={32} color="#f59e0b" style={{ marginBottom: '12px' }} />
          <h4>2. 20-Minute Room Holds</h4>
          <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>Locks room availability while en route to prevent ghost bookings and arrival collisions.</p>
        </div>

        <div className="glass-card" style={{ padding: '20px', textAlign: 'center' }}>
          <Users size={32} color="var(--accent-indigo)" style={{ marginBottom: '12px' }} />
          <h4>3. Subject Squad Matcher</h4>
          <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>Pairs students using Jaccard subject vectors and discrete schedule overlap matrices.</p>
        </div>
      </div>
    </div>
  );
}
