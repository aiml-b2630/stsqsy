import React from 'react';
import { CheckCircle, AlertCircle, Info } from 'lucide-react';

export function Toast({ toast }) {
  if (!toast) return null;

  const bgColors = {
    success: 'rgba(16, 185, 129, 0.9)',
    warning: 'rgba(245, 158, 11, 0.9)',
    info: 'rgba(56, 189, 248, 0.9)'
  };

  return (
    <div style={{
      position: 'fixed',
      bottom: '24px',
      right: '24px',
      background: bgColors[toast.type] || bgColors.info,
      color: '#fff',
      padding: '12px 20px',
      borderRadius: '8px',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
      zIndex: 1000,
      animation: 'pulse 0.3s ease-in-out'
    }}>
      {toast.type === 'success' && <CheckCircle size={18} />}
      {toast.type === 'warning' && <AlertCircle size={18} />}
      {toast.type === 'info' && <Info size={18} />}
      <span style={{ fontSize: '14px', fontWeight: 500 }}>{toast.message}</span>
    </div>
  );
}
