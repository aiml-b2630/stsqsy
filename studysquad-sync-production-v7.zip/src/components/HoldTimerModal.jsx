import React from 'react';
import { useHoldTimer } from '../hooks/useHoldTimer';
import { Clock, ShieldCheck, XCircle } from 'lucide-react';

export function HoldTimerModal({ hold, onRelease }) {
  const { formattedTime, isExpired } = useHoldTimer(hold?.holdUntil, () => onRelease(hold.roomId));

  if (!hold) return null;

  return (
    <div style={{ position: 'fixed', bottom: '24px', left: '24px', zIndex: 900 }}>
      <div className="glass-card" style={{ padding: '20px', minWidth: '280px', borderLeft: '4px solid #f59e0b' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#f59e0b', fontWeight: 'bold' }}>
            <Clock size={18} className="pulse-animation" /> 20-Min Active Hold
          </div>
          <button onClick={() => onRelease(hold.roomId)} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer' }}>
            <XCircle size={16} />
          </button>
        </div>
        <div style={{ fontSize: '14px', fontWeight: 'bold' }}>{hold.roomName}</div>
        <div style={{ fontSize: '24px', fontWeight: 'bold', margin: '8px 0', color: '#38bdf8' }}>{formattedTime}</div>
        <p style={{ margin: 0, fontSize: '11px', color: 'var(--text-secondary)' }}>Auto-releases if unconfirmed on arrival.</p>
      </div>
    </div>
  );
}
