import React, { useState } from 'react';
import { RoomCard } from './RoomCard';
import { Filter, Search } from 'lucide-react';

export function RoomVisualizer({ rooms, onHoldRoom }) {
  const [search, setSearch] = useState('');
  const [filterAmenity, setFilterAmenity] = useState('ALL');
  const [filterBuilding, setFilterBuilding] = useState('ALL');

  const filtered = rooms.filter(r => {
    const matchesSearch = r.name.toLowerCase().includes(search.toLowerCase()) || r.building.toLowerCase().includes(search.toLowerCase());
    const matchesAmenity = filterAmenity === 'ALL' || (r.amenities && r.amenities.includes(filterAmenity));
    const matchesBuilding = filterBuilding === 'ALL' || r.building === filterBuilding;
    return matchesSearch && matchesAmenity && matchesBuilding;
  });

  return (
    <div>
      <div className="glass-card" style={{ padding: '16px', marginBottom: '24px', display: 'flex', gap: '16px', flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: '200px' }}>
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '12px', color: 'var(--text-secondary)' }} />
          <input
            type="text"
            placeholder="Search room or building..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ width: '100%', padding: '10px 10px 10px 36px', background: 'rgba(0,0,0,0.2)', border: '1px solid var(--border-glass)', color: '#fff', borderRadius: '6px' }}
          />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Filter size={16} color="var(--accent-blue)" />
          <select value={filterAmenity} onChange={e => setFilterAmenity(e.target.value)} style={{ background: '#1e293b', color: '#fff', border: '1px solid var(--border-glass)', padding: '10px', borderRadius: '6px' }}>
            <option value="ALL">All Amenities</option>
            <option value="Whiteboard">Whiteboard</option>
            <option value="Power Sockets">Power Sockets</option>
            <option value="Silent Zone">Silent Zone</option>
            <option value="Dual Monitors">Dual Monitors</option>
            <option value="Group Discussion">Group Discussion</option>
          </select>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '20px' }}>
        {filtered.map(room => (
          <RoomCard key={room.id} room={room} onHold={() => onHoldRoom(room.id)} />
        ))}
      </div>
    </div>
  );
}
