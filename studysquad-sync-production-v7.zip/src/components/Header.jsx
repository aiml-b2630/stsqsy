import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Shield, User, Users, MapPin, BookOpen } from 'lucide-react';

export function Header({ activeTab, setActiveTab }) {
  const { user, login } = useAuth();

  return (
    <header className="glass-card" style={{ padding: '16px 24px', margin: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <MapPin style={{ color: 'var(--accent-blue)', width: '28px', height: '28px' }} />
        <div>
          <h1 style={{ margin: 0, fontSize: '20px', fontWeight: 'bold' }}>StudySquad Sync</h1>
          <span style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>RoomRadar & Peer Squad Matcher (v7.0.0)</span>
        </div>
      </div>

      <nav style={{ display: 'flex', gap: '12px' }}>
        <button className={`nav-btn ${activeTab === 'radar' ? 'active' : ''}`} onClick={() => setActiveTab('radar')} style={{ background: activeTab === 'radar' ? 'var(--accent-blue)' : 'transparent', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          <MapPin size={16} /> Room Radar
        </button>
        <button className={`nav-btn ${activeTab === 'squads' ? 'active' : ''}`} onClick={() => setActiveTab('squads')} style={{ background: activeTab === 'squads' ? 'var(--accent-blue)' : 'transparent', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          <Users size={16} /> Study Squads
        </button>
        <button className={`nav-btn ${activeTab === 'how' ? 'active' : ''}`} onClick={() => setActiveTab('how')} style={{ background: activeTab === 'how' ? 'var(--accent-blue)' : 'transparent', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer' }}>
          <BookOpen size={16} /> How It Works
        </button>
      </nav>

      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div style={{ fontSize: '13px', textAlign: 'right' }}>
          <div style={{ fontWeight: 'bold' }}>{user ? user.username : 'Guest User'}</div>
          <div style={{ color: 'var(--text-secondary)', fontSize: '11px' }}>Role: {user ? user.role : 'Student'}</div>
        </div>
        <button onClick={() => login(user?.role === 'admin' ? 'Student Alex' : 'Room Admin Mark', user?.role === 'admin' ? 'student' : 'admin')} style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid var(--border-glass)', color: '#fff', padding: '6px 12px', borderRadius: '6px', cursor: 'pointer', fontSize: '12px' }}>
          <Shield size={14} /> Toggling Admin
        </button>
      </div>
    </header>
  );
}
