import React, { useState } from 'react';
import { validateSquadForm } from '../utils/validationSchemas';

export function CreateSquadModal({ isOpen, onClose, onCreate }) {
  const [form, setForm] = useState({ title: '', subject: '', max_members: 4, meeting_time: 'Afternoon' });
  const [errors, setErrors] = useState({});

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validateSquadForm(form);
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    onCreate(form);
    onClose();
  };

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
      <div className="glass-card" style={{ padding: '24px', width: '400px', background: '#1e293b' }}>
        <h3 style={{ margin: '0 0 16px 0' }}>Create New Study Squad</h3>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '12px' }}>
            <label style={{ fontSize: '12px', display: 'block', marginBottom: '4px' }}>Squad Title</label>
            <input type="text" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} style={{ width: '100%', padding: '8px', background: 'rgba(0,0,0,0.2)', border: '1px solid var(--border-glass)', color: '#fff', borderRadius: '4px' }} />
            {errors.title && <span style={{ color: '#ef4444', fontSize: '11px' }}>{errors.title}</span>}
          </div>
          <div style={{ marginBottom: '12px' }}>
            <label style={{ fontSize: '12px', display: 'block', marginBottom: '4px' }}>Subject Topic</label>
            <input type="text" value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })} style={{ width: '100%', padding: '8px', background: 'rgba(0,0,0,0.2)', border: '1px solid var(--border-glass)', color: '#fff', borderRadius: '4px' }} />
            {errors.subject && <span style={{ color: '#ef4444', fontSize: '11px' }}>{errors.subject}</span>}
          </div>
          <div style={{ marginBottom: '16px' }}>
            <label style={{ fontSize: '12px', display: 'block', marginBottom: '4px' }}>Max Members</label>
            <input type="number" min="2" max="20" value={form.max_members} onChange={e => setForm({ ...form, max_members: parseInt(e.target.value) })} style={{ width: '100%', padding: '8px', background: 'rgba(0,0,0,0.2)', border: '1px solid var(--border-glass)', color: '#fff', borderRadius: '4px' }} />
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
            <button type="button" onClick={onClose} style={{ background: 'transparent', border: '1px solid var(--border-glass)', color: '#fff', padding: '8px 16px', borderRadius: '4px' }}>Cancel</button>
            <button type="submit" style={{ background: 'var(--accent-blue)', border: 'none', color: '#fff', padding: '8px 16px', borderRadius: '4px', fontWeight: 'bold' }}>Create</button>
          </div>
        </form>
      </div>
    </div>
  );
}
