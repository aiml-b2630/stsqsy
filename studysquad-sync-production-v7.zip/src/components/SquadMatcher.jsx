import React, { useState } from 'react';
import { SquadCard } from './SquadCard';
import { matchSquads } from '../utils/matchingEngine';
import { Sparkles, Plus } from 'lucide-react';

export function SquadMatcher({ squads, onJoinSquad, onCreateClick }) {
  const [subject, setSubject] = useState('Operating Systems');
  const [schedule, setSchedule] = useState('Afternoon');

  const matched = matchSquads(subject, schedule, squads);

  return (
    <div>
      <div className="glass-card" style={{ padding: '20px', marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h3 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Sparkles size={20} color="var(--accent-blue)" /> AI Schedule & Subject Compatibility Matcher
          </h3>
          <button onClick={onCreateClick} style={{ background: 'var(--accent-blue)', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Plus size={16} /> Create Squad
          </button>
        </div>

        <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '200px' }}>
            <label style={{ fontSize: '12px', color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>Your Target Subject</label>
            <input type="text" value={subject} onChange={e => setSubject(e.target.value)} style={{ width: '100%', padding: '8px', background: 'rgba(0,0,0,0.2)', border: '1px solid var(--border-glass)', color: '#fff', borderRadius: '6px' }} />
          </div>
          <div style={{ flex: 1, minWidth: '200px' }}>
            <label style={{ fontSize: '12px', color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>Preferred Time Block</label>
            <select value={schedule} onChange={e => setSchedule(e.target.value)} style={{ width: '100%', padding: '8px', background: '#1e293b', border: '1px solid var(--border-glass)', color: '#fff', borderRadius: '6px' }}>
              <option value="Morning">Morning (8 AM - 12 PM)</option>
              <option value="Afternoon">Afternoon (12 PM - 5 PM)</option>
              <option value="Evening">Evening (5 PM - 8 PM)</option>
              <option value="Late Night">Late Night (8 PM - 12 AM)</option>
            </select>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '20px' }}>
        {matched.map(squad => (
          <SquadCard key={squad.id} squad={squad} onJoin={onJoinSquad} isMember={squad.members.includes('Current Student') || squad.members.includes('Alex Student')} />
        ))}
      </div>
    </div>
  );
}
