import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('StudySquad ErrorBoundary caught exception:', error, errorInfo);
  }

  handleReset = () => {
    localStorage.removeItem('studysquad_rooms');
    localStorage.removeItem('studysquad_squads');
    localStorage.removeItem('studysquad_hold');
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '40px', textAlign: 'center', background: '#1e293b', color: '#fff', borderRadius: '12px', margin: '40px' }}>
          <AlertTriangle size={48} style={{ color: '#ef4444', marginBottom: '16px' }} />
          <h2>Something went wrong in the application.</h2>
          <p style={{ color: '#94a3b8' }}>State corrupted or component render failure. Click below to reset state cache.</p>
          <button onClick={this.handleReset} style={{ background: '#38bdf8', border: 'none', color: '#fff', padding: '10px 20px', borderRadius: '6px', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
            <RefreshCw size={16} /> Reset Local State & Reload
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
