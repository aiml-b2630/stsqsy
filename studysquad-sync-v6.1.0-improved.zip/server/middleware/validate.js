import logger from '../logger.js';

export function sanitizeInput(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/[<>]/g, '').trim();
}

export function validateSquadCreation(req, res, next) {
  const { title, subject, max_members } = req.body;

  if (!title || typeof title !== 'string' || title.length < 3) {
    return res.status(400).json({ success: false, error: "Validation Error: Title must be at least 3 characters long." });
  }

  if (!subject || typeof subject !== 'string') {
    return res.status(400).json({ success: false, error: "Validation Error: Valid subject is required." });
  }

  if (!max_members || typeof max_members !== 'number' || max_members < 2 || max_members > 12) {
    return res.status(400).json({ success: false, error: "Validation Error: Group capacity must be between 2 and 12 members." });
  }

  req.body.title = sanitizeInput(title);
  req.body.subject = sanitizeInput(subject);
  next();
}
