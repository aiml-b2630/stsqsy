import { WebSocketServer, WebSocket } from 'ws';
import logger from './logger.js';

let socketServer;
export function attachRealtime(server, db) {
  socketServer = new WebSocketServer({ server, path: '/ws' });
  socketServer.on('connection', socket => {
    socket.send(JSON.stringify({ type: 'rooms:snapshot', rooms: db.getRooms() }));
    socket.on('error', error => logger.warn('WebSocket client error', { error: error.message }));
  });
  logger.info('Room occupancy WebSocket endpoint ready', { path: '/ws' });
  return socketServer;
}
export function broadcastRooms(db, type = 'rooms:updated') {
  if (!socketServer) return;
  const payload = JSON.stringify({ type, rooms: db.getRooms(), emitted_at: new Date().toISOString() });
  for (const client of socketServer.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(payload);
  }
}
