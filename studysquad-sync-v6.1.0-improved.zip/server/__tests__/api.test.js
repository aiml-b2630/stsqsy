import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import dotenv from 'dotenv';

dotenv.config();
process.env.DB_FILE = ':memory:';
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = process.env.JWT_SECRET && process.env.JWT_SECRET.length >= 32 ? process.env.JWT_SECRET : 'test_only_secret_value_32_chars_minimum_123456';
const { default: app } = await import('../server.js');

describe('StudySquad Sync Express API Integration Tests', () => {
  let authToken = '';

  it('GET /api/health should return OK status', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('OK');
    expect(res.body.version).toBe('6.1.0');
  });

  it('POST /api/auth/login should issue JWT token', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ username: 'AlexStudent', password: 'password123' });
    
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.token).toBeDefined();
    authToken = res.body.token;
  });

  it('GET /api/rooms should return campus room inventory', async () => {
    const res = await request(app).get('/api/rooms');
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(Array.isArray(res.body.rooms)).toBe(true);
  });

  it('POST /api/rooms/1/reserve without token should return 401', async () => {
    const res = await request(app)
      .post('/api/rooms/1/reserve')
      .send({ version: 1 });
    expect(res.status).toBe(401);
  });

  it('POST /api/rooms/1/reserve with token should succeed', async () => {
    const res = await request(app)
      .post('/api/rooms/1/reserve')
      .set('Authorization', `Bearer ${authToken}`)
      .send({ version: 1, duration_minutes: 20 });
    
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.room.status).toBe('reserved');
  });
});
