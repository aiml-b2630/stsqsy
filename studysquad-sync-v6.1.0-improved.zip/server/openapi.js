const openapi = {
  openapi: '3.0.3',
  info: { title: 'StudySquad Sync API', version: '6.1.0', description: 'REST API for campus study rooms, reservations, authentication, and study squads. Room changes are also published over WebSocket at /ws.' },
  servers: [{ url: '/api', description: 'Current server' }],
  components: {
    securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } },
    schemas: {
      Error: { type: 'object', properties: { success: { type: 'boolean', example: false }, error: { type: 'string' } } },
      Room: { type: 'object', properties: { id: { type: 'integer' }, name: { type: 'string' }, building: { type: 'string' }, floor: { type: 'string' }, capacity: { type: 'integer' }, occupied_chairs: { type: 'integer' }, noise_db: { type: 'integer' }, amenities: { type: 'array', items: { type: 'string' } }, status: { type: 'string', enum: ['available','occupied','reserved'] }, version: { type: 'integer' }, hold_until: { type: 'integer', nullable: true } } },
      Squad: { type: 'object', properties: { id: { type: 'integer' }, title: { type: 'string' }, subject: { type: 'string' }, creator: { type: 'string' }, max_members: { type: 'integer' }, current_members: { type: 'integer' }, schedule: { type: 'string' }, target_goal: { type: 'string' }, room_name: { type: 'string' } } }
    }
  },
  paths: {
    '/health': { get: { summary: 'API health check', responses: { 200: { description: 'Service is healthy' } } } },
    '/auth/login': { post: { summary: 'Issue an eight-hour JWT for a student session', requestBody: { required: true, content: { 'application/json': { schema: { type: 'object', required: ['username','password'], properties: { username: { type: 'string' }, password: { type: 'string', format: 'password' } } } } } }, responses: { 200: { description: 'JWT issued' }, 400: { description: 'Missing credentials', content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } } }, 500: { description: 'JWT_SECRET missing or invalid' } } } },
    '/rooms': { get: { summary: 'List campus rooms', responses: { 200: { description: 'Room inventory', content: { 'application/json': { schema: { type: 'object', properties: { success: { type: 'boolean' }, rooms: { type: 'array', items: { $ref: '#/components/schemas/Room' } } } } } } } } } },
    '/rooms/{id}/reserve': { post: { summary: 'Place a time-limited room hold using optimistic concurrency', security: [{ bearerAuth: [] }], parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], requestBody: { required: true, content: { 'application/json': { schema: { type: 'object', required: ['version'], properties: { version: { type: 'integer' }, duration_minutes: { type: 'integer', default: 20, minimum: 1, maximum: 120 } } } } } }, responses: { 200: { description: 'Room hold created' }, 401: { description: 'Authentication required' }, 409: { description: 'Room unavailable or version conflict' } } } },
    '/squads': { get: { summary: 'List study squads', responses: { 200: { description: 'Study squad list' } } }, post: { summary: 'Create a study squad', security: [{ bearerAuth: [] }], requestBody: { required: true, content: { 'application/json': { schema: { type: 'object', required: ['title','subject','max_members'], properties: { title: { type: 'string', minLength: 3 }, subject: { type: 'string' }, max_members: { type: 'integer', minimum: 2, maximum: 12 }, schedule: { type: 'string' }, target_goal: { type: 'string' }, room_name: { type: 'string' } } } } } }, responses: { 201: { description: 'Squad created' }, 400: { description: 'Validation error' }, 401: { description: 'Authentication required' } } } }
  }
};
export default openapi;
