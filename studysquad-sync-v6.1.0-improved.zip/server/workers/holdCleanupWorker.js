import db from '../db.js';
import logger from '../logger.js';

let intervalId = null;

export function startHoldCleanupWorker(intervalMs = 10000, onReleased = () => {}) {
  if (intervalId) return;

  logger.info("Starting background room hold cleanup worker service", { intervalMs });

  intervalId = setInterval(() => {
    try {
      const released = db.releaseExpiredHolds();
      if (released > 0) {
        logger.info(`Cleanup worker cycle complete: ${released} expired room hold(s) released to public status.`);
        onReleased();
      }
    } catch (err) {
      logger.error("Error running hold cleanup worker cycle", { error: err.message });
    }
  }, intervalMs);
}

export function stopHoldCleanupWorker() {
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
    logger.info("Background room hold cleanup worker service stopped.");
  }
}
