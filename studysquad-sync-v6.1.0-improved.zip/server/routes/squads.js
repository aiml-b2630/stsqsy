import express from 'express';
import db from '../db.js';
import { authenticateToken } from '../middleware/auth.js';
import { validateSquadCreation } from '../middleware/validate.js';
import logger from '../logger.js';

const router = express.Router();

router.get('/', (req, res) => {
  res.json({ success: true, squads: db.getSquads() });
});

router.post('/', authenticateToken, validateSquadCreation, (req, res) => {
  const newSquad = db.createSquad({
    ...req.body,
    creator: req.user.username || 'Student User'
  });
  res.status(201).json({ success: true, squad: newSquad });
});

export default router;
