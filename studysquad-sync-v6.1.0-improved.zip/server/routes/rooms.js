import express from 'express';
import db from '../db.js';
import { authenticateToken } from '../middleware/auth.js';
import logger from '../logger.js';
import { broadcastRooms } from '../realtime.js';

const router = express.Router();

router.get('/', (req, res) => {
  res.json({ success: true, rooms: db.getRooms() });
});

router.post('/:id/reserve', authenticateToken, (req, res) => {
  const roomId = req.params.id;
  const { version, duration_minutes = 20 } = req.body;

  if (version === undefined) {
    return res.status(400).json({ success: false, error: "Optimistic concurrency 'version' required." });
  }

  const holdUntilMs = Date.now() + (duration_minutes * 60 * 1000);
  const result = db.reserveRoom(roomId, version, holdUntilMs);

  if (!result.success) {
    return res.status(409).json(result);
  }

  broadcastRooms(db, 'rooms:updated');
  res.json({ success: true, room: result.room, message: `Room held for ${duration_minutes} minutes.` });
});

export default router;
