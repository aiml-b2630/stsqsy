import express from 'express';
import jwt from 'jsonwebtoken';
import logger from '../logger.js';

const router = express.Router();
function getJwtSecret() {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 32 || secret === 'replace_with_a_random_secret_at_least_32_characters') {
    const error = new Error('JWT_SECRET must be configured with a random value of at least 32 characters.');
    error.status = 500;
    throw error;
  }
  return secret;
}
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ success: false, error: 'Username and password required' });
  let jwtSecret;
  try { jwtSecret = getJwtSecret(); }
  catch (error) { logger.error('Authentication unavailable: JWT_SECRET is not configured'); return res.status(500).json({ success: false, error: 'Server security misconfiguration.' }); }
  const user = { id: 101, username, role: 'student', student_id: 'STUD-2026-99' };
  const token = jwt.sign(user, jwtSecret, { expiresIn: '8h' });
  logger.info('User logged in successfully', { username });
  res.json({ success: true, token, user });
});
export default router;
