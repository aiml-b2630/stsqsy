const API_BASE = '/api';

export async function fetchApi(endpoint, options = {}) {
  const token = localStorage.getItem('studysquad_token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
    ...options.headers
  };

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || 'API Request Failed');
  }
  return data;
}

export const api = {
  getRooms: () => fetchApi('/rooms'),
  reserveRoom: (id, version) => fetchApi(`/rooms/${id}/reserve`, {
    method: 'POST',
    body: JSON.stringify({ version, duration_minutes: 20 })
  }),
  getSquads: () => fetchApi('/squads'),
  createSquad: (squadData) => fetchApi('/squads', {
    method: 'POST',
    body: JSON.stringify(squadData)
  }),
  login: (username, password) => fetchApi('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password })
  })
};
