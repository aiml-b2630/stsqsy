export function tokenizeSubject(subjectStr) {
  return new Set(
    subjectStr.toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .split(/\s+/)
      .filter(w => w.length > 2)
  );
}

export function jaccardSimilarity(setA, setB) {
  if (setA.size === 0 || setB.size === 0) return 0;
  let intersection = 0;
  setA.forEach(val => { if (setB.has(val)) intersection++; });
  const union = new Set([...setA, ...setB]).size;
  return union === 0 ? 0 : intersection / union;
}

export function calculateSquadMatchScore(userProfile, squad) {
  const userSubjectTokens = tokenizeSubject(userProfile.subject || '');
  const squadSubjectTokens = tokenizeSubject(squad.subject || '');
  
  const subjectScore = jaccardSimilarity(userSubjectTokens, squadSubjectTokens);
  const scheduleScore = userProfile.schedule === squad.schedule ? 1.0 : 0.3;
  const capacityScore = squad.current_members < squad.max_members ? 1.0 : 0.0;
  
  const totalScore = (0.40 * scheduleScore) + (0.40 * subjectScore) + (0.20 * capacityScore);
  return Math.round(totalScore * 100);
}
