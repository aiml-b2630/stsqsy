export function sanitizeString(input) {
  if (typeof input !== 'string') return '';
  return input.replace(/[<>]/g, '').trim();
}

export function validateSquadInput(formData) {
  const errors = {};
  
  if (!formData.title || formData.title.trim().length < 3) {
    errors.title = "Title must be at least 3 characters long.";
  }
  
  if (!formData.subject || formData.subject.trim().length === 0) {
    errors.subject = "Subject selection is required.";
  }
  
  const size = Number(formData.max_members);
  if (isNaN(size) || size < 2 || size > 12) {
    errors.max_members = "Squad capacity must be between 2 and 12 members.";
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}
