import React, { useState } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import { SquadProvider } from './contexts/SquadContext';
import ErrorBoundary from './components/ErrorBoundary';
import Header from './components/Header';
import RoomVisualizer from './components/RoomVisualizer';
import SquadMatcher from './components/SquadMatcher';
import SquadWorkspace from './components/SquadWorkspace';
import HowItWorks from './components/HowItWorks';
import './styles/custom.css';

export default function App() {
  const [activeTab, setActiveTab] = useState('radar');
  const [theme, setTheme] = useState('dark');

  const toggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    document.documentElement.setAttribute('data-theme', nextTheme);
  };

  return (
    <ErrorBoundary>
      <AuthProvider>
        <SquadProvider>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: 24 }}>
            <Header activeTab={activeTab} setActiveTab={setActiveTab} theme={theme} toggleTheme={toggleTheme} />
            
            <main>
              {activeTab === 'radar' && <RoomVisualizer />}
              {activeTab === 'squads' && <SquadMatcher />}
              {activeTab === 'workspace' && <SquadWorkspace />}
              {activeTab === 'how' && <HowItWorks />}
            </main>
          </div>
        </SquadProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
