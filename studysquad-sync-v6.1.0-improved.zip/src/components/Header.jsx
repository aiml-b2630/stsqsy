import React from 'react';
import { Shield, Radio, Users, BookOpen, Clock, Moon, Sun } from 'lucide-react';

export default function Header({ activeTab, setActiveTab, theme, toggleTheme }) {
  return (
    <header className="glass-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <Radio style={{ color: 'var(--accent-blue)', width: 28, height: 28 }} />
        <div>
          <h1 style={{ margin: 0, fontSize: '1.4rem', fontWeight: 700, color: 'var(--text-primary)' }}>StudySquad Sync</h1>
          <p style={{ margin: 0, fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Smart Campus Room Radar & Peer Matching Engine</p>
        </div>
      </div>
      
      <nav style={{ display: 'flex', gap: 16 }}>
        <button 
          onClick={() => setActiveTab('radar')}
          style={{ padding: '8px 16px', borderRadius: 8, border: 'none', background: activeTab === 'radar' ? 'var(--accent-blue)' : 'transparent', color: activeTab === 'radar' ? '#fff' : 'var(--text-secondary)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}
        >
          <Radio size={16} /> Room Radar
        </button>
        <button 
          onClick={() => setActiveTab('squads')}
          style={{ padding: '8px 16px', borderRadius: 8, border: 'none', background: activeTab === 'squads' ? 'var(--accent-blue)' : 'transparent', color: activeTab === 'squads' ? '#fff' : 'var(--text-secondary)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}
        >
          <Users size={16} /> Study Squads
        </button>
        <button 
          onClick={() => setActiveTab('workspace')}
          style={{ padding: '8px 16px', borderRadius: 8, border: 'none', background: activeTab === 'workspace' ? 'var(--accent-blue)' : 'transparent', color: activeTab === 'workspace' ? '#fff' : 'var(--text-secondary)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}
        >
          <Clock size={16} /> Focus Workspace
        </button>
        <button 
          onClick={() => setActiveTab('how')}
          style={{ padding: '8px 16px', borderRadius: 8, border: 'none', background: activeTab === 'how' ? 'var(--accent-blue)' : 'transparent', color: activeTab === 'how' ? '#fff' : 'var(--text-secondary)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}
        >
          <BookOpen size={16} /> How It Works
        </button>
      </nav>

      <button onClick={toggleTheme} style={{ background: 'transparent', border: '1px solid var(--border-color)', color: 'var(--text-primary)', padding: 8, borderRadius: 8, cursor: 'pointer' }}>
        {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
      </button>
    </header>
  );
}
