import React from 'react';
import PomodoroTimer from './PomodoroTimer';
import StreakTracker from './StreakTracker';

export default function SquadWorkspace() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <div className="grid-responsive">
        <PomodoroTimer />
        <StreakTracker />
      </div>

      <div className="glass-card">
        <h3>Session Target Checklist</h3>
        <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <li style={{ display: 'flex', alignItems: 'center', gap: 10, color: 'var(--text-primary)' }}>
            <input type="checkbox" defaultChecked /> Review Chapter 5 Proofs
          </li>
          <li style={{ display: 'flex', alignItems: 'center', gap: 10, color: 'var(--text-primary)' }}>
            <input type="checkbox" defaultChecked /> Solve Practice Problem Set #3
          </li>
          <li style={{ display: 'flex', alignItems: 'center', gap: 10, color: 'var(--text-secondary)' }}>
            <input type="checkbox" /> Mock Exam Peer Review
          </li>
        </ul>
      </div>
    </div>
  );
}
