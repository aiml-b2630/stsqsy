import React from 'react';
import { useHoldTimer } from '../hooks/useHoldTimer';
import { Clock, CheckCircle, AlertTriangle } from 'lucide-react';

export default function HoldTimerModal({ activeHold, onRelease }) {
  if (!activeHold) return null;

  const { formatted, isExpired } = useHoldTimer(activeHold.holdUntil, () => {
    onRelease(activeHold.roomId);
  });

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 900 }}>
      <div className="glass-card" style={{ width: 400, textAlign: 'center', padding: 32 }}>
        <Clock size={48} style={{ color: 'var(--accent-emerald)', marginBottom: 16 }} />
        <h2 style={{ margin: 0 }}>Active Room Hold</h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: 20 }}>{activeHold.roomName}</p>

        <div style={{ fontSize: '3rem', fontWeight: 800, fontFamily: 'monospace', color: 'var(--accent-emerald)', marginBottom: 20 }}>
          {formatted}
        </div>

        <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: 24 }}>
          Please confirm your arrival at the room within 20 minutes. Ghost bookings automatically release to public status when the timer reaches 00:00.
        </p>

        <div style={{ display: 'flex', gap: 12 }}>
          <button onClick={() => onRelease(activeHold.roomId)} style={{ flex: 1, padding: 10, borderRadius: 8, border: 'none', background: '#ef4444', color: '#fff', cursor: 'pointer', fontWeight: 600 }}>
            Cancel Hold
          </button>
        </div>
      </div>
    </div>
  );
}
