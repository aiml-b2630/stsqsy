import React from 'react';
import { Volume2, Users, CheckCircle, Clock, ShieldAlert } from 'lucide-react';

export default function RoomCard({ room, onReserve }) {
  const badgeClass = room.status === 'available' ? 'badge-available' : room.status === 'reserved' ? 'badge-reserved' : 'badge-occupied';

  return (
    <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
          <div>
            <h3 style={{ margin: 0, fontSize: '1.1rem' }}>{room.name}</h3>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{room.building} ({room.floor})</span>
          </div>
          <span className={`badge ${badgeClass}`}>{room.status}</span>
        </div>

        <div style={{ display: 'flex', gap: 16, fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <Users size={14} /> {room.occupied_chairs} / {room.capacity} Chairs
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <Volume2 size={14} /> {room.noise_db} dB
          </div>
        </div>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
          {room.amenities.map((amenity, idx) => (
            <span key={idx} style={{ background: 'rgba(255,255,255,0.06)', fontSize: '0.75rem', padding: '2px 8px', borderRadius: 4, color: 'var(--text-secondary)' }}>
              {amenity}
            </span>
          ))}
        </div>
      </div>

      <button
        disabled={room.status !== 'available'}
        onClick={() => onReserve(room.id)}
        style={{
          width: '100%',
          padding: '10px 0',
          borderRadius: 8,
          border: 'none',
          background: room.status === 'available' ? 'var(--accent-blue)' : 'rgba(255,255,255,0.1)',
          color: room.status === 'available' ? '#fff' : 'var(--text-secondary)',
          cursor: room.status === 'available' ? 'pointer' : 'not-allowed',
          fontWeight: 600,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 8
        }}
      >
        <Clock size={16} /> {room.status === 'available' ? 'Place 20-Min Hold' : room.status === 'reserved' ? 'Room Held' : 'Room Occupied'}
      </button>
    </div>
  );
}
