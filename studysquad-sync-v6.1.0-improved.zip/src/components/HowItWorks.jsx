import React from 'react';
import { Radio, Shield, Users, Clock } from 'lucide-react';

export default function HowItWorks() {
  return (
    <div className="glass-card">
      <h2>How StudySquad Sync Works</h2>
      <p style={{ color: 'var(--text-secondary)' }}>Eliminating wasted hours spent hunting for vacant study spaces and compatible exam study partners.</p>

      <div className="grid-responsive" style={{ marginTop: 24 }}>
        <div style={{ background: 'rgba(255,255,255,0.03)', padding: 16, borderRadius: 8 }}>
          <Radio style={{ color: 'var(--accent-blue)', marginBottom: 8 }} size={28} />
          <h3>1. Live Room Radar</h3>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)' }}>View real-time campus library discussion room occupancy, occupied seat counts, and decibel (dB) noise meter telemetry.</p>
        </div>

        <div style={{ background: 'rgba(255,255,255,0.03)', padding: 16, borderRadius: 8 }}>
          <Clock style={{ color: 'var(--accent-emerald)', marginBottom: 8 }} size={28} />
          <h3>2. 20-Min Space Hold</h3>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)' }}>Place a 20-minute temporary reservation hold on an available room while walking to the library. Auto-released if unconfirmed.</p>
        </div>

        <div style={{ background: 'rgba(255,255,255,0.03)', padding: 16, borderRadius: 8 }}>
          <Users style={{ color: 'var(--accent-purple)', marginBottom: 8 }} size={28} />
          <h3>3. Heuristic Squad Matcher</h3>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)' }}>Form or join peer study squads paired by subject Jaccard vector similarity and schedule matrix compatibility.</p>
        </div>
      </div>
    </div>
  );
}
