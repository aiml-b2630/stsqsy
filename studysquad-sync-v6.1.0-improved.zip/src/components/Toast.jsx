import React from 'react';

export default function Toast({ message, type = 'info', onClose }) {
  if (!message) return null;
  
  const bg = type === 'error' ? '#ef4444' : type === 'success' ? '#10b981' : '#0284c7';

  return (
    <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 999, background: bg, color: '#fff', padding: '12px 20px', borderRadius: 8, boxShadow: '0 4px 12px rgba(0,0,0,0.3)', display: 'flex', alignItems: 'center', gap: 12 }}>
      <span>{message}</span>
      <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#fff', cursor: 'pointer', fontWeight: 'bold' }}>×</button>
    </div>
  );
}
