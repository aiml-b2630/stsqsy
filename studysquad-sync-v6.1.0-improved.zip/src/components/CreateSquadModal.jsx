import React, { useState } from 'react';
import { validateSquadInput } from '../utils/validationSchemas';

export default function CreateSquadModal({ isOpen, onClose, onCreate }) {
  const [formData, setFormData] = useState({
    title: '',
    subject: 'Computer Science',
    max_members: 4,
    schedule: 'Afternoon',
    target_goal: '',
    room_name: 'Library Pod A1'
  });
  const [errors, setErrors] = useState({});

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    const validation = validateSquadInput(formData);
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }

    onCreate(formData);
    onClose();
  };

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 900 }}>
      <div className="glass-card" style={{ width: 450, padding: 32 }}>
        <h2>Create Study Squad</h2>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16, marginTop: 16 }}>
          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Squad Title</label>
            <input
              type="text"
              value={formData.title}
              onChange={e => setFormData({ ...formData, title: e.target.value })}
              style={{ width: '100%', padding: 10, background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)' }}
            />
            {errors.title && <span style={{ color: '#ef4444', fontSize: '0.75rem' }}>{errors.title}</span>}
          </div>

          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Subject Domain</label>
            <input
              type="text"
              value={formData.subject}
              onChange={e => setFormData({ ...formData, subject: e.target.value })}
              style={{ width: '100%', padding: 10, background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)' }}
            />
          </div>

          <div style={{ display: 'flex', gap: 16 }}>
            <div style={{ flex: 1 }}>
              <label style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Max Members</label>
              <input
                type="number"
                value={formData.max_members}
                onChange={e => setFormData({ ...formData, max_members: Number(e.target.value) })}
                style={{ width: '100%', padding: 10, background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)' }}
              />
            </div>
            <div style={{ flex: 1 }}>
              <label style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Schedule</label>
              <select
                value={formData.schedule}
                onChange={e => setFormData({ ...formData, schedule: e.target.value })}
                style={{ width: '100%', padding: 10, background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)' }}
              >
                <option value="Morning">Morning</option>
                <option value="Afternoon">Afternoon</option>
                <option value="Late Night">Late Night</option>
              </select>
            </div>
          </div>

          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Target Session Goal</label>
            <input
              type="text"
              value={formData.target_goal}
              onChange={e => setFormData({ ...formData, target_goal: e.target.value })}
              placeholder="e.g. Solve Chapter 4 Practice Problems"
              style={{ width: '100%', padding: 10, background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)' }}
            />
          </div>

          <div style={{ display: 'flex', gap: 12, marginTop: 12 }}>
            <button type="button" onClick={onClose} style={{ flex: 1, padding: 10, background: 'transparent', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)', cursor: 'pointer' }}>Cancel</button>
            <button type="submit" style={{ flex: 1, padding: 10, background: 'var(--accent-blue)', border: 'none', borderRadius: 8, color: '#fff', cursor: 'pointer', fontWeight: 600 }}>Create Squad</button>
          </div>
        </form>
      </div>
    </div>
  );
}
