import React, { useState } from 'react';
import { useSquad } from '../contexts/SquadContext';
import RoomCard from './RoomCard';
import HoldTimerModal from './HoldTimerModal';
import { Search, Filter } from 'lucide-react';

export default function RoomVisualizer() {
  const { rooms, reserveRoomHold, activeHold, releaseHold } = useSquad();
  const [selectedAmenity, setSelectedAmenity] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredRooms = rooms.filter(room => {
    const matchesAmenity = selectedAmenity === 'All' || room.amenities.includes(selectedAmenity);
    const matchesSearch = room.name.toLowerCase().includes(searchQuery.toLowerCase()) || room.building.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesAmenity && matchesSearch;
  });

  return (
    <div>
      <div className="glass-card" style={{ marginBottom: 24, display: 'flex', flexWrap: 'wrap', gap: 16, alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'rgba(255,255,255,0.05)', padding: '8px 14px', borderRadius: 8, flex: 1, minWidth: 240 }}>
          <Search size={16} style={{ color: 'var(--text-secondary)' }} />
          <input
            type="text"
            placeholder="Search campus building or room name..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            style={{ background: 'none', border: 'none', color: 'var(--text-primary)', outline: 'none', width: '100%' }}
          />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Filter size={16} style={{ color: 'var(--text-secondary)' }} />
          <select
            value={selectedAmenity}
            onChange={e => setSelectedAmenity(e.target.value)}
            style={{ background: 'var(--bg-secondary)', color: 'var(--text-primary)', border: '1px solid var(--border-color)', padding: '8px 12px', borderRadius: 8 }}
          >
            <option value="All">All Amenities</option>
            <option value="Whiteboard">Whiteboard</option>
            <option value="Power Sockets">Power Sockets</option>
            <option value="Silent Zone">Silent Zone</option>
            <option value="Dual Monitors">Dual Monitors</option>
            <option value="Group Discussion">Group Discussion</option>
          </select>
        </div>
      </div>

      <div className="grid-responsive">
        {filteredRooms.map(room => (
          <RoomCard key={room.id} room={room} onReserve={reserveRoomHold} />
        ))}
      </div>

      <HoldTimerModal activeHold={activeHold} onRelease={releaseHold} />
    </div>
  );
}
