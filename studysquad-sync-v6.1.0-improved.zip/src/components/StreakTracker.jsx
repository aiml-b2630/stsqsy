import React from 'react';
import { Award, Flame } from 'lucide-react';

export default function StreakTracker() {
  return (
    <div className="glass-card" style={{ display: 'flex', alignItems: 'center', gap: 16, padding: 20 }}>
      <div style={{ background: 'rgba(245, 158, 11, 0.15)', padding: 12, borderRadius: 12, color: 'var(--status-reserved)' }}>
        <Flame size={32} />
      </div>
      <div>
        <div style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--text-primary)' }}>4-Day Study Streak</div>
        <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Completed 12 Pomodoro cycles together this week!</div>
      </div>
    </div>
  );
}
