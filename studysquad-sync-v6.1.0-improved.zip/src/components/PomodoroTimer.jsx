import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Award } from 'lucide-react';

export default function PomodoroTimer() {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState('focus'); // focus or break

  useEffect(() => {
    let interval = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    } else if (timeLeft === 0) {
      if (mode === 'focus') {
        setMode('break');
        setTimeLeft(5 * 60);
      } else {
        setMode('focus');
        setTimeLeft(25 * 60);
      }
      setIsRunning(false);
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft, mode]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="glass-card" style={{ textAlign: 'center', padding: 24 }}>
      <span className="badge" style={{ background: mode === 'focus' ? 'rgba(56, 189, 248, 0.15)' : 'rgba(54, 211, 153, 0.15)', color: mode === 'focus' ? 'var(--accent-blue)' : 'var(--accent-emerald)', marginBottom: 12 }}>
        {mode === 'focus' ? '25-Min Focus Cycle' : '5-Min Break Cycle'}
      </span>

      <div style={{ fontSize: '3.5rem', fontWeight: 800, fontFamily: 'monospace', color: 'var(--text-primary)', margin: '16px 0' }}>
        {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', gap: 12 }}>
        <button onClick={() => setIsRunning(!isRunning)} style={{ padding: '10px 20px', borderRadius: 8, border: 'none', background: 'var(--accent-blue)', color: '#fff', cursor: 'pointer', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6 }}>
          {isRunning ? <Pause size={16} /> : <Play size={16} />} {isRunning ? 'Pause' : 'Start Focus'}
        </button>
        <button onClick={() => { setIsRunning(false); setTimeLeft(25 * 60); setMode('focus'); }} style={{ padding: 10, borderRadius: 8, border: '1px solid var(--border-color)', background: 'transparent', color: 'var(--text-primary)', cursor: 'pointer' }}>
          <RotateCcw size={16} />
        </button>
      </div>
    </div>
  );
}
