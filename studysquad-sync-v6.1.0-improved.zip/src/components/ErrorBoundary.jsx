import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("ErrorBoundary caught an exception:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="glass-card" style={{ padding: 32, margin: 40, textAlign: 'center' }}>
          <h2 style={{ color: '#ef4444' }}>System Exception Intercepted</h2>
          <p style={{ color: 'var(--text-secondary)' }}>An unexpected rendering error occurred. State recovery initiated.</p>
          <button 
            onClick={() => { localStorage.clear(); window.location.reload(); }}
            style={{ padding: '10px 20px', background: 'var(--accent-blue)', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', marginTop: 16 }}
          >
            Reset Application State
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
