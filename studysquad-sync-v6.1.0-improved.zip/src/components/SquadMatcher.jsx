import React, { useState } from 'react';
import { useSquad } from '../contexts/SquadContext';
import SquadCard from './SquadCard';
import CreateSquadModal from './CreateSquadModal';
import { calculateSquadMatchScore } from '../utils/matchingEngine';
import { Plus, Sparkles } from 'lucide-react';

export default function SquadMatcher() {
  const { squads, createSquad } = useSquad();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [userProfile, setUserProfile] = useState({ subject: 'Mathematics', schedule: 'Afternoon' });

  return (
    <div>
      <div className="glass-card" style={{ marginBottom: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ margin: 0, fontSize: '1.2rem' }}>Subject Study Squad Matcher</h2>
          <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Weighted Jaccard subject vector & schedule overlap heuristic engine</p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          style={{ padding: '10px 18px', background: 'var(--accent-purple)', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8 }}
        >
          <Plus size={16} /> Create Study Squad
        </button>
      </div>

      <div className="grid-responsive">
        {squads.map(squad => {
          const matchScore = calculateSquadMatchScore(userProfile, squad);
          return (
            <SquadCard key={squad.id} squad={squad} userProfile={userProfile} matchScore={matchScore} />
          );
        })}
      </div>

      <CreateSquadModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onCreate={createSquad} />
    </div>
  );
}
