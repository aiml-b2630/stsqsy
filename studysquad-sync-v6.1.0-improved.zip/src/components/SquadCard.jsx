import React from 'react';
import { Users, BookOpen, Clock, MapPin } from 'lucide-react';

export default function SquadCard({ squad, userProfile, matchScore }) {
  return (
    <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
          <span className="badge" style={{ background: 'rgba(192, 132, 252, 0.15)', color: 'var(--accent-purple)' }}>
            {squad.subject}
          </span>
          {matchScore !== undefined && (
            <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--accent-emerald)', background: 'rgba(52, 211, 153, 0.15)', padding: '2px 8px', borderRadius: 12 }}>
              {matchScore}% Match
            </span>
          )}
        </div>

        <h3 style={{ margin: '8px 0', fontSize: '1.1rem' }}>{squad.title}</h3>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: 16 }}>{squad.target_goal}</p>

        <div style={{ display: 'flex', flexColumn: 'column', gap: 6, fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Clock size={14} /> Schedule: {squad.schedule}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <MapPin size={14} /> Room: {squad.room_name}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Users size={14} /> Roster: {squad.current_members} / {squad.max_members} Students
          </div>
        </div>
      </div>

      <button style={{ width: '100%', padding: '10px 0', borderRadius: 8, border: 'none', background: 'var(--accent-purple)', color: '#fff', cursor: 'pointer', fontWeight: 600 }}>
        Join Squad Workspace
      </button>
    </div>
  );
}
