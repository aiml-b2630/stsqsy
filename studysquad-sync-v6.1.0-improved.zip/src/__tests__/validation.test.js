import { describe, it, expect } from 'vitest';
import { sanitizeString, validateSquadInput } from '../utils/validationSchemas.js';

describe('Input Validation & Sanitization Tests', () => {
  it('sanitizeString should strip HTML tags and trim text', () => {
    const clean = sanitizeString('<script>alert("xss")</script>  Study Group  ');
    expect(clean).toBe('scriptalert("xss")/script  Study Group');
  });

  it('validateSquadInput should reject squad with title under 3 chars', () => {
    const res = validateSquadInput({ title: 'AB', subject: 'Math', max_members: 4 });
    expect(res.isValid).toBe(false);
    expect(res.errors.title).toBeDefined();
  });

  it('validateSquadInput should accept valid squad inputs', () => {
    const res = validateSquadInput({ title: 'GATE Revision Group', subject: 'Engineering', max_members: 5 });
    expect(res.isValid).toBe(true);
  });
});
