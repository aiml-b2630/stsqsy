import { describe, it, expect } from 'vitest';
import { jaccardSimilarity, tokenizeSubject, calculateSquadMatchScore } from '../utils/matchingEngine.js';

describe('Subject Matching Engine Unit Tests', () => {
  it('tokenizeSubject should parse and clean subject strings', () => {
    const tokens = tokenizeSubject('Linear Algebra & Calculus 2026!');
    expect(tokens.has('linear')).toBe(true);
    expect(tokens.has('algebra')).toBe(true);
    expect(tokens.has('calculus')).toBe(true);
  });

  it('jaccardSimilarity should compute similarity index between sets', () => {
    const setA = new Set(['operating', 'systems', 'cs']);
    const setB = new Set(['operating', 'systems', 'finals']);
    const sim = jaccardSimilarity(setA, setB);
    expect(sim).toBeGreaterThan(0.4);
  });

  it('calculateSquadMatchScore should return percentage score based on subject & schedule', () => {
    const user = { subject: 'Operating Systems', schedule: 'Afternoon' };
    const squad = { subject: 'Operating Systems Revision', schedule: 'Afternoon', current_members: 2, max_members: 4 };
    const score = calculateSquadMatchScore(user, squad);
    expect(score).toBeGreaterThan(70);
  });
});
