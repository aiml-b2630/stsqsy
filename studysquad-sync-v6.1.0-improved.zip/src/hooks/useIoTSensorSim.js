import { useEffect } from 'react';

export function useIoTSensorSim(rooms, setRooms) {
  useEffect(() => {
    const interval = setInterval(() => {
      setRooms(prevRooms => {
        return prevRooms.map(room => {
          if (room.status === 'occupied') {
            const noiseDelta = (Math.random() * 6) - 3;
            const newNoise = Math.min(75, Math.max(30, Math.round(room.noise_db + noiseDelta)));
            return { ...room, noise_db: newNoise };
          }
          return room;
        });
      });
    }, 6000);

    return () => clearInterval(interval);
  }, [setRooms]);
}
