import { useState, useEffect } from 'react';

export function useHoldTimer(targetTimestampMs, onExpire) {
  const [timeLeftMs, setTimeLeftMs] = useState(() => Math.max(0, targetTimestampMs - Date.now()));

  useEffect(() => {
    if (!targetTimestampMs) return;

    const timer = setInterval(() => {
      const remaining = Math.max(0, targetTimestampMs - Date.now());
      setTimeLeftMs(remaining);

      if (remaining === 0) {
        clearInterval(timer);
        if (onExpire) onExpire();
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [targetTimestampMs, onExpire]);

  const minutes = Math.floor(timeLeftMs / (1000 * 60));
  const seconds = Math.floor((timeLeftMs % (1000 * 60)) / 1000);

  return {
    timeLeftMs,
    formatted: `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`,
    isExpired: timeLeftMs === 0
  };
}
