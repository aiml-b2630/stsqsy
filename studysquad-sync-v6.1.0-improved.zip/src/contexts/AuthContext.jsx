import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState({ id: 101, username: 'AlexStudent', role: 'student' });
  const [token, setToken] = useState('mock-jwt-token-2026');

  return (
    <AuthContext.Provider value={{ user, token, isAuthenticated: !!token }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
