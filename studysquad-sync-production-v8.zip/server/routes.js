import { Router } from 'express';
import { getAllRooms, holdRoom, releaseHold } from './controllers/roomController.js';
import { getAllSquads, createSquad, joinSquad } from './controllers/squadController.js';
import { login } from './controllers/authController.js';
import { authenticateToken } from './middleware/auth.js';
import { validateHoldRequest, validateSquadCreation } from './middleware/validate.js';
import { occupancyStreamHandler } from './events/occupancyStream.js';

const router = Router();

// Auth route
router.post('/auth/login', login);

// Room routes
router.get('/rooms', getAllRooms);
router.post('/rooms/hold', authenticateToken, validateHoldRequest, holdRoom);
router.post('/rooms/release', authenticateToken, releaseHold);
router.get('/rooms/stream', occupancyStreamHandler);

// Squad routes
router.get('/squads', getAllSquads);
router.post('/squads', authenticateToken, validateSquadCreation, createSquad);
router.post('/squads/:squadId/join', authenticateToken, joinSquad);

export default router;
