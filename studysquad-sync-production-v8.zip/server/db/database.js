import sqlite3 from 'better-sqlite3';
import path from 'path';
import { logger } from '../logger.js';

const dbPath = process.env.DB_FILE || path.join(process.cwd(), 'studysquad.db');
const db = sqlite3(dbPath);

db.pragma('foreign_keys = ON');

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS rooms (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      building TEXT NOT NULL,
      capacity INTEGER NOT NULL,
      occupied_seats INTEGER DEFAULT 0,
      status TEXT CHECK(status IN ('Available', 'Occupied', 'Reserved')) DEFAULT 'Available',
      noise_db INTEGER DEFAULT 40,
      amenities TEXT NOT NULL,
      hold_until DATETIME,
      version INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS squads (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      subject TEXT NOT NULL,
      target_goal TEXT NOT NULL,
      schedule_block TEXT NOT NULL,
      max_size INTEGER NOT NULL,
      current_members INTEGER DEFAULT 1,
      room_id TEXT,
      created_by TEXT NOT NULL,
      streak_days INTEGER DEFAULT 1,
      FOREIGN KEY(room_id) REFERENCES rooms(id)
    );

    CREATE TABLE IF NOT EXISTS squad_members (
      id TEXT PRIMARY KEY,
      squad_id TEXT NOT NULL,
      user_name TEXT NOT NULL,
      joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(squad_id) REFERENCES squads(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status);
    CREATE INDEX IF NOT EXISTS idx_rooms_building ON rooms(building);
    CREATE INDEX IF NOT EXISTS idx_squads_subject ON squads(subject);
    CREATE INDEX IF NOT EXISTS idx_squad_members_squad ON squad_members(squad_id);
  `);

  // Seed sample campus spaces if empty
  const count = db.prepare('SELECT COUNT(*) as cnt FROM rooms').get().cnt;
  if (count === 0) {
    const seedRooms = [
      ['r1', 'Central Lib Pod 301', 'Central Library', 4, 1, 'Available', 38, 'Whiteboard,Power Sockets,Silent Zone', null, 1],
      ['r2', 'Central Lib Silent Room B', 'Central Library', 8, 8, 'Occupied', 32, 'Silent Zone,Power Sockets,Dual Monitors', null, 1],
      ['r3', 'Eng Block Room 102', 'Engineering Block', 6, 2, 'Available', 55, 'Whiteboard,Group Discussion,Power Sockets', null, 1],
      ['r4', 'Eng Block Tech Lab', 'Engineering Block', 5, 0, 'Available', 42, 'Dual Monitors,Power Sockets,Whiteboard', null, 1],
      ['r5', 'Student Union Room 4', 'Student Center', 10, 6, 'Available', 65, 'Group Discussion,Power Sockets', null, 1],
      ['r6', 'Science Wing Cubicle A', 'Science Block', 2, 1, 'Available', 35, 'Silent Zone,Power Sockets', null, 1],
      ['r7', 'Science Wing Cubicle B', 'Science Block', 2, 2, 'Occupied', 36, 'Silent Zone,Power Sockets', null, 1],
      ['r8', 'North Hall Discussion 1', 'North Complex', 6, 0, 'Available', 45, 'Whiteboard,Group Discussion', null, 1],
      ['r9', 'North Hall Discussion 2', 'North Complex', 6, 6, 'Occupied', 60, 'Whiteboard,Group Discussion', null, 1],
      ['r10', 'Law Library Quiet Room', 'Law Building', 4, 0, 'Available', 30, 'Silent Zone,Power Sockets', null, 1],
      ['r11', 'Graduate Study Lounge', 'Central Library', 12, 5, 'Available', 48, 'Dual Monitors,Power Sockets,Whiteboard', null, 1],
      ['r12', 'Campus Media Lab 3', 'Student Center', 4, 1, 'Available', 50, 'Dual Monitors,Power Sockets', null, 1]
    ];
    const insertRoom = db.prepare('INSERT INTO rooms VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    seedRooms.forEach(r => insertRoom.run(...r));
    logger.info('Database seeded with 12 campus study spaces.');
  }
}

export default db;
