import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import apiRoutes from './routes.js';
import { initDatabase } from './db/database.js';
import { startHoldCleanupWorker } from './workers/holdCleanupWorker.js';
import { logger } from './logger.js';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Initialize DB and Background Worker
initDatabase();
startHoldCleanupWorker(15000);

// API Documentation endpoint
app.get('/api/docs', (req, res) => {
  res.sendFile(path.join(__dirname, 'docs', 'swagger.json'));
});

// API Routes
app.use('/api', apiRoutes);

// Global Error Handler
app.use((err, req, res, next) => {
  logger.error('Unhandled Server Error', { error: err.message, stack: err.stack });
  res.status(500).json({ error: 'Internal Server Error' });
});

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    logger.info(`StudySquad Sync Production Server listening on port ${PORT}`);
  });
}

export default app;
