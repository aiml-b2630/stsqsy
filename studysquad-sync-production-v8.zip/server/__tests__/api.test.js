import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../index.js';
import db from '../db/database.js';

describe('StudySquad Sync Production API Integration Suite', () => {
  let authToken = '';

  beforeAll(() => {
    process.env.JWT_SECRET = 'super_secret_jwt_key_studysquad_2026_prod';
  });

  it('GET /api/rooms should return 12 campus study spaces', async () => {
    const res = await request(app).get('/api/rooms');
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBe(12);
  });

  it('POST /api/auth/login should issue valid JWT token', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ username: 'TestStudent', password: 'password123' });

    expect(res.status).toBe(200);
    expect(res.body.token).toBeDefined();
    authToken = res.body.token;
  });

  it('POST /api/rooms/hold without token should return 401 Unauthorized', async () => {
    const res = await request(app)
      .post('/api/rooms/hold')
      .send({ roomId: 'r1', expectedVersion: 1 });

    expect(res.status).toBe(401);
  });

  it('POST /api/rooms/hold with valid token and OCC version should grant hold', async () => {
    const res = await request(app)
      .post('/api/rooms/hold')
      .set('Authorization', `Bearer ${authToken}`)
      .send({ roomId: 'r1', expectedVersion: 1 });

    expect(res.status).toBe(200);
    expect(res.body.room.status).toBe('Reserved');
  });

  it('POST /api/rooms/hold with outdated OCC version should return 409 Conflict', async () => {
    const res = await request(app)
      .post('/api/rooms/hold')
      .set('Authorization', `Bearer ${authToken}`)
      .send({ roomId: 'r1', expectedVersion: 1 });

    expect(res.status).toBe(409);
    expect(res.body.error).toContain('Concurrency conflict');
  });
});
