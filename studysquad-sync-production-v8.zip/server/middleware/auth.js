import jwt from 'jsonwebtoken';
import { logger } from '../logger.js';

export function authenticateToken(req, res, next) {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    logger.error('CRITICAL: JWT_SECRET missing in environment variables.');
    return res.status(500).json({ error: 'Server security misconfiguration: JWT secret not set.' });
  }

  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Authentication token required.' });
  }

  jwt.verify(token, secret, (err, user) => {
    if (err) {
      logger.warn('JWT verification failed', { error: err.message });
      return res.status(403).json({ error: 'Invalid or expired token.' });
    }
    req.user = user;
    next();
  });
}
