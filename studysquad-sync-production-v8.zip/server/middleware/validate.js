import { logger } from '../logger.js';

export function validateHoldRequest(req, res, next) {
  const { roomId, expectedVersion } = req.body;
  if (!roomId || typeof roomId !== 'string') {
    return res.status(400).json({ error: 'Valid roomId is required.' });
  }
  if (typeof expectedVersion !== 'number') {
    return res.status(400).json({ error: 'expectedVersion numeric parameter required for OCC.' });
  }
  next();
}

export function validateSquadCreation(req, res, next) {
  const { title, subject, targetGoal, scheduleBlock, maxSize } = req.body;
  if (!title || !subject || !targetGoal || !scheduleBlock || !maxSize) {
    return res.status(400).json({ error: 'Missing required squad creation fields.' });
  }
  if (typeof maxSize !== 'number' || maxSize < 2 || maxSize > 10) {
    return res.status(400).json({ error: 'maxSize must be a number between 2 and 10.' });
  }
  next();
}
