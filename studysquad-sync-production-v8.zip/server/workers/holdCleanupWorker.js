import db from '../db/database.js';
import { logger } from '../logger.js';

export function startHoldCleanupWorker(intervalMs = 15000) {
  logger.info(`Starting background hold cleanup worker running every ${intervalMs}ms...`);
  
  setInterval(() => {
    try {
      const nowIso = new Date().toISOString();
      const expiredStmt = db.prepare(`
        UPDATE rooms
        SET status = 'Available', hold_until = NULL, version = version + 1
        WHERE status = 'Reserved' AND hold_until IS NOT NULL AND hold_until <= ?
      `);
      const result = expiredStmt.run(nowIso);
      if (result.changes > 0) {
        logger.info(`[Cleanup Worker] Released ${result.changes} expired room hold(s).`);
      }
    } catch (err) {
      logger.error('[Cleanup Worker Error]', { error: err.message });
    }
  }, intervalMs);
}
