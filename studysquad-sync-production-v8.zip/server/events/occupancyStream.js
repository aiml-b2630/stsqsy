import { logger } from '../logger.js';

const clients = new Set();

export function occupancyStreamHandler(req, res) {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  clients.add(res);
  logger.info('Client connected to occupancy SSE stream.', { totalClients: clients.size });

  req.on('close', () => {
    clients.delete(res);
    logger.info('Client disconnected from occupancy SSE stream.');
  });
}

export function broadcastOccupancyChange(roomData) {
  const payload = `data: ${JSON.stringify(roomData)}\n\n`;
  for (const client of clients) {
    client.write(payload);
  }
}
