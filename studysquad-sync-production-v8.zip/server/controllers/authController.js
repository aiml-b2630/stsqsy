import jwt from 'jsonwebtoken';
import { logger } from '../logger.js';

export function login(req, res) {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password required.' });
  }

  const secret = process.env.JWT_SECRET;
  if (!secret) {
    return res.status(500).json({ error: 'Server security misconfiguration: JWT secret not set.' });
  }

  const token = jwt.sign(
    { username, role: 'Student', campusId: 'STU_' + Math.floor(1000 + Math.random() * 9000) },
    secret,
    { expiresIn: '8h' }
  );

  logger.info('Authenticated user session generated', { username });
  res.json({
    message: 'Authentication successful',
    token,
    user: { username, role: 'Student' }
  });
}
