import db from '../db/database.js';
import { logger } from '../logger.js';
import { broadcastOccupancyChange } from '../events/occupancyStream.js';

export function getAllRooms(req, res) {
  try {
    const rooms = db.prepare('SELECT * FROM rooms').all();
    const formatted = rooms.map(r => ({
      ...r,
      amenities: r.amenities ? r.amenities.split(',') : []
    }));
    res.json(formatted);
  } catch (err) {
    logger.error('Failed to fetch rooms', { error: err.message });
    res.status(500).json({ error: 'Database query failed' });
  }
}

export function holdRoom(req, res) {
  try {
    const { roomId, expectedVersion } = req.body;
    const room = db.prepare('SELECT * FROM rooms WHERE id = ?').get(roomId);

    if (!room) {
      return res.status(404).json({ error: 'Room not found' });
    }

    if (room.status !== 'Available') {
      return res.status(409).json({ error: `Room is currently ${room.status}. Cannot place hold.` });
    }

    if (room.version !== expectedVersion) {
      logger.warn('OCC Conflict detected during room hold attempt', { roomId, expectedVersion, actualVersion: room.version });
      return res.status(409).json({
        error: 'Concurrency conflict: Room status was updated by another student. Please refresh.',
        currentVersion: room.version
      });
    }

    const holdUntil = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    const updateStmt = db.prepare(`
      UPDATE rooms
      SET status = 'Reserved', hold_until = ?, version = version + 1
      WHERE id = ? AND version = ?
    `);

    const result = updateStmt.run(holdUntil, roomId, expectedVersion);

    if (result.changes === 0) {
      return res.status(409).json({ error: 'Race condition conflict: Reservation failed.' });
    }

    const updatedRoom = db.prepare('SELECT * FROM rooms WHERE id = ?').get(roomId);
    updatedRoom.amenities = updatedRoom.amenities ? updatedRoom.amenities.split(',') : [];

    logger.info('Room hold successfully granted', { roomId, holdUntil, newVersion: updatedRoom.version });
    broadcastOccupancyChange(updatedRoom);

    res.json({
      message: '20-Minute room hold granted successfully!',
      room: updatedRoom,
      holdUntil
    });
  } catch (err) {
    logger.error('Failed to place room hold', { error: err.message });
    res.status(500).json({ error: 'Internal server error during room hold.' });
  }
}

export function releaseHold(req, res) {
  try {
    const { roomId } = req.body;
    const updateStmt = db.prepare(`
      UPDATE rooms
      SET status = 'Available', hold_until = NULL, version = version + 1
      WHERE id = ? AND status = 'Reserved'
    `);
    const result = updateStmt.run(roomId);
    if (result.changes === 0) {
      return res.status(400).json({ error: 'Room was not in reserved state.' });
    }
    const updatedRoom = db.prepare('SELECT * FROM rooms WHERE id = ?').get(roomId);
    broadcastOccupancyChange(updatedRoom);
    res.json({ message: 'Hold released successfully', room: updatedRoom });
  } catch (err) {
    res.status(500).json({ error: 'Failed to release room hold' });
  }
}
