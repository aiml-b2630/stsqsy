import db from '../db/database.js';
import { logger } from '../logger.js';

export function getAllSquads(req, res) {
  try {
    const squads = db.prepare('SELECT * FROM squads').all();
    const result = squads.map(s => {
      const members = db.prepare('SELECT user_name FROM squad_members WHERE squad_id = ?').all(s.id);
      return {
        ...s,
        members: members.map(m => m.user_name)
      };
    });
    res.json(result);
  } catch (err) {
    logger.error('Failed to fetch squads', { error: err.message });
    res.status(500).json({ error: 'Database query failed' });
  }
}

export function createSquad(req, res) {
  try {
    const { title, subject, targetGoal, scheduleBlock, maxSize, roomId } = req.body;
    const squadId = 'sq_' + Math.random().toString(36).substring(2, 9);
    const createdBy = req.user ? req.user.username : 'Student_User';

    const insertSquad = db.prepare(`
      INSERT INTO squads (id, title, subject, target_goal, schedule_block, max_size, current_members, room_id, created_by, streak_days)
      VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, 1)
    `);
    insertSquad.run(squadId, title, subject, targetGoal, scheduleBlock, maxSize, roomId || null, createdBy);

    const insertMember = db.prepare('INSERT INTO squad_members (id, squad_id, user_name) VALUES (?, ?, ?)');
    insertMember.run('sm_' + Math.random().toString(36).substring(2, 9), squadId, createdBy);

    logger.info('Created new study squad', { squadId, title, subject });
    res.status(201).json({
      message: 'Study Squad created successfully',
      squad: {
        id: squadId,
        title,
        subject,
        targetGoal,
        scheduleBlock,
        maxSize,
        currentMembers: 1,
        members: [createdBy],
        roomId,
        streakDays: 1
      }
    });
  } catch (err) {
    logger.error('Failed to create squad', { error: err.message });
    res.status(500).json({ error: 'Internal server error while creating squad' });
  }
}

export function joinSquad(req, res) {
  try {
    const { squadId } = req.params;
    const userName = req.user ? req.user.username : 'Student_Peer';

    const squad = db.prepare('SELECT * FROM squads WHERE id = ?').get(squadId);
    if (!squad) {
      return res.status(404).json({ error: 'Squad not found' });
    }

    if (squad.current_members >= squad.max_size) {
      return res.status(409).json({ error: 'Squad has reached maximum capacity.' });
    }

    const existing = db.prepare('SELECT * FROM squad_members WHERE squad_id = ? AND user_name = ?').get(squadId, userName);
    if (existing) {
      return res.status(400).json({ error: 'You are already a member of this squad.' });
    }

    db.prepare('INSERT INTO squad_members (id, squad_id, user_name) VALUES (?, ?, ?)').run(
      'sm_' + Math.random().toString(36).substring(2, 9), squadId, userName
    );

    db.prepare('UPDATE squads SET current_members = current_members + 1 WHERE id = ?').run(squadId);

    const members = db.prepare('SELECT user_name FROM squad_members WHERE squad_id = ?').all(squadId).map(m => m.user_name);
    
    logger.info('User joined squad', { squadId, userName });
    res.json({
      message: 'Successfully joined Study Squad!',
      squad: {
        ...squad,
        currentMembers: squad.current_members + 1,
        members
      }
    });
  } catch (err) {
    logger.error('Failed to join squad', { error: err.message });
    res.status(500).json({ error: 'Failed to join squad' });
  }
}
