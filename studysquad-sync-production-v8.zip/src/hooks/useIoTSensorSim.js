import { useEffect } from 'react';

export function useIoTSensorSim(rooms, setRooms, intervalMs = 6000) {
  useEffect(() => {
    const timer = setInterval(() => {
      setRooms(prevRooms =>
        prevRooms.map(room => {
          if (room.status === 'Reserved') return room;

          // Random noise fluctuation (+/- 3 dB)
          const dbDelta = Math.floor(Math.random() * 7) - 3;
          const newDb = Math.max(30, Math.min(75, room.noise_db + dbDelta));

          // Random occupancy shift (10% chance)
          let newOccupancy = room.occupied_seats;
          let newStatus = room.status;

          if (Math.random() < 0.15) {
            const shift = Math.random() > 0.5 ? 1 : -1;
            newOccupancy = Math.max(0, Math.min(room.capacity, room.occupied_seats + shift));
            newStatus = newOccupancy >= room.capacity ? 'Occupied' : 'Available';
          }

          return {
            ...room,
            noise_db: newDb,
            occupied_seats: newOccupancy,
            status: newStatus
          };
        })
      );
    }, intervalMs);

    return () => clearInterval(timer);
  }, [setRooms]);
}
