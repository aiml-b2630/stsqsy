import { useState, useEffect } from 'react';

export function useHoldTimer(holdUntilIso, onExpire) {
  const [secondsRemaining, setSecondsRemaining] = useState(0);

  useEffect(() => {
    if (!holdUntilIso) {
      setSecondsRemaining(0);
      return;
    }

    const calculateRemaining = () => {
      const diff = Math.max(0, Math.floor((new Date(holdUntilIso).getTime() - Date.now()) / 1000));
      setSecondsRemaining(diff);
      if (diff === 0 && onExpire) {
        onExpire();
      }
    };

    calculateRemaining();
    const interval = setInterval(calculateRemaining, 1000);
    return () => clearInterval(interval);
  }, [holdUntilIso, onExpire]);

  const minutes = Math.floor(secondsRemaining / 60);
  const seconds = secondsRemaining % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  return { secondsRemaining, formattedTime, isExpired: secondsRemaining === 0 };
}
