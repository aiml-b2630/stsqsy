import React from 'react';
import { Users, Calendar, MapPin, Award, CheckCircle } from 'lucide-react';

export function SquadCard({ squad, onJoin, isJoined }) {
  return (
    <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--accent-indigo)', fontWeight: 600 }}>{squad.subject}</span>
          {squad.matchPercentage && (
            <span className="badge badge-available" style={{ fontSize: '0.7rem' }}>
              {squad.matchPercentage}% Match
            </span>
          )}
        </div>

        <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '6px' }}>{squad.title}</h3>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '14px' }}>
          "{squad.target_goal}"
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Calendar size={14} />
            <span>Time Block: {squad.schedule_block}</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Users size={14} />
            <span>Roster: {squad.current_members} / {squad.max_size} Members ({squad.members.join(', ')})</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Award size={14} color="var(--accent-amber)" />
            <span>{squad.streak_days}-Day Peer Study Streak</span>
          </div>
        </div>
      </div>

      <div>
        {isJoined ? (
          <button className="btn btn-secondary" style={{ width: '100%', justifyContent: 'center', color: 'var(--accent-emerald)' }} disabled>
            <CheckCircle size={16} /> Joined & Active
          </button>
        ) : (
          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} onClick={() => onJoin(squad)}>
            <Users size={16} /> Join Study Squad
          </button>
        )}
      </div>
    </div>
  );
}
