import React, { useState } from 'react';
import { useSquad } from '../contexts/SquadContext';
import { validateSquadInput } from '../utils/validationSchemas';
import { X, PlusCircle } from 'lucide-react';

export function CreateSquadModal({ onClose }) {
  const { setSquads, setUserSquad, triggerToast } = useSquad();
  const [formData, setFormData] = useState({
    title: '',
    subject: 'Operating Systems',
    targetGoal: '',
    scheduleBlock: 'Afternoon',
    maxSize: 4
  });
  const [errors, setErrors] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();
    const result = validateSquadInput(formData);
    if (!result.isValid) {
      setErrors(result.errors);
      return;
    }

    const newSquad = {
      id: 'sq_' + Math.random().toString(36).substring(2, 9),
      title: result.sanitized.title,
      subject: result.sanitized.subject,
      target_goal: result.sanitized.targetGoal,
      schedule_block: result.sanitized.scheduleBlock,
      max_size: result.sanitized.maxSize,
      current_members: 1,
      members: ['You (Creator)'],
      streak_days: 1
    };

    setSquads(prev => [newSquad, ...prev]);
    setUserSquad(newSquad);
    triggerToast(`Created squad "${newSquad.title}"!`, 'success');
    onClose();
  };

  return (
    <div style={{
      position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
      background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000
    }}>
      <div className="glass-card" style={{ width: '100%', maxWidth: '500px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h3 style={{ fontSize: '1.2rem', fontWeight: 700 }}>Launch Study Squad</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer' }}>
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div>
            <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Squad Name</label>
            <input
              type="text"
              placeholder="e.g. OS Finals Review Group"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', color: 'var(--text-primary)', marginTop: '4px' }}
            />
            {errors.title && <span style={{ fontSize: '0.75rem', color: 'var(--accent-rose)' }}>{errors.title}</span>}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Subject</label>
              <select
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', color: 'var(--text-primary)', marginTop: '4px' }}
              >
                <option value="Operating Systems">Operating Systems</option>
                <option value="Linear Algebra">Linear Algebra</option>
                <option value="Algorithms">Algorithms</option>
                <option value="Computer Networks">Computer Networks</option>
              </select>
            </div>

            <div>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Time Block</label>
              <select
                value={formData.scheduleBlock}
                onChange={(e) => setFormData({ ...formData, scheduleBlock: e.target.value })}
                style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', color: 'var(--text-primary)', marginTop: '4px' }}
              >
                <option value="Morning">Morning (8 AM - 12 PM)</option>
                <option value="Afternoon">Afternoon (12 PM - 5 PM)</option>
                <option value="Evening">Evening (5 PM - 9 PM)</option>
                <option value="Late Night">Late Night (9 PM - 2 AM)</option>
              </select>
            </div>
          </div>

          <div>
            <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Target Study Goal</label>
            <input
              type="text"
              placeholder="e.g. Master Virtual Memory Paging"
              value={formData.targetGoal}
              onChange={(e) => setFormData({ ...formData, targetGoal: e.target.value })}
              style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', color: 'var(--text-primary)', marginTop: '4px' }}
            />
            {errors.targetGoal && <span style={{ fontSize: '0.75rem', color: 'var(--accent-rose)' }}>{errors.targetGoal}</span>}
          </div>

          <div>
            <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Max Group Capacity (2-10)</label>
            <input
              type="number"
              min="2"
              max="10"
              value={formData.maxSize}
              onChange={(e) => setFormData({ ...formData, maxSize: Number(e.target.value) })}
              style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', color: 'var(--text-primary)', marginTop: '4px' }}
            />
          </div>

          <button type="submit" className="btn btn-primary" style={{ marginTop: '8px', justifyContent: 'center' }}>
            <PlusCircle size={18} /> Launch Study Squad
          </button>
        </form>
      </div>
    </div>
  );
}
