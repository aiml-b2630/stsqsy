import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught exception:', error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '40px', textAlign: 'center', maxWidth: '600px', margin: '80px auto' }} className="glass-card">
          <AlertTriangle size={48} color="var(--accent-rose)" style={{ marginBottom: '16px' }} />
          <h2>Something went wrong in the component tree.</h2>
          <p style={{ color: 'var(--text-secondary)', margin: '12px 0 24px 0' }}>
            {this.state.error ? this.state.error.toString() : 'An unexpected error occurred.'}
          </p>
          <button className="btn btn-primary" onClick={this.handleReset}>
            <RefreshCw size={18} /> Recover & Reload Application
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
