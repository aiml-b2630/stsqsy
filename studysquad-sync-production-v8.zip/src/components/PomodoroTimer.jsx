import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Bell } from 'lucide-react';

export function PomodoroTimer() {
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState('focus'); // focus or break

  useEffect(() => {
    let interval = null;
    if (isActive && secondsLeft > 0) {
      interval = setInterval(() => setSecondsLeft(prev => prev - 1), 1000);
    } else if (secondsLeft === 0) {
      if (mode === 'focus') {
        setMode('break');
        setSecondsLeft(5 * 60);
      } else {
        setMode('focus');
        setSecondsLeft(25 * 60);
      }
      setIsActive(false);
    }
    return () => clearInterval(interval);
  }, [isActive, secondsLeft, mode]);

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const timeStr = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const resetTimer = () => {
    setIsActive(false);
    setMode('focus');
    setSecondsLeft(25 * 60);
  };

  return (
    <div style={{ textAlign: 'center' }}>
      <span className="badge badge-available" style={{ marginBottom: '12px' }}>
        {mode === 'focus' ? '🎯 25-Min Focus Sprint' : '☕ 5-Min Break Chime'}
      </span>

      <div style={{ fontSize: '3rem', fontWeight: 800, fontFamily: 'monospace', color: 'var(--accent-blue)', margin: '12px 0' }}>
        {timeStr}
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', gap: '12px' }}>
        <button className="btn btn-primary" onClick={() => setIsActive(!isActive)}>
          {isActive ? <Pause size={16} /> : <Play size={16} />}
          {isActive ? 'Pause' : 'Start Focus'}
        </button>
        <button className="btn btn-secondary" onClick={resetTimer}>
          <RotateCcw size={16} /> Reset
        </button>
      </div>
    </div>
  );
}
