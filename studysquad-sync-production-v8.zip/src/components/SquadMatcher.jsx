import React, { useState } from 'react';
import { useSquad } from '../contexts/SquadContext';
import { SquadCard } from './SquadCard';
import { CreateSquadModal } from './CreateSquadModal';
import { rankSquadsForUser } from '../utils/matchingEngine';
import { Plus, Sparkles, Filter } from 'lucide-react';

export function SquadMatcher() {
  const { squads, joinSquad, userSquad } = useSquad();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [subjectFilter, setSubjectFilter] = useState('All');

  const userProfile = {
    subjects: ['Operating Systems', 'Linear Algebra', 'Algorithms'],
    preferredSchedule: 'Afternoon',
    desiredAmenities: ['Whiteboard', 'Silent Zone']
  };

  const rankedSquads = rankSquadsForUser(userProfile, squads);
  const filteredSquads = subjectFilter === 'All'
    ? rankedSquads
    : rankedSquads.filter(s => s.subject === subjectFilter);

  return (
    <div>
      <div className="glass-card" style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Sparkles size={20} color="var(--accent-indigo)" />
              <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Peer Study Squad Matcher</h2>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
              Matched using weighted Jaccard subject similarity vector & schedule compatibility matrix
            </p>
          </div>
          <button className="btn btn-primary" onClick={() => setShowCreateModal(true)}>
            <Plus size={18} /> Create New Squad
          </button>
        </div>

        <div style={{ marginTop: '16px', display: 'flex', gap: '8px' }}>
          {['All', 'Operating Systems', 'Linear Algebra', 'Algorithms'].map(sub => (
            <button
              key={sub}
              className={`btn ${subjectFilter === sub ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.8rem', padding: '6px 14px' }}
              onClick={() => setSubjectFilter(sub)}
            >
              {sub}
            </button>
          ))}
        </div>
      </div>

      <div className="grid-layout">
        {filteredSquads.map(squad => (
          <SquadCard
            key={squad.id}
            squad={squad}
            onJoin={joinSquad}
            isJoined={userSquad && userSquad.id === squad.id}
          />
        ))}
      </div>

      {showCreateModal && <CreateSquadModal onClose={() => setShowCreateModal(false)} />}
    </div>
  );
}
