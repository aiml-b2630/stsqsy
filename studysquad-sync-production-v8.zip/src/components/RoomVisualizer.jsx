import React, { useState } from 'react';
import { useSquad } from '../contexts/SquadContext';
import { RoomCard } from './RoomCard';
import { HoldTimerModal } from './HoldTimerModal';
import { Filter, Search, RefreshCw, Activity } from 'lucide-react';

export function RoomVisualizer() {
  const { rooms, activeHold, placeRoomHold } = useSquad();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAmenity, setSelectedAmenity] = useState('All');
  const [maxNoise, setMaxNoise] = useState(75);

  const amenitiesList = ['All', 'Whiteboard', 'Power Sockets', 'Silent Zone', 'Group Discussion', 'Dual Monitors'];

  const filteredRooms = rooms.filter(room => {
    const matchesSearch = room.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          room.building.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAmenity = selectedAmenity === 'All' || (room.amenities && room.amenities.includes(selectedAmenity));
    const matchesNoise = room.noise_db <= maxNoise;
    return matchesSearch && matchesAmenity && matchesNoise;
  });

  return (
    <div>
      <div className="glass-card" style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <div>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Campus RoomRadar Occupancy Grid</h2>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Live telemetry updated via client-side IoT PIR motion sensors & dB decibel meters
            </p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.8rem', color: 'var(--accent-emerald)' }}>
            <Activity size={16} className="pulse-animation" />
            <span>PIR Telemetry Live</span>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 200px 200px', gap: '16px' }}>
          <div style={{ position: 'relative' }}>
            <Search size={18} style={{ position: 'absolute', left: '12px', top: '12px', color: 'var(--text-secondary)' }} />
            <input
              type="text"
              placeholder="Search library wings, blocks, or room names..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{
                width: '100%',
                padding: '10px 10px 10px 40px',
                borderRadius: '8px',
                background: 'var(--bg-secondary)',
                border: '1px solid var(--border-color)',
                color: 'var(--text-primary)'
              }}
            />
          </div>

          <div>
            <select
              value={selectedAmenity}
              onChange={(e) => setSelectedAmenity(e.target.value)}
              style={{
                width: '100%',
                padding: '10px',
                borderRadius: '8px',
                background: 'var(--bg-secondary)',
                border: '1px solid var(--border-color)',
                color: 'var(--text-primary)'
              }}
            >
              {amenitiesList.map(a => <option key={a} value={a}>{a === 'All' ? 'Filter by Amenity' : a}</option>)}
            </select>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <label style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
              Max Noise Level: {maxNoise} dB
            </label>
            <input
              type="range"
              min="30"
              max="75"
              value={maxNoise}
              onChange={(e) => setMaxNoise(Number(e.target.value))}
            />
          </div>
        </div>
      </div>

      <div className="grid-layout">
        {filteredRooms.map(room => (
          <RoomCard
            key={room.id}
            room={room}
            onHold={placeRoomHold}
            isHeld={activeHold && activeHold.room.id === room.id}
          />
        ))}
      </div>

      {activeHold && <HoldTimerModal />}
    </div>
  );
}
