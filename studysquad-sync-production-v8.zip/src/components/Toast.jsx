import React from 'react';
import { useSquad } from '../contexts/SquadContext';
import { CheckCircle, AlertCircle, Info } from 'lucide-react';

export function Toast() {
  const { toastMessage } = useSquad();
  if (!toastMessage) return null;

  const { msg, type } = toastMessage;
  const isSuccess = type === 'success';
  const isError = type === 'error';

  return (
    <div style={{
      position: 'fixed',
      bottom: '24px',
      right: '24px',
      zIndex: 9999,
      background: isSuccess ? 'rgba(16, 185, 129, 0.95)' : isError ? 'rgba(244, 63, 94, 0.95)' : 'rgba(56, 189, 248, 0.95)',
      color: 'white',
      padding: '12px 20px',
      borderRadius: '12px',
      boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      fontWeight: 600,
      backdropFilter: 'blur(8px)'
    }}>
      {isSuccess && <CheckCircle size={20} />}
      {isError && <AlertCircle size={20} />}
      {!isSuccess && !isError && <Info size={20} />}
      <span>{msg}</span>
    </div>
  );
}
