import React from 'react';
import { MapPin, Users, Volume2, ShieldAlert, Clock, Check } from 'lucide-react';

export function RoomCard({ room, onHold, isHeld }) {
  const isAvailable = room.status === 'Available';
  const isOccupied = room.status === 'Occupied';
  const isReserved = room.status === 'Reserved';

  return (
    <div className="glass-card" style={{ position: 'relative', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
          <div>
            <span style={{ fontSize: '0.75rem', color: 'var(--accent-blue)', fontWeight: 600 }}>{room.building}</span>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginTop: '2px' }}>{room.name}</h3>
          </div>
          <span className={`badge badge-${room.status.toLowerCase()}`}>
            {room.status}
          </span>
        </div>

        <div style={{ display: 'flex', gap: '16px', margin: '12px 0', fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Users size={16} />
            <span>{room.occupied_seats} / {room.capacity} Chairs</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Volume2 size={16} color={room.noise_db > 55 ? 'var(--accent-amber)' : 'var(--accent-emerald)'} />
            <span>{room.noise_db} dB</span>
          </div>
        </div>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '16px' }}>
          {room.amenities && room.amenities.map((amenity, idx) => (
            <span key={idx} style={{
              fontSize: '0.7rem',
              padding: '3px 8px',
              borderRadius: '6px',
              background: 'var(--bg-secondary)',
              color: 'var(--text-primary)',
              border: '1px solid var(--border-color)'
            }}>
              {amenity}
            </span>
          ))}
        </div>
      </div>

      <div>
        {isAvailable && (
          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} onClick={() => onHold(room)}>
            <Clock size={16} /> Hold Room (20 Min)
          </button>
        )}
        {isReserved && (
          <button className="btn btn-secondary" style={{ width: '100%', justifyContent: 'center', color: 'var(--accent-amber)', borderColor: 'var(--accent-amber)' }} disabled>
            <Check size={16} /> {isHeld ? 'Held by You' : 'Reserved'}
          </button>
        )}
        {isOccupied && (
          <button className="btn btn-secondary" style={{ width: '100%', justifyContent: 'center', opacity: 0.6 }} disabled>
            <ShieldAlert size={16} /> Room Full
          </button>
        )}
      </div>
    </div>
  );
}
