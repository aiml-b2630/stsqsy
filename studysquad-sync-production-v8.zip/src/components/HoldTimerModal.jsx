import React from 'react';
import { useSquad } from '../contexts/SquadContext';
import { useHoldTimer } from '../hooks/useHoldTimer';
import { Clock, Navigation, X } from 'lucide-react';

export function HoldTimerModal() {
  const { activeHold, releaseRoomHold } = useSquad();
  const { formattedTime, isExpired } = useHoldTimer(activeHold?.holdUntil, releaseRoomHold);

  if (!activeHold) return null;

  return (
    <div style={{
      position: 'fixed',
      bottom: '24px',
      left: '24px',
      zIndex: 900,
      maxWidth: '380px'
    }} className="glass-card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Clock className="pulse-animation" color="var(--accent-amber)" size={20} />
          <h4 style={{ fontSize: '1rem', fontWeight: 700 }}>20-Min En Route Room Hold</h4>
        </div>
        <button onClick={releaseRoomHold} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer' }}>
          <X size={18} />
        </button>
      </div>

      <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '12px' }}>
        Holding <strong>{activeHold.room.name}</strong> ({activeHold.room.building}). Confirm arrival before countdown expires to prevent ghost booking release.
      </p>

      <div style={{
        background: 'rgba(245, 158, 11, 0.1)',
        border: '1px solid var(--accent-amber)',
        borderRadius: '12px',
        padding: '12px',
        textAlign: 'center',
        marginBottom: '12px'
      }}>
        <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-amber)', fontFamily: 'monospace' }}>
          {formattedTime}
        </div>
        <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Remaining Time En Route</span>
      </div>

      <button className="btn btn-secondary" style={{ width: '100%', justifyContent: 'center', fontSize: '0.85rem' }} onClick={releaseRoomHold}>
        <Navigation size={14} /> Confirm Arrival / Release Hold
      </button>
    </div>
  );
}
