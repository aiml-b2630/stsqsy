import React from 'react';
import { Compass, Clock, Users, ShieldCheck } from 'lucide-react';

export function HowItWorks() {
  return (
    <div style={{ maxWidth: '800px', margin: '0 auto' }}>
      <div className="glass-card" style={{ marginBottom: '24px', textAlign: 'center' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 800, marginBottom: '8px' }}>StudySquad Sync Architecture</h2>
        <p style={{ color: 'var(--text-secondary)' }}>
          Eliminating wasted hours spent hunting vacant study spaces & finding compatible study partners.
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        <div className="glass-card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
            <Compass color="var(--accent-blue)" size={24} />
            <h3 style={{ fontSize: '1.1rem', fontWeight: 700 }}>1. RoomRadar Grid</h3>
          </div>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Visualizes real-world campus library study room occupancy and decibel noise levels (30–75 dB) using simulated IoT PIR motion sensor streams.
          </p>
        </div>

        <div className="glass-card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
            <Clock color="var(--accent-amber)" size={24} />
            <h3 style={{ fontSize: '1.1rem', fontWeight: 700 }}>2. 20-Min En Route Hold</h3>
          </div>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Places an active 20-minute reservation hold on an available room while walking across campus, featuring auto-release ghost booking prevention.
          </p>
        </div>

        <div className="glass-card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
            <Users color="var(--accent-indigo)" size={24} />
            <h3 style={{ fontSize: '1.1rem', fontWeight: 700 }}>3. Squad Matcher Engine</h3>
          </div>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Pairs peer students using a multi-factor weighted Jaccard similarity vector and discrete time block schedule matrix (Morning, Afternoon, Late Night).
          </p>
        </div>

        <div className="glass-card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
            <ShieldCheck color="var(--accent-emerald)" size={24} />
            <h3 style={{ fontSize: '1.1rem', fontWeight: 700 }}>4. Synchronized Workspace</h3>
          </div>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Provides a dedicated study group workspace with synchronized 25-minute Pomodoro focus timers, daily streak badges, and goal checklists.
          </p>
        </div>
      </div>
    </div>
  );
}
