import React from 'react';
import { Award, Flame, Calendar, Check } from 'lucide-react';

export function StreakTracker({ streakDays = 3 }) {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
        <Flame size={20} color="var(--accent-amber)" />
        <h4 style={{ fontSize: '1rem', fontWeight: 700 }}>Peer Study Streak: {streakDays} Days</h4>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', gap: '6px' }}>
        {days.map((day, idx) => (
          <div key={day} style={{
            flex: 1,
            textAlign: 'center',
            padding: '8px 4px',
            borderRadius: '8px',
            background: idx < streakDays ? 'rgba(16, 185, 129, 0.15)' : 'var(--bg-secondary)',
            border: idx < streakDays ? '1px solid var(--accent-emerald)' : '1px solid var(--border-color)'
          }}>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-secondary)' }}>{day}</div>
            <div style={{ marginTop: '4px', display: 'flex', justifyContent: 'center' }}>
              {idx < streakDays ? <Check size={14} color="var(--accent-emerald)" /> : <span style={{ fontSize: '0.7rem', opacity: 0.4 }}>•</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
