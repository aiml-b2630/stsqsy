import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useSquad } from '../contexts/SquadContext';
import { Compass, Users, Clock, Moon, Sun, BookOpen, ShieldCheck } from 'lucide-react';

export function Header({ activeTab, setActiveTab }) {
  const { theme, toggleTheme, user } = useAuth();
  const { activeHold } = useSquad();

  return (
    <header className="glass-card" style={{ borderRadius: '0 0 16px 16px', marginBottom: '24px', padding: '16px 32px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ background: 'linear-gradient(135deg, #38bdf8, #6366f1)', padding: '10px', borderRadius: '12px', display: 'flex' }}>
            <Compass color="white" size={24} />
          </div>
          <div>
            <h1 style={{ fontSize: '1.4rem', fontWeight: 700, letterSpacing: '-0.5px' }}>StudySquad Sync</h1>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Campus RoomRadar & Peer Matching System v8.0</p>
          </div>
        </div>

        <nav style={{ display: 'flex', gap: '8px' }}>
          <button className={`btn ${activeTab === 'radar' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setActiveTab('radar')}>
            <Compass size={18} /> RoomRadar
          </button>
          <button className={`btn ${activeTab === 'squads' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setActiveTab('squads')}>
            <Users size={18} /> Study Squads
          </button>
          <button className={`btn ${activeTab === 'workspace' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setActiveTab('workspace')}>
            <Clock size={18} /> Focus Workspace
          </button>
          <button className={`btn ${activeTab === 'how' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setActiveTab('how')}>
            <BookOpen size={18} /> How It Works
          </button>
        </nav>

        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          {activeHold && (
            <div className="badge badge-reserved pulse-animation" style={{ cursor: 'pointer' }} onClick={() => setActiveTab('radar')}>
              Hold Active: {activeHold.room.name}
            </div>
          )}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            <ShieldCheck size={16} color="var(--accent-emerald)" />
            <span>{user.username} ({user.role})</span>
          </div>
          <button className="btn btn-secondary" onClick={toggleTheme} style={{ padding: '8px' }}>
            {theme === 'dark' ? <Sun size={18} color="var(--accent-amber)" /> : <Moon size={18} color="var(--accent-indigo)" />}
          </button>
        </div>
      </div>
    </header>
  );
}
