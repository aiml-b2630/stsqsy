import React from 'react';
import { useSquad } from '../contexts/SquadContext';
import { PomodoroTimer } from './PomodoroTimer';
import { StreakTracker } from './StreakTracker';
import { Users, Target, MapPin, CheckSquare, Clock } from 'lucide-react';

export function SquadWorkspace() {
  const { userSquad, activeHold } = useSquad();

  if (!userSquad) {
    return (
      <div className="glass-card" style={{ textAlign: 'center', padding: '60px 20px' }}>
        <Users size={48} color="var(--accent-indigo)" style={{ marginBottom: '16px' }} />
        <h3>No Active Study Squad Selected</h3>
        <p style={{ color: 'var(--text-secondary)', marginTop: '8px' }}>
          Browse the Peer Study Squad Matcher tab to join or launch a squad.
        </p>
      </div>
    );
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '24px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        <div className="glass-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
            <div>
              <span style={{ fontSize: '0.75rem', color: 'var(--accent-blue)', fontWeight: 600 }}>{userSquad.subject}</span>
              <h2 style={{ fontSize: '1.4rem', fontWeight: 800 }}>{userSquad.title}</h2>
            </div>
            <span className="badge badge-available">Active Workspace</span>
          </div>

          <div style={{ display: 'flex', gap: '20px', margin: '16px 0', fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Target size={16} color="var(--accent-indigo)" />
              <span>Goal: {userSquad.target_goal}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <MapPin size={16} color="var(--accent-emerald)" />
              <span>Location: {activeHold ? activeHold.room.name : 'Eng Block Room 102'}</span>
            </div>
          </div>
        </div>

        <div className="glass-card">
          <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <CheckSquare size={18} color="var(--accent-emerald)" />
            Session Focus Agenda Checklist
          </h3>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {[
              'Review Chapter 5 Memory Paging concepts',
              'Solve Problem Set 4.2 (Virtual Memory Page Faults)',
              'Compare TLB hit rate calculations across peer solutions',
              'Summarize key takeaway notes for semester final'
            ].map((task, idx) => (
              <label key={idx} style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.9rem', cursor: 'pointer', padding: '8px', borderRadius: '8px', background: 'var(--bg-secondary)' }}>
                <input type="checkbox" defaultChecked={idx === 0} style={{ accentColor: 'var(--accent-emerald)' }} />
                <span>{task}</span>
              </label>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        <div className="glass-card">
          <PomodoroTimer />
        </div>

        <div className="glass-card">
          <StreakTracker streakDays={userSquad.streak_days || 3} />
        </div>

        <div className="glass-card">
          <h4 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Users size={16} /> Member Roster ({userSquad.members.length})
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {userSquad.members.map((member, idx) => (
              <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.85rem', padding: '6px 10px', borderRadius: '6px', background: 'var(--bg-secondary)' }}>
                <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--accent-emerald)' }}></div>
                <span>{member}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
