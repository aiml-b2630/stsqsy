import React, { useState } from 'react';
import { SquadProvider } from './contexts/SquadContext';
import { AuthProvider } from './contexts/AuthContext';
import { Header } from './components/Header';
import { Toast } from './components/Toast';
import { ErrorBoundary } from './components/ErrorBoundary';
import { RoomVisualizer } from './components/RoomVisualizer';
import { SquadMatcher } from './components/SquadMatcher';
import { SquadWorkspace } from './components/SquadWorkspace';
import { HowItWorks } from './components/HowItWorks';
import './styles/custom.css';

export function App() {
  const [activeTab, setActiveTab] = useState('radar');

  return (
    <ErrorBoundary>
      <AuthProvider>
        <SquadProvider>
          <div style={{ minHeight: '100vh', paddingBottom: '60px' }}>
            <Header activeTab={activeTab} setActiveTab={setActiveTab} />
            <main style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px' }}>
              {activeTab === 'radar' && <RoomVisualizer />}
              {activeTab === 'squads' && <SquadMatcher />}
              {activeTab === 'workspace' && <SquadWorkspace />}
              {activeTab === 'how' && <HowItWorks />}
            </main>
            <Toast />
          </div>
        </SquadProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;
