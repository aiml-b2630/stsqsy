export function sanitizeString(str) {
  if (typeof str !== 'string') return '';
  return str.replace(/[<>]/g, '').trim();
}

export function validateSquadInput(input) {
  const errors = {};
  const title = sanitizeString(input.title);
  const subject = sanitizeString(input.subject);
  const targetGoal = sanitizeString(input.targetGoal);

  if (!title || title.length < 3) errors.title = 'Title must be at least 3 characters.';
  if (!subject) errors.subject = 'Subject selection is required.';
  if (!targetGoal) errors.targetGoal = 'Target study goal is required.';
  if (!input.maxSize || input.maxSize < 2 || input.maxSize > 10) errors.maxSize = 'Max squad size must be between 2 and 10.';

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    sanitized: { ...input, title, subject, targetGoal }
  };
}
