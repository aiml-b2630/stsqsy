export function calculateJaccardSimilarity(setA, setB) {
  const unionSize = new Set([...setA, ...setB]).size;
  if (unionSize === 0) return 0;
  const intersectionSize = setA.filter(x => setB.includes(x)).length;
  return intersectionSize / unionSize;
}

export function calculateSquadMatchScore(userProfile, squad) {
  let score = 0;

  // 1. Subject Match (40% weight)
  const userSubjects = userProfile.subjects.map(s => s.toLowerCase());
  const squadSubject = squad.subject.toLowerCase();
  const subjectSimilarity = calculateJaccardSimilarity(userSubjects, [squadSubject]);
  score += subjectSimilarity * 0.40;

  // 2. Schedule Block Match (35% weight)
  if (userProfile.preferredSchedule === squad.schedule_block) {
    score += 0.35;
  }

  // 3. Amenity Preferences Match (15% weight)
  if (userProfile.desiredAmenities && squad.amenities) {
    const amenitySim = calculateJaccardSimilarity(userProfile.desiredAmenities, squad.amenities);
    score += amenitySim * 0.15;
  }

  // 4. Capacity Availability (10% weight)
  if (squad.current_members < squad.max_size) {
    score += 0.10;
  }

  return Math.round(score * 100);
}

export function rankSquadsForUser(userProfile, squadList) {
  return squadList
    .map(squad => ({
      ...squad,
      matchPercentage: calculateSquadMatchScore(userProfile, squad)
    }))
    .sort((a, b) => b.matchPercentage - a.matchPercentage);
}
