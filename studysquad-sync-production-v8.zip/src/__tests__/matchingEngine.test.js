import { describe, it, expect } from 'vitest';
import { calculateJaccardSimilarity, calculateSquadMatchScore, rankSquadsForUser } from '../utils/matchingEngine';

describe('Subject & Schedule Squad Matcher Heuristics', () => {
  it('calculateJaccardSimilarity should correctly compute intersection over union', () => {
    const setA = ['whiteboard', 'silent zone', 'power sockets'];
    const setB = ['silent zone', 'power sockets', 'dual monitors'];
    // Intersection: 2, Union: 4 => 0.5
    expect(calculateJaccardSimilarity(setA, setB)).toBe(0.5);
  });

  it('calculateSquadMatchScore should rank exact schedule and subject matches higher', () => {
    const user = {
      subjects: ['Operating Systems'],
      preferredSchedule: 'Afternoon',
      desiredAmenities: ['Whiteboard']
    };

    const squadMatch = {
      subject: 'Operating Systems',
      schedule_block: 'Afternoon',
      amenities: ['Whiteboard'],
      current_members: 2,
      max_size: 4
    };

    const squadMismatch = {
      subject: 'Literature',
      schedule_block: 'Morning',
      amenities: ['Dual Monitors'],
      current_members: 4,
      max_size: 4
    };

    const scoreMatch = calculateSquadMatchScore(user, squadMatch);
    const scoreMismatch = calculateSquadMatchScore(user, squadMismatch);

    expect(scoreMatch).toBeGreaterThan(scoreMismatch);
    expect(scoreMatch).toBeGreaterThanOrEqual(80);
  });
});
