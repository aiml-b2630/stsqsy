import React, { createContext, useContext, useState, useEffect } from 'react';
import { useIoTSensorSim } from '../hooks/useIoTSensorSim';

const SquadContext = createContext();

const initialRooms = [
  { id: 'r1', name: 'Central Lib Pod 301', building: 'Central Library', capacity: 4, occupied_seats: 1, status: 'Available', noise_db: 38, amenities: ['Whiteboard', 'Power Sockets', 'Silent Zone'], version: 1 },
  { id: 'r2', name: 'Central Lib Silent Room B', building: 'Central Library', capacity: 8, occupied_seats: 8, status: 'Occupied', noise_db: 32, amenities: ['Silent Zone', 'Power Sockets', 'Dual Monitors'], version: 1 },
  { id: 'r3', name: 'Eng Block Room 102', building: 'Engineering Block', capacity: 6, occupied_seats: 2, status: 'Available', noise_db: 55, amenities: ['Whiteboard', 'Group Discussion', 'Power Sockets'], version: 1 },
  { id: 'r4', name: 'Eng Block Tech Lab', building: 'Engineering Block', capacity: 5, occupied_seats: 0, status: 'Available', noise_db: 42, amenities: ['Dual Monitors', 'Power Sockets', 'Whiteboard'], version: 1 },
  { id: 'r5', name: 'Student Union Room 4', building: 'Student Center', capacity: 10, occupied_seats: 6, status: 'Available', noise_db: 65, amenities: ['Group Discussion', 'Power Sockets'], version: 1 },
  { id: 'r6', name: 'Science Wing Cubicle A', building: 'Science Block', capacity: 2, occupied_seats: 1, status: 'Available', noise_db: 35, amenities: ['Silent Zone', 'Power Sockets'], version: 1 }
];

const initialSquads = [
  { id: 'sq1', title: 'OS Finals Prep Squad', subject: 'Operating Systems', target_goal: 'Finish Memory Management & Virtual Memory Problem Sets', schedule_block: 'Afternoon', max_size: 4, current_members: 2, members: ['Alice_OS', 'Bob_Linux'], room_id: 'r3', streak_days: 3 },
  { id: 'sq2', title: 'Linear Algebra Problem Solving', subject: 'Linear Algebra', target_goal: 'Master Eigenvalues & Singular Value Decomposition', schedule_block: 'Morning', max_size: 5, current_members: 3, members: ['Charlie_Math', 'David_Matrix', 'Eva_Vectors'], room_id: 'r1', streak_days: 5 }
];

export function SquadProvider({ children }) {
  const [rooms, setRooms] = useState(initialRooms);
  const [squads, setSquads] = useState(initialSquads);
  const [activeHold, setActiveHold] = useState(null);
  const [userSquad, setUserSquad] = useState(initialSquads[0]);
  const [toastMessage, setToastMessage] = useState(null);

  useIoTSensorSim(rooms, setRooms);

  const triggerToast = (msg, type = 'info') => {
    setToastMessage({ msg, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const placeRoomHold = (room) => {
    if (room.status !== 'Available') {
      triggerToast(`Room ${room.name} is not available for hold.`, 'error');
      return;
    }
    const holdUntil = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    setRooms(prev => prev.map(r => r.id === room.id ? { ...r, status: 'Reserved', hold_until: holdUntil, version: r.version + 1 } : r));
    setActiveHold({ room, holdUntil });
    triggerToast(`20-Minute hold placed on ${room.name}!`, 'success');
  };

  const releaseRoomHold = () => {
    if (!activeHold) return;
    setRooms(prev => prev.map(r => r.id === activeHold.room.id ? { ...r, status: 'Available', hold_until: null, version: r.version + 1 } : r));
    setActiveHold(null);
    triggerToast('Room hold released.', 'info');
  };

  const joinSquad = (squad) => {
    if (squad.current_members >= squad.max_size) {
      triggerToast('Squad is full!', 'error');
      return;
    }
    const updated = { ...squad, current_members: squad.current_members + 1, members: [...squad.members, 'You (Student)'] };
    setSquads(prev => prev.map(s => s.id === squad.id ? updated : s));
    setUserSquad(updated);
    triggerToast(`Successfully joined ${squad.title}!`, 'success');
  };

  return (
    <SquadContext.Provider value={{
      rooms, squads, activeHold, userSquad, setUserSquad, placeRoomHold, releaseRoomHold, joinSquad, setSquads, toastMessage, triggerToast
    }}>
      {children}
    </SquadContext.Provider>
  );
}

export function useSquad() {
  return useContext(SquadContext);
}
