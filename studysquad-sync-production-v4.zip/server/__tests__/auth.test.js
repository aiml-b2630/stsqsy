import { describe, it, expect } from 'vitest';
import { signToken, verifyToken } from '../middleware/auth';

describe('HMAC-SHA256 JWT Authentication Middleware', () => {
  it('should sign and verify valid user payload', () => {
    const payload = { userId: 'usr_test123', role: 'student' };
    const token = signToken(payload);
    expect(token).toBeDefined();
    
    const verified = verifyToken(token);
    expect(verified.userId).toBe('usr_test123');
    expect(verified.role).toBe('student');
  });

  it('should reject tampered tokens', () => {
    const token = signToken({ userId: 'usr_test' });
    const tampered = token.slice(0, -4) + 'abcd';
    const verified = verifyToken(tampered);
    expect(verified).toBeNull();
  });
});
