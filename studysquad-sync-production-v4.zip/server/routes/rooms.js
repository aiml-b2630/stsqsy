import express from 'express';
import db from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

// GET all rooms
router.get('/', (req, res) => {
  db.all("SELECT * FROM rooms", [], (err, rows) => {
    if (err) return res.status(500).json({ success: false, error: err.message });
    res.json({ success: true, rooms: rows });
  });
});

// POST 20-minute temporary room hold with optimistic concurrency check
router.post('/:id/hold', requireAuth, (req, res) => {
  const roomId = req.params.id;
  const { version } = req.body; // Expected current version for concurrency check

  db.serialize(() => {
    db.get("SELECT * FROM rooms WHERE id = ?", [roomId], (err, room) => {
      if (err || !room) return res.status(404).json({ success: false, error: 'Room not found' });
      if (room.status === 'occupied') {
        return res.status(409).json({ success: false, error: 'Conflict: Room is currently occupied.' });
      }
      if (room.status === 'reserved') {
        return res.status(409).json({ success: false, error: 'Conflict: Room is already held by another student.' });
      }
      if (version !== undefined && room.version !== version) {
        return res.status(412).json({ success: false, error: 'Precondition Failed: Concurrency version mismatch. Room status changed.' });
      }

      const heldUntil = new Date(Date.now() + 20 * 60 * 1000).toISOString();
      const newVersion = room.version + 1;

      db.run(
        "UPDATE rooms SET status = 'reserved', heldUntil = ?, version = ? WHERE id = ? AND version = ?",
        [heldUntil, newVersion, roomId, room.version],
        function(updateErr) {
          if (updateErr || this.changes === 0) {
            return res.status(409).json({ success: false, error: 'Concurrency Conflict: Room was reserved simultaneously by another user.' });
          }
          res.json({
            success: true,
            message: '20-minute temporary hold placed successfully',
            room: { ...room, status: 'reserved', heldUntil, version: newVersion }
          });
        }
      );
    });
  });
});

// POST release room hold
router.post('/:id/release', requireAuth, (req, res) => {
  const roomId = req.params.id;
  db.run("UPDATE rooms SET status = 'available', heldUntil = NULL, version = version + 1 WHERE id = ?", [roomId], function(err) {
    if (err) return res.status(500).json({ success: false, error: err.message });
    res.json({ success: true, message: 'Room hold released' });
  });
});

export default router;
