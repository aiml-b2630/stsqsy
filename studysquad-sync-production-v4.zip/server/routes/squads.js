import express from 'express';
import db from '../db.js';
import { requireAuth } from '../middleware/auth.js';
import { validateSquadInput } from '../middleware/validation.js';

const router = express.Router();

router.get('/', (req, res) => {
  db.all("SELECT * FROM squads ORDER BY createdAt DESC", [], (err, squads) => {
    if (err) return res.status(500).json({ success: false, error: err.message });
    res.json({ success: true, squads });
  });
});

router.post('/', requireAuth, validateSquadInput, (req, res) => {
  const { title, subject, maxSize, schedule, meetingRoom, topicGoal, amenityPref } = req.body;
  const id = 'sq_' + Math.random().toString(36).substring(2, 9);
  const createdAt = new Date().toISOString();
  
  const stmt = db.prepare(`INSERT INTO squads (id, title, subject, creatorId, creatorName, maxSize, schedule, meetingRoom, topicGoal, amenityPref, streak, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`);
  stmt.run([id, title, subject, req.user.userId, req.user.name, maxSize, schedule || 'Afternoon', meetingRoom || 'Central Library', topicGoal || 'General Revision', amenityPref || 'Whiteboard', createdAt], function(err) {
    if (err) return res.status(500).json({ success: false, error: err.message });
    
    // Add creator to squad_members
    db.run("INSERT INTO squad_members (squadId, userId, userName, joinedAt) VALUES (?, ?, ?, ?)", [id, req.user.userId, req.user.name, createdAt]);

    res.json({
      success: true,
      squad: { id, title, subject, creatorId: req.user.userId, creatorName: req.user.name, maxSize, schedule, meetingRoom, topicGoal, amenityPref, streak: 1, createdAt }
    });
  });
});

router.post('/:id/join', requireAuth, (req, res) => {
  const squadId = req.params.id;
  const joinedAt = new Date().toISOString();
  
  db.get("SELECT COUNT(*) as memberCount FROM squad_members WHERE squadId = ?", [squadId], (err, row) => {
    if (err) return res.status(500).json({ success: false, error: err.message });
    
    db.get("SELECT maxSize FROM squads WHERE id = ?", [squadId], (err, squad) => {
      if (!squad) return res.status(404).json({ success: false, error: 'Squad not found' });
      if (row.memberCount >= squad.maxSize) {
        return res.status(400).json({ success: false, error: 'Squad is already full' });
      }

      db.run("INSERT OR IGNORE INTO squad_members (squadId, userId, userName, joinedAt) VALUES (?, ?, ?, ?)", [squadId, req.user.userId, req.user.name, joinedAt], function(joinErr) {
        if (joinErr) return res.status(500).json({ success: false, error: joinErr.message });
        res.json({ success: true, message: 'Joined squad successfully' });
      });
    });
  });
});

export default router;
