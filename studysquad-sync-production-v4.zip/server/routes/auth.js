import express from 'express';
import { signToken, verifyToken } from '../middleware/auth.js';
import db from '../db.js';

const router = express.Router();

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ success: false, error: 'Email and password required' });
  }

  // Simulated DB lookup / static check
  const role = email.includes('admin') ? 'admin' : 'student';
  const name = email.split('@')[0].replace('.', ' ').toUpperCase() || 'Campus Student';
  const userId = 'usr_' + Math.random().toString(36).substring(2, 9);
  
  const token = signToken({ userId, name, email, role });
  return res.json({
    success: true,
    token,
    user: { id: userId, name, email, role }
  });
});

router.get('/verify', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ success: false, error: 'No token provided' });
  const token = authHeader.split(' ')[1];
  const payload = verifyToken(token);
  if (!payload) return res.status(401).json({ success: false, error: 'Invalid or expired token' });
  res.json({ success: true, user: payload });
});

export default router;
