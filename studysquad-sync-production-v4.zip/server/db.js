import sqlite3 from 'sqlite3';
import path from 'path';
import dotenv from 'dotenv';
dotenv.config();

const dbPath = process.env.DATABASE_FILE || 'studysquad.sqlite';
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`PRAGMA foreign_keys = ON`);

  // Rooms table with optimistic concurrency control version column
  db.run(`CREATE TABLE IF NOT EXISTS rooms (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    building TEXT NOT NULL,
    capacity INTEGER NOT NULL,
    occupiedSeats INTEGER DEFAULT 0,
    noiseLevel INTEGER DEFAULT 40,
    status TEXT DEFAULT 'available',
    amenities TEXT NOT NULL,
    version INTEGER DEFAULT 1,
    heldUntil TEXT
  )`);

  // Users table
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    passwordHash TEXT NOT NULL,
    role TEXT DEFAULT 'student'
  )`);

  // Squads table
  db.run(`CREATE TABLE IF NOT EXISTS squads (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    subject TEXT NOT NULL,
    creatorId TEXT NOT NULL,
    creatorName TEXT NOT NULL,
    maxSize INTEGER NOT NULL,
    schedule TEXT NOT NULL,
    meetingRoom TEXT,
    topicGoal TEXT,
    amenityPref TEXT,
    streak INTEGER DEFAULT 1,
    createdAt TEXT NOT NULL
  )`);

  // Squad members join table
  db.run(`CREATE TABLE IF NOT EXISTS squad_members (
    squadId TEXT NOT NULL,
    userId TEXT NOT NULL,
    userName TEXT NOT NULL,
    joinedAt TEXT NOT NULL,
    PRIMARY KEY (squadId, userId)
  )`);

  // Seed default rooms if empty
  db.get("SELECT COUNT(*) as count FROM rooms", (err, row) => {
    if (row && row.count === 0) {
      const stmt = db.prepare(`INSERT INTO rooms (id, name, building, capacity, occupiedSeats, noiseLevel, status, amenities, version) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`);
      const initialRooms = [
        ['room-1', 'Central Discussion Pod #1', 'Central Library 3rd Floor', 4, 1, 38, 'available', 'Whiteboard, Power Sockets, Group Discussion'],
        ['room-2', 'Engineering Quiet Room #A', 'Engineering Block B', 2, 0, 32, 'available', 'Silent Zone, Power Sockets, Dual Monitors'],
        ['room-3', 'Science Collab Lab #3', 'Science Complex', 6, 6, 62, 'occupied', 'Whiteboard, Group Discussion, Power Sockets'],
        ['room-4', 'Graduate Research Pod', 'Central Library 4th Floor', 2, 1, 34, 'available', 'Silent Zone, Dual Monitors, Power Sockets'],
        ['room-5', 'Student Union Focus Lounge', 'Student Center 2nd Floor', 8, 3, 58, 'available', 'Group Discussion, Power Sockets, Whiteboard'],
        ['room-6', 'Math & Stats Study Suite', 'Science Complex', 4, 0, 36, 'available', 'Whiteboard, Power Sockets, Dual Monitors'],
        ['room-7', 'Campus Media Lab Pod #2', 'Main Library 2nd Floor', 4, 4, 65, 'occupied', 'Dual Monitors, Power Sockets, Group Discussion'],
        ['room-8', 'BioTech Quiet Alcove', 'Medical Sciences Block', 2, 0, 30, 'available', 'Silent Zone, Power Sockets'],
        ['room-9', 'CS Code Sprint Room #101', 'Engineering Block A', 6, 2, 45, 'available', 'Whiteboard, Dual Monitors, Power Sockets, Group Discussion'],
        ['room-10', 'Humanities Reading Circle', 'Old Campus Hall', 5, 0, 33, 'available', 'Silent Zone, Power Sockets'],
        ['room-11', 'Robotics Team Collab Suite', 'Engineering Innovation Wing', 8, 7, 68, 'occupied', 'Whiteboard, Power Sockets, Group Discussion'],
        ['room-12', 'Physics Problem Solving Pod', 'Science Complex', 3, 0, 35, 'available', 'Whiteboard, Power Sockets']
      ];
      initialRooms.forEach(r => stmt.run(r));
      stmt.finalize();
    }
  });
});

export default db;
