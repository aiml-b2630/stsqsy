export function sanitizeInput(str) {
  if (typeof str !== 'string') return '';
  return str.replace(/[<>'"]/g, '').trim();
}

export function validateSquadInput(req, res, next) {
  let { title, subject, maxSize, schedule } = req.body;
  title = sanitizeInput(title);
  subject = sanitizeInput(subject);
  if (!title || title.length < 3) {
    return res.status(400).json({ success: false, error: 'Validation Error: Squad title must be at least 3 characters long.' });
  }
  if (!subject) {
    return res.status(400).json({ success: false, error: 'Validation Error: Subject topic is required.' });
  }
  if (!maxSize || Number(maxSize) < 2 || Number(maxSize) > 12) {
    return res.status(400).json({ success: false, error: 'Validation Error: Squad capacity must be between 2 and 12.' });
  }
  req.body.title = title;
  req.body.subject = subject;
  next();
}
