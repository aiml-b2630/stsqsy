import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.js';
import roomRoutes from './routes/rooms.js';
import squadRoutes from './routes/squads.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/squads', squadRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'StudySquad Sync REST API v4.0.0', db: 'SQLite3' });
});

app.use((err, req, res, next) => {
  console.error('[Server Error]', err);
  res.status(500).json({ success: false, error: 'Internal Server Error: ' + err.message });
});

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    console.log(`StudySquad Sync v4 Server listening on port ${PORT}`);
  });
}

export default app;
