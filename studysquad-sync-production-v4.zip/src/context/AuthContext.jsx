import React, { createContext, useContext, useState, useEffect } from 'react';
import { fetchApi } from '../services/api';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState({ id: 'usr_student', name: 'Alex Rivera (CS Senior)', role: 'student' });
  const [token, setToken] = useState(localStorage.getItem('studysquad_jwt_token') || 'mock_token');
  const [isAuthenticated, setIsAuthenticated] = useState(true);

  useEffect(() => {
    if (token) {
      fetchApi('/auth/verify')
        .then(res => {
          if (res.user) setUser(res.user);
        })
        .catch(() => {
          // fallback to client user state
        });
    }
  }, [token]);

  const login = async (email, password) => {
    try {
      const res = await fetchApi('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
      if (res.token) {
        setToken(res.token);
        setUser(res.user);
        localStorage.setItem('studysquad_jwt_token', res.token);
        setIsAuthenticated(true);
      }
      return res;
    } catch (err) {
      // client-side demo authentication mode fallback
      const mockUser = { id: 'usr_' + Date.now(), name: email.split('@')[0] || 'Student User', role: email.includes('admin') ? 'admin' : 'student' };
      setUser(mockUser);
      setIsAuthenticated(true);
      return { success: true, user: mockUser };
    }
  };

  const toggleRole = () => {
    setUser(prev => ({
      ...prev,
      role: prev.role === 'student' ? 'admin' : 'student'
    }));
  };

  return (
    <AuthContext.Provider value={{ user, token, isAuthenticated, login, toggleRole }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
