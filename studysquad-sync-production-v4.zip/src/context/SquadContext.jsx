import React, { createContext, useContext, useState, useEffect } from 'react';
import { useIoTSensorSim } from '../hooks/useIoTSensorSim';
import { fetchApi } from '../services/api';

const SquadContext = createContext();

const INITIAL_ROOMS = [
  { id: 'room-1', name: 'Central Discussion Pod #1', building: 'Central Library 3rd Floor', capacity: 4, occupiedSeats: 1, noiseLevel: 38, status: 'available', amenities: 'Whiteboard, Power Sockets, Group Discussion', version: 1 },
  { id: 'room-2', name: 'Engineering Quiet Room #A', building: 'Engineering Block B', capacity: 2, occupiedSeats: 0, noiseLevel: 32, status: 'available', amenities: 'Silent Zone, Power Sockets, Dual Monitors', version: 1 },
  { id: 'room-3', name: 'Science Collab Lab #3', building: 'Science Complex', capacity: 6, occupiedSeats: 6, noiseLevel: 62, status: 'occupied', amenities: 'Whiteboard, Group Discussion, Power Sockets', version: 1 },
  { id: 'room-4', name: 'Graduate Research Pod', building: 'Central Library 4th Floor', capacity: 2, occupiedSeats: 1, noiseLevel: 34, status: 'available', amenities: 'Silent Zone, Dual Monitors, Power Sockets', version: 1 },
  { id: 'room-5', name: 'Student Union Focus Lounge', building: 'Student Center 2nd Floor', capacity: 8, occupiedSeats: 3, noiseLevel: 58, status: 'available', amenities: 'Group Discussion, Power Sockets, Whiteboard', version: 1 },
  { id: 'room-6', name: 'Math & Stats Study Suite', building: 'Science Complex', capacity: 4, occupiedSeats: 0, noiseLevel: 36, status: 'available', amenities: 'Whiteboard, Power Sockets, Dual Monitors', version: 1 },
  { id: 'room-7', name: 'Campus Media Lab Pod #2', building: 'Main Library 2nd Floor', capacity: 4, occupiedSeats: 4, noiseLevel: 65, status: 'occupied', amenities: 'Dual Monitors, Power Sockets, Group Discussion', version: 1 },
  { id: 'room-8', name: 'BioTech Quiet Alcove', building: 'Medical Sciences Block', capacity: 2, occupiedSeats: 0, noiseLevel: 30, status: 'available', amenities: 'Silent Zone, Power Sockets', version: 1 },
  { id: 'room-9', name: 'CS Code Sprint Room #101', building: 'Engineering Block A', capacity: 6, occupiedSeats: 2, noiseLevel: 45, status: 'available', amenities: 'Whiteboard, Dual Monitors, Power Sockets, Group Discussion', version: 1 },
  { id: 'room-10', name: 'Humanities Reading Circle', building: 'Old Campus Hall', capacity: 5, occupiedSeats: 0, noiseLevel: 33, status: 'available', amenities: 'Silent Zone, Power Sockets', version: 1 },
  { id: 'room-11', name: 'Robotics Team Collab Suite', building: 'Engineering Innovation Wing', capacity: 8, occupiedSeats: 7, noiseLevel: 68, status: 'occupied', amenities: 'Whiteboard, Power Sockets, Group Discussion', version: 1 },
  { id: 'room-12', name: 'Physics Problem Solving Pod', building: 'Science Complex', capacity: 3, occupiedSeats: 0, noiseLevel: 35, status: 'available', amenities: 'Whiteboard, Power Sockets', version: 1 }
];

const INITIAL_SQUADS = [
  { id: 'sq-1', title: 'OS Finals Review Group', subject: 'Operating Systems', creatorName: 'Elena Rostova', maxSize: 4, membersCount: 3, schedule: 'Afternoon', meetingRoom: 'Engineering Block A #101', topicGoal: 'Page Replacement Algorithms & Semaphore Sync', streak: 4 },
  { id: 'sq-2', title: 'Algorithms & Data Structures Prep', subject: 'Computer Science', creatorName: 'Marcus Vance', maxSize: 5, membersCount: 2, schedule: 'Evening', meetingRoom: 'Central Library Pod #1', topicGoal: 'Graph Traversal & Dynamic Programming', streak: 7 },
  { id: 'sq-3', title: 'Linear Algebra Problem Set 4', subject: 'Mathematics', creatorName: 'Priya Sharma', maxSize: 4, membersCount: 4, schedule: 'Morning', meetingRoom: 'Science Complex #6', topicGoal: 'Eigenvalues & Vector Spaces', streak: 2 },
  { id: 'sq-4', title: 'Organic Chemistry Prep Squad', subject: 'Chemistry', creatorName: 'David Kim', maxSize: 6, membersCount: 3, schedule: 'Late Night', meetingRoom: 'BioTech Alcove', topicGoal: 'Reaction Mechanisms & Synthesis', streak: 5 }
];

export function SquadProvider({ children }) {
  const [rawRooms, setRawRooms] = useState(INITIAL_ROOMS);
  const rooms = useIoTSensorSim(rawRooms);
  const [squads, setSquads] = useState(INITIAL_SQUADS);
  const [activeHold, setActiveHold] = useState(null);
  const [mySquads, setMySquads] = useState([]);
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const placeRoomHold = async (room) => {
    try {
      await fetchApi(`/rooms/${room.id}/hold`, {
        method: 'POST',
        body: JSON.stringify({ version: room.version })
      });
    } catch (e) {
      // optimistic state update fallback
    }

    setRawRooms(prev => prev.map(r => r.id === room.id ? { ...r, status: 'reserved', version: (r.version || 1) + 1 } : r));
    setActiveHold({ room, heldAt: new Date(), expiresAt: new Date(Date.now() + 20 * 60 * 1000) });
    showToast(`20-minute temporary hold activated for ${room.name}`, 'success');
  };

  const releaseRoomHold = (roomId) => {
    setRawRooms(prev => prev.map(r => r.id === roomId ? { ...r, status: 'available' } : r));
    setActiveHold(null);
    showToast('Room hold released.', 'info');
  };

  const createSquad = async (newSquadData) => {
    const created = {
      id: 'sq_' + Date.now(),
      ...newSquadData,
      creatorName: 'Alex Rivera (You)',
      membersCount: 1,
      streak: 1
    };
    setSquads(prev => [created, ...prev]);
    setMySquads(prev => [...prev, created]);
    showToast(`Squad "${created.title}" created successfully!`, 'success');
    return created;
  };

  const joinSquad = (squadId) => {
    setSquads(prev => prev.map(s => {
      if (s.id === squadId) {
        if (s.membersCount >= s.maxSize) {
          showToast('Squad is already at maximum capacity!', 'error');
          return s;
        }
        const updated = { ...s, membersCount: s.membersCount + 1 };
        setMySquads(my => [...my, updated]);
        showToast(`Joined squad: ${s.title}`, 'success');
        return updated;
      }
      return s;
    }));
  };

  return (
    <SquadContext.Provider value={{ rooms, squads, activeHold, mySquads, toast, placeRoomHold, releaseRoomHold, createSquad, joinSquad, showToast }}>
      {children}
    </SquadContext.Provider>
  );
}

export function useSquad() {
  return useContext(SquadContext);
}
