import { useState, useEffect } from 'react';

export function useIoTSensorSim(initialRooms = []) {
  const [rooms, setRooms] = useState(initialRooms);

  useEffect(() => {
    setRooms(initialRooms);
  }, [initialRooms.length]);

  useEffect(() => {
    const interval = setInterval(() => {
      setRooms(prevRooms =>
        prevRooms.map(room => {
          if (room.status === 'occupied') {
            const noiseDelta = (Math.random() - 0.5) * 6;
            const newNoise = Math.min(75, Math.max(30, Math.round((room.noiseLevel || 50) + noiseDelta)));
            return { ...room, noiseLevel: newNoise };
          } else if (room.status === 'available') {
            const noiseDelta = (Math.random() - 0.5) * 2;
            const newNoise = Math.min(42, Math.max(28, Math.round((room.noiseLevel || 32) + noiseDelta)));
            return { ...room, noiseLevel: newNoise };
          }
          return room;
        })
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return rooms;
}
