import { useState, useEffect } from 'react';

export function useHoldTimer(initialSeconds = 1200, onExpire) {
  const [secondsLeft, setSecondsLeft] = useState(initialSeconds);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    let timer = null;
    if (isActive && secondsLeft > 0) {
      timer = setInterval(() => {
        setSecondsLeft(prev => prev - 1);
      }, 1000);
    } else if (secondsLeft === 0 && isActive) {
      setIsActive(false);
      if (onExpire) onExpire();
    }
    return () => clearInterval(timer);
  }, [isActive, secondsLeft, onExpire]);

  const startTimer = (seconds = 1200) => {
    setSecondsLeft(seconds);
    setIsActive(true);
  };

  const stopTimer = () => {
    setIsActive(false);
  };

  const formatTime = () => {
    const mins = Math.floor(secondsLeft / 60);
    const secs = secondsLeft % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return { secondsLeft, isActive, startTimer, stopTimer, formatTime };
}
