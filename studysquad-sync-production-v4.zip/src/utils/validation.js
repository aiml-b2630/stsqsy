export function sanitizeString(input) {
  if (typeof input !== 'string') return '';
  return input.replace(/[<>'"]/g, '').trim();
}

export function validateSquadForm({ title, subject, maxSize }) {
  const errors = {};
  if (!title || title.trim().length < 3) {
    errors.title = 'Title must be at least 3 characters long.';
  }
  if (!subject || subject.trim().length < 2) {
    errors.subject = 'Subject is required.';
  }
  if (!maxSize || Number(maxSize) < 2 || Number(maxSize) > 12) {
    errors.maxSize = 'Capacity must be between 2 and 12.';
  }
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}
