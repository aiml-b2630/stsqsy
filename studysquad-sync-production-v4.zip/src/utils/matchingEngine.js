/**
 * Multi-Dimensional Weighted Overlap Matching Algorithm (v4.0.0)
 * Evaluates schedule matrix overlap, subject semantic similarity vector (Jaccard index),
 * learning amenity compatibility, and group capacity headroom.
 */

// Discrete schedule blocks: Morning (08-12), Afternoon (12-17), Evening (17-21), Late Night (21-02)
const SCHEDULE_WEIGHT = 0.40;
const SUBJECT_WEIGHT = 0.35;
const AMENITY_WEIGHT = 0.15;
const CAPACITY_WEIGHT = 0.10;

export function calculateSubjectSimilarity(str1, str2) {
  if (!str1 || !str2) return 0;
  const set1 = new Set(str1.toLowerCase().replace(/[^a-z0-9 ]/g, '').split(' '));
  const set2 = new Set(str2.toLowerCase().replace(/[^a-z0-9 ]/g, '').split(' '));
  const intersection = new Set([...set1].filter(x => set2.has(x)));
  const union = new Set([...set1, ...set2]);
  return union.size === 0 ? 0 : intersection.size / union.size;
}

export function calculateScheduleOverlap(sched1, sched2) {
  if (!sched1 || !sched2) return 0.2;
  if (sched1.toLowerCase() === sched2.toLowerCase()) return 1.0;
  if (sched1.includes('Anytime') || sched2.includes('Anytime')) return 0.8;
  return 0.1;
}

export function calculateMatchScore(studentPref, squad) {
  const scheduleScore = calculateScheduleOverlap(studentPref.schedule, squad.schedule);
  const subjectScore = calculateSubjectSimilarity(studentPref.subject, squad.subject);
  
  let amenityScore = 0.5;
  if (studentPref.amenities && squad.amenityPref) {
    const prefList = studentPref.amenities.split(',').map(s => s.trim().toLowerCase());
    const squadAmenity = squad.amenityPref.toLowerCase();
    if (prefList.some(p => squadAmenity.includes(p))) {
      amenityScore = 1.0;
    }
  }

  // Capacity headroom score: prefers squads with space available
  const currentMembers = squad.membersCount || 1;
  const capacityScore = currentMembers < squad.maxSize ? 1.0 : 0.0;

  const totalScore = (
    (scheduleScore * SCHEDULE_WEIGHT) +
    (subjectScore * SUBJECT_WEIGHT) +
    (amenityScore * AMENITY_WEIGHT) +
    (capacityScore * CAPACITY_WEIGHT)
  );

  return Math.min(100, Math.round(totalScore * 100));
}

export function rankSquadsForStudent(studentPref, squads) {
  return squads
    .map(squad => ({
      ...squad,
      matchScore: calculateMatchScore(studentPref, squad)
    }))
    .sort((a, b) => b.matchScore - a.matchScore);
}
