import { describe, it, expect } from 'vitest';
import { calculateMatchScore, calculateSubjectSimilarity } from '../utils/matchingEngine';

describe('Matching Engine Heuristics (v4.0.0)', () => {
  it('should return 1.0 for identical subject tokens', () => {
    const score = calculateSubjectSimilarity('Operating Systems', 'Operating Systems');
    expect(score).toBe(1.0);
  });

  it('should calculate weighted score accurately', () => {
    const student = { subject: 'Operating Systems', schedule: 'Afternoon', amenities: 'Whiteboard' };
    const squad = { subject: 'Operating Systems', schedule: 'Afternoon', amenityPref: 'Whiteboard', maxSize: 4, membersCount: 2 };
    const score = calculateMatchScore(student, squad);
    expect(score).toBeGreaterThanOrEqual(90);
  });
});
