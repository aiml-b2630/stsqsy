import React, { useState } from 'react';
import Header from './components/Header';
import RoomVisualizer from './components/RoomVisualizer';
import SquadMatcher from './components/SquadMatcher';
import SquadWorkspace from './components/SquadWorkspace';
import HowItWorks from './components/HowItWorks';
import Toast from './components/Toast';
import ErrorBoundary from './components/ErrorBoundary';
import { AuthProvider } from './context/AuthContext';
import { SquadProvider } from './context/SquadContext';

export default function App() {
  const [activeTab, setActiveTab] = useState('rooms');

  return (
    <ErrorBoundary>
      <AuthProvider>
        <SquadProvider>
          <div className="app-shell">
            <Header activeTab={activeTab} setActiveTab={setActiveTab} />
            <main className="main-content">
              {activeTab === 'rooms' && <RoomVisualizer />}
              {activeTab === 'matcher' && <SquadMatcher />}
              {activeTab === 'workspace' && <SquadWorkspace />}
              {activeTab === 'howItWorks' && <HowItWorks />}
            </main>
            <Toast />
          </div>
        </SquadProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
