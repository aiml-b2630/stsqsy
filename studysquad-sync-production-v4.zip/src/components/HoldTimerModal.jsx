import React from 'react';
import { Clock, ShieldCheck, AlertCircle } from 'lucide-react';

export default function HoldTimerModal({ room, onClose, onConfirm }) {
  return (
    <div className="modal-backdrop">
      <div className="modal-content">
        <div className="modal-header">
          <Clock size={24} className="accent-color" />
          <h3>Confirm 20-Minute Temporary Hold</h3>
        </div>
        <div className="modal-body">
          <p>You are about to place a <strong>20-minute temporary reservation</strong> on:</p>
          <div className="room-summary-box">
            <h4>{room.name}</h4>
            <p>{room.building}</p>
          </div>
          <div className="warning-callout">
            <AlertCircle size={18} />
            <span>If you fail to confirm physical arrival at the room within 20 minutes, the hold will automatically expire to release ghost bookings.</span>
          </div>
        </div>
        <div className="modal-actions">
          <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={onConfirm}>
            <ShieldCheck size={18} /> Confirm & Activate Timer
          </button>
        </div>
      </div>
    </div>
  );
}
