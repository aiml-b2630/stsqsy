import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Coffee, Sparkles } from 'lucide-react';

export default function PomodoroTimer() {
  const [secondsLeft, setSecondsLeft] = useState(1500); // 25 mins
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState('focus'); // 'focus' | 'break'

  useEffect(() => {
    let interval = null;
    if (isActive && secondsLeft > 0) {
      interval = setInterval(() => setSecondsLeft(s => s - 1), 1000);
    } else if (secondsLeft === 0) {
      if (mode === 'focus') {
        setMode('break');
        setSecondsLeft(300); // 5 min break
      } else {
        setMode('focus');
        setSecondsLeft(1500);
      }
    }
    return () => clearInterval(interval);
  }, [isActive, secondsLeft, mode]);

  const toggleTimer = () => setIsActive(!isActive);

  const resetTimer = () => {
    setIsActive(false);
    setMode('focus');
    setSecondsLeft(1500);
  };

  const formatTime = () => {
    const m = Math.floor(secondsLeft / 60);
    const s = secondsLeft % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="pomodoro-card">
      <div className="pomodoro-header">
        {mode === 'focus' ? <Sparkles size={18} className="accent-color" /> : <Coffee size={18} color="#10b981" />}
        <span>{mode === 'focus' ? 'Synchronized Focus Block (25m)' : 'Rest Break (5m)'}</span>
      </div>
      <div className="timer-display">{formatTime()}</div>
      <div className="pomodoro-actions">
        <button className="btn btn-primary" onClick={toggleTimer}>
          {isActive ? <Pause size={16} /> : <Play size={16} />}
          <span>{isActive ? 'Pause' : 'Start Focus Session'}</span>
        </button>
        <button className="btn btn-secondary" onClick={resetTimer}>
          <RotateCcw size={16} /> Reset
        </button>
      </div>
    </div>
  );
}
