import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('[StudySquad ErrorBoundary]', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '3rem', textAlign: 'center', background: '#1e293b', color: '#f8fafc', borderRadius: '12px', margin: '2rem' }}>
          <h2>⚠️ Something went wrong in the component tree.</h2>
          <p style={{ color: '#94a3b8', marginTop: '0.5rem' }}>{this.state.error?.message}</p>
          <button 
            style={{ marginTop: '1.5rem', padding: '0.75rem 1.5rem', background: '#3b82f6', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer' }}
            onClick={() => { localStorage.clear(); window.location.reload(); }}
          >
            Reset Application State
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
