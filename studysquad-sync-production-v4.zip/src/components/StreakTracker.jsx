import React from 'react';
import { Flame, Award, CheckCircle2 } from 'lucide-react';

export default function StreakTracker() {
  return (
    <div className="streak-card">
      <div className="streak-header">
        <Flame size={24} color="#f97316" />
        <div>
          <h3>Squad Study Streak</h3>
          <p>Daily consecutive hours completed together</p>
        </div>
      </div>
      <div className="streak-counter">
        <span className="streak-number">7</span>
        <span className="streak-unit">Days Active</span>
      </div>
      <div className="streak-badges">
        <div className="badge-item active"><Award size={16} /> 3-Day Warmup</div>
        <div className="badge-item active"><Award size={16} /> 7-Day Scholar</div>
        <div className="badge-item locked"><Award size={16} /> 14-Day Master</div>
      </div>
    </div>
  );
}
