import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useSquad } from '../context/SquadContext';
import { Shield, Clock, Users, MapPin, Sparkles } from 'lucide-react';

export default function Header({ activeTab, setActiveTab }) {
  const { user, toggleRole } = useAuth();
  const { activeHold } = useSquad();

  return (
    <header className="header-bar">
      <div className="header-container">
        <div className="brand-logo" onClick={() => setActiveTab('rooms')}>
          <div className="logo-icon">📡</div>
          <div>
            <h1 className="brand-title">StudySquad Sync</h1>
            <span className="brand-subtitle">Campus RoomRadar & Peer Squad System</span>
          </div>
        </div>

        <nav className="nav-menu">
          <button className={`nav-btn ${activeTab === 'rooms' ? 'active' : ''}`} onClick={() => setActiveTab('rooms')}>
            <MapPin size={18} /> Room Radar
          </button>
          <button className={`nav-btn ${activeTab === 'matcher' ? 'active' : ''}`} onClick={() => setActiveTab('matcher')}>
            <Users size={18} /> Squad Matcher
          </button>
          <button className={`nav-btn ${activeTab === 'workspace' ? 'active' : ''}`} onClick={() => setActiveTab('workspace')}>
            <Sparkles size={18} /> Squad Workspace
          </button>
          <button className={`nav-btn ${activeTab === 'howItWorks' ? 'active' : ''}`} onClick={() => setActiveTab('howItWorks')}>
            How It Works
          </button>
        </nav>

        <div className="user-controls">
          {activeHold && (
            <div className="hold-badge" onClick={() => setActiveTab('rooms')}>
              <Clock size={14} className="pulse-icon" />
              <span>Hold Active: {activeHold.room.name}</span>
            </div>
          )}

          <button className="role-chip" onClick={toggleRole} title="Click to switch simulated permissions">
            <Shield size={14} />
            <span>{user.role === 'admin' ? 'Role: Room Admin' : 'Role: Student'}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
