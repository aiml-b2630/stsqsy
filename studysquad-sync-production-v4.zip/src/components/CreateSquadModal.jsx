import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import { validateSquadForm } from '../utils/validation';
import { Users, X } from 'lucide-react';

export default function CreateSquadModal({ onClose }) {
  const { createSquad } = useSquad();
  const [formData, setFormData] = useState({
    title: '',
    subject: '',
    maxSize: 4,
    schedule: 'Afternoon',
    meetingRoom: 'Central Library Discussion Pod #1',
    topicGoal: '',
    amenityPref: 'Whiteboard'
  });
  const [errors, setErrors] = useState({});

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validation = validateSquadForm(formData);
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }
    await createSquad(formData);
    onClose();
  };

  return (
    <div className="modal-backdrop">
      <div className="modal-content">
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Users size={20} className="accent-color" />
            <h3>Create New Study Squad</h3>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer' }}>
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="modal-form">
          <div className="form-group">
            <label>Squad Title *</label>
            <input 
              type="text" 
              placeholder="e.g., OS Exam Prep Group" 
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="input-text"
            />
            {errors.title && <span className="field-error">{errors.title}</span>}
          </div>

          <div className="form-group">
            <label>Subject / Course Code *</label>
            <input 
              type="text" 
              placeholder="e.g., Operating Systems" 
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              className="input-text"
            />
            {errors.subject && <span className="field-error">{errors.subject}</span>}
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Max Group Size</label>
              <input 
                type="number" 
                min="2" 
                max="12" 
                value={formData.maxSize}
                onChange={(e) => setFormData({ ...formData, maxSize: Number(e.target.value) })}
                className="input-text"
              />
              {errors.maxSize && <span className="field-error">{errors.maxSize}</span>}
            </div>

            <div className="form-group">
              <label>Time Block</label>
              <select value={formData.schedule} onChange={(e) => setFormData({ ...formData, schedule: e.target.value })} className="select-filter">
                <option value="Morning">Morning</option>
                <option value="Afternoon">Afternoon</option>
                <option value="Evening">Evening</option>
                <option value="Late Night">Late Night</option>
              </select>
            </div>
          </div>

          <div className="form-group">
            <label>Meeting Location / Campus Room</label>
            <input 
              type="text" 
              value={formData.meetingRoom}
              onChange={(e) => setFormData({ ...formData, meetingRoom: e.target.value })}
              className="input-text"
            />
          </div>

          <div className="form-group">
            <label>Target Session Goal</label>
            <input 
              type="text" 
              placeholder="e.g., Complete Problem Set 3 & Page Replacement" 
              value={formData.topicGoal}
              onChange={(e) => setFormData({ ...formData, topicGoal: e.target.value })}
              className="input-text"
            />
          </div>

          <div className="modal-actions">
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary">Publish Study Squad</button>
          </div>
        </form>
      </div>
    </div>
  );
}
