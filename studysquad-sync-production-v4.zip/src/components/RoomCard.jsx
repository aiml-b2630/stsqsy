import React from 'react';
import { Volume2, Users, Clock, ShieldAlert } from 'lucide-react';

export default function RoomCard({ room, onHold }) {
  const getNoiseColor = (dB) => {
    if (dB < 40) return '#10b981'; // quiet green
    if (dB < 60) return '#f59e0b'; // amber
    return '#ef4444'; // loud red
  };

  const getStatusBadge = () => {
    if (room.status === 'available') return <span className="badge badge-available">Available</span>;
    if (room.status === 'reserved') return <span className="badge badge-reserved">20m Hold Active</span>;
    return <span className="badge badge-occupied">Occupied</span>;
  };

  return (
    <div className={`room-card card-status-${room.status}`}>
      <div className="card-header">
        <div>
          <h3 className="room-title">{room.name}</h3>
          <p className="room-building">{room.building}</p>
        </div>
        {getStatusBadge()}
      </div>

      <div className="card-stats">
        <div className="stat-item">
          <Users size={16} />
          <span>{room.occupiedSeats} / {room.capacity} Seats Occupied</span>
        </div>
        <div className="stat-item" style={{ color: getNoiseColor(room.noiseLevel) }}>
          <Volume2 size={16} />
          <span>{room.noiseLevel} dB ({room.noiseLevel < 40 ? 'Quiet' : room.noiseLevel < 60 ? 'Moderate' : 'Active Discussion'})</span>
        </div>
      </div>

      <div className="amenity-tags">
        {room.amenities.split(',').map((am, i) => (
          <span key={i} className="amenity-chip">{am.trim()}</span>
        ))}
      </div>

      <div className="card-actions">
        {room.status === 'available' ? (
          <button className="btn btn-primary btn-block" onClick={() => onHold(room)}>
            <Clock size={16} /> Place 20-Min Temporary Hold
          </button>
        ) : room.status === 'reserved' ? (
          <button className="btn btn-warning btn-block" disabled>
            <Clock size={16} /> Hold Placed by Student
          </button>
        ) : (
          <button className="btn btn-secondary btn-block" disabled>
            <ShieldAlert size={16} /> Space Currently Full
          </button>
        )}
      </div>
    </div>
  );
}
