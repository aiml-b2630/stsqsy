import React from 'react';
import { Users, Calendar, MapPin, Target, Flame, Sparkles } from 'lucide-react';

export default function SquadCard({ squad, onJoin }) {
  const isFull = squad.membersCount >= squad.maxSize;

  return (
    <div className="squad-card">
      <div className="squad-card-header">
        <div>
          <span className="squad-subject-chip">{squad.subject}</span>
          <h3 className="squad-title">{squad.title}</h3>
          <p className="squad-creator">Created by {squad.creatorName}</p>
        </div>
        {squad.matchScore !== undefined && (
          <div className="match-score-badge" title="Algorithmic schedule & subject compatibility score">
            <Sparkles size={14} />
            <span>{squad.matchScore}% Match</span>
          </div>
        )}
      </div>

      <div className="squad-details">
        <div className="detail-row">
          <Users size={16} />
          <span>{squad.membersCount} / {squad.maxSize} Members</span>
        </div>
        <div className="detail-row">
          <Calendar size={16} />
          <span>Time: {squad.schedule}</span>
        </div>
        <div className="detail-row">
          <MapPin size={16} />
          <span>Location: {squad.meetingRoom}</span>
        </div>
        {squad.topicGoal && (
          <div className="detail-row">
            <Target size={16} />
            <span>Goal: {squad.topicGoal}</span>
          </div>
        )}
      </div>

      <div className="squad-card-footer">
        <div className="streak-badge">
          <Flame size={16} color="#f97316" />
          <span>{squad.streak || 1} Day Streak</span>
        </div>

        <button 
          className={`btn ${isFull ? 'btn-secondary' : 'btn-primary'}`} 
          disabled={isFull}
          onClick={() => onJoin(squad.id)}
        >
          {isFull ? 'Squad Full' : 'Join Study Squad'}
        </button>
      </div>
    </div>
  );
}
