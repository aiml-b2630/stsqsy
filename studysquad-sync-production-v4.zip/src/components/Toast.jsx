import React from 'react';
import { useSquad } from '../context/SquadContext';

export default function Toast() {
  const { toast } = useSquad();
  if (!toast) return null;

  return (
    <div className={`toast-notification toast-${toast.type}`}>
      <span>{toast.message}</span>
    </div>
  );
}
