import React from 'react';
import { MapPin, Clock, Users, ShieldCheck } from 'lucide-react';

export default function HowItWorks() {
  return (
    <div className="section-container">
      <div className="section-header">
        <div>
          <h2>How StudySquad Sync Works</h2>
          <p>Eliminating wasted campus space hunts and connecting serious peer study groups.</p>
        </div>
      </div>

      <div className="steps-grid">
        <div className="step-card">
          <div className="step-number">1</div>
          <MapPin size={28} className="step-icon" />
          <h3>Live RoomRadar</h3>
          <p>Check real-time decibel noise meters and seat occupancy across 12 campus library halls and quiet pods.</p>
        </div>

        <div className="step-card">
          <div className="step-number">2</div>
          <Clock size={28} className="step-icon" />
          <h3>20-Minute Hold</h3>
          <p>Place a temporary hold while walking to the library. Ghost bookings are automatically released after 20 minutes.</p>
        </div>

        <div className="step-card">
          <div className="step-number">3</div>
          <Users size={28} className="step-icon" />
          <h3>Peer Squad Matcher</h3>
          <p>Pair with compatible peers based on subject vector matching and overlapping study time blocks.</p>
        </div>

        <div className="step-card">
          <div className="step-number">4</div>
          <ShieldCheck size={28} className="step-icon" />
          <h3>Synchronized Focus</h3>
          <p>Use the shared 25-minute Pomodoro timer, topic goal checklists, and earn daily study streak badges together.</p>
        </div>
      </div>
    </div>
  );
}
