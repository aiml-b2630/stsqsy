import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import RoomCard from './RoomCard';
import HoldTimerModal from './HoldTimerModal';
import { Filter, SlidersHorizontal, Search } from 'lucide-react';

export default function RoomVisualizer() {
  const { rooms, placeRoomHold } = useSquad();
  const [selectedAmenity, setSelectedAmenity] = useState('All');
  const [maxNoise, setMaxNoise] = useState(75);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRoomForHold, setSelectedRoomForHold] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const roomsPerPage = 6;

  const amenitiesList = ['All', 'Whiteboard', 'Power Sockets', 'Silent Zone', 'Group Discussion', 'Dual Monitors'];

  const filteredRooms = rooms.filter(room => {
    const matchesAmenity = selectedAmenity === 'All' || room.amenities.includes(selectedAmenity);
    const matchesNoise = room.noiseLevel <= maxNoise;
    const matchesSearch = room.name.toLowerCase().includes(searchTerm.toLowerCase()) || room.building.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesAmenity && matchesNoise && matchesSearch;
  });

  const totalPages = Math.ceil(filteredRooms.length / roomsPerPage);
  const displayedRooms = filteredRooms.slice((currentPage - 1) * roomsPerPage, currentPage * roomsPerPage);

  return (
    <div className="section-container">
      <div className="section-header">
        <div>
          <h2>Campus RoomRadar Availability</h2>
          <p>Live PIR motion & decibel telemetry for library pods and study halls.</p>
        </div>
      </div>

      <div className="filter-bar">
        <div className="filter-group">
          <Search size={18} className="filter-icon" />
          <input 
            type="text" 
            placeholder="Search facility name or location..." 
            className="input-search"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="filter-group">
          <Filter size={18} className="filter-icon" />
          <select value={selectedAmenity} onChange={(e) => setSelectedAmenity(e.target.value)} className="select-filter">
            {amenitiesList.map(am => <option key={am} value={am}>{am}</option>)}
          </select>
        </div>

        <div className="filter-group">
          <SlidersHorizontal size={18} className="filter-icon" />
          <label className="range-label">Max Noise: <strong>{maxNoise} dB</strong></label>
          <input 
            type="range" 
            min="30" 
            max="75" 
            value={maxNoise} 
            onChange={(e) => setMaxNoise(Number(e.target.value))} 
            className="range-input"
          />
        </div>
      </div>

      <div className="rooms-grid">
        {displayedRooms.length > 0 ? (
          displayedRooms.map(room => (
            <RoomCard key={room.id} room={room} onHold={(r) => setSelectedRoomForHold(r)} />
          ))
        ) : (
          <div className="empty-state">No campus spaces match your current telemetry filters.</div>
        )}
      </div>

      {totalPages > 1 && (
        <div className="pagination">
          <button disabled={currentPage === 1} onClick={() => setCurrentPage(p => p - 1)} className="btn btn-secondary">Previous</button>
          <span>Page {currentPage} of {totalPages}</span>
          <button disabled={currentPage === totalPages} onClick={() => setCurrentPage(p => p + 1)} className="btn btn-secondary">Next</button>
        </div>
      )}

      {selectedRoomForHold && (
        <HoldTimerModal 
          room={selectedRoomForHold} 
          onClose={() => setSelectedRoomForHold(null)} 
          onConfirm={() => {
            placeRoomHold(selectedRoomForHold);
            setSelectedRoomForHold(null);
          }}
        />
      )}
    </div>
  );
}
