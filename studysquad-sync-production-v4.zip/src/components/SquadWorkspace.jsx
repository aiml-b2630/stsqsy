import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import PomodoroTimer from './PomodoroTimer';
import StreakTracker from './StreakTracker';
import { Users, Target, CheckSquare, Sparkles } from 'lucide-react';

export default function SquadWorkspace() {
  const { mySquads, squads } = useSquad();
  const activeSquad = mySquads[0] || squads[0];

  const [goals, setGoals] = useState([
    { id: 1, text: 'Review Chapter 4 Operating System Memory Management', done: true },
    { id: 2, text: 'Solve Page Replacement Algorithm Practice Matrix', done: false },
    { id: 3, text: 'Draft Group Summary Notes for Semaphores', done: false }
  ]);
  const [newGoal, setNewGoal] = useState('');

  const toggleGoal = (id) => {
    setGoals(goals.map(g => g.id === id ? { ...g, done: !g.done } : g));
  };

  const addGoal = (e) => {
    e.preventDefault();
    if (!newGoal.trim()) return;
    setGoals([...goals, { id: Date.now(), text: newGoal, done: false }]);
    setNewGoal('');
  };

  if (!activeSquad) {
    return <div className="section-container">No active squad selected.</div>;
  }

  return (
    <div className="section-container">
      <div className="workspace-banner">
        <div>
          <span className="squad-subject-chip">{activeSquad.subject}</span>
          <h2>{activeSquad.title}</h2>
          <p>Meeting Room: <strong>{activeSquad.meetingRoom}</strong> • Schedule: <strong>{activeSquad.schedule}</strong></p>
        </div>
      </div>

      <div className="workspace-grid">
        <div className="workspace-left">
          <PomodoroTimer />
          
          <div className="goals-card">
            <div className="goals-header">
              <Target size={18} className="accent-color" />
              <h3>Session Focus Goals</h3>
            </div>
            
            <form onSubmit={addGoal} className="add-goal-form">
              <input 
                type="text" 
                placeholder="Add session study objective..." 
                value={newGoal} 
                onChange={(e) => setNewGoal(e.target.value)}
                className="input-text"
              />
              <button type="submit" className="btn btn-primary">Add</button>
            </form>

            <div className="goals-list">
              {goals.map(g => (
                <div key={g.id} className={`goal-item ${g.done ? 'completed' : ''}`} onClick={() => toggleGoal(g.id)}>
                  <CheckSquare size={18} color={g.done ? '#10b981' : '#64748b'} />
                  <span>{g.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="workspace-right">
          <StreakTracker />

          <div className="roster-card">
            <div className="roster-header">
              <Users size={18} className="accent-color" />
              <h3>Active Squad Members</h3>
            </div>
            <div className="roster-list">
              <div className="roster-item">
                <div className="avatar">AR</div>
                <div>
                  <div className="member-name">Alex Rivera (You)</div>
                  <div className="member-role">Creator • Online</div>
                </div>
              </div>
              <div className="roster-item">
                <div className="avatar">ER</div>
                <div>
                  <div className="member-name">Elena Rostova</div>
                  <div className="member-role">Member • Online</div>
                </div>
              </div>
              <div className="roster-item">
                <div className="avatar">MV</div>
                <div>
                  <div className="member-name">Marcus Vance</div>
                  <div className="member-role">Member • In Room</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
