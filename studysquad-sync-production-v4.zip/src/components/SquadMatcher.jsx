import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import SquadCard from './SquadCard';
import CreateSquadModal from './CreateSquadModal';
import { rankSquadsForStudent } from '../utils/matchingEngine';
import { Plus, Sparkles, Filter } from 'lucide-react';

export default function SquadMatcher() {
  const { squads, joinSquad } = useSquad();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [mySubject, setMySubject] = useState('');
  const [mySchedule, setMySchedule] = useState('Anytime');
  const [myAmenity, setMyAmenity] = useState('');

  const studentPref = {
    subject: mySubject,
    schedule: mySchedule,
    amenities: myAmenity
  };

  const rankedSquads = rankSquadsForStudent(studentPref, squads);

  return (
    <div className="section-container">
      <div className="section-header">
        <div>
          <h2>Subject Study Squad Matcher</h2>
          <p>Find compatible peer study groups paired by subject vector and schedule matrix.</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowCreateModal(true)}>
          <Plus size={18} /> Create New Squad
        </button>
      </div>

      <div className="matcher-filter-card">
        <div className="matcher-filter-title">
          <Sparkles size={18} />
          <span>Tune Your Compatibility Vector</span>
        </div>
        <div className="matcher-inputs-grid">
          <div>
            <label>Target Subject / Course</label>
            <input 
              type="text" 
              placeholder="e.g., Operating Systems, Linear Algebra..." 
              value={mySubject} 
              onChange={(e) => setMySubject(e.target.value)}
              className="input-text"
            />
          </div>
          <div>
            <label>Preferred Study Time Block</label>
            <select value={mySchedule} onChange={(e) => setMySchedule(e.target.value)} className="select-filter">
              <option value="Anytime">Anytime</option>
              <option value="Morning">Morning (08:00 - 12:00)</option>
              <option value="Afternoon">Afternoon (12:00 - 17:00)</option>
              <option value="Evening">Evening (17:00 - 21:00)</option>
              <option value="Late Night">Late Night (21:00 - 02:00)</option>
            </select>
          </div>
          <div>
            <label>Required Facility Amenity</label>
            <input 
              type="text" 
              placeholder="e.g., Whiteboard, Silent Zone..." 
              value={myAmenity} 
              onChange={(e) => setMyAmenity(e.target.value)}
              className="input-text"
            />
          </div>
        </div>
      </div>

      <div className="squads-grid">
        {rankedSquads.map(squad => (
          <SquadCard key={squad.id} squad={squad} onJoin={joinSquad} />
        ))}
      </div>

      {showCreateModal && <CreateSquadModal onClose={() => setShowCreateModal(false)} />}
    </div>
  );
}
