import express from 'express';
import cors from 'cors';
import 'dotenv/config';
import authRoutes from './routes/auth.js';
import roomRoutes from './routes/rooms.js';
import squadRoutes from './routes/squads.js';
import workspaceRoutes from './routes/workspace.js';
import { startHoldCleanupWorker } from './workers/holdCleanupWorker.js';
import logger from './logger.js';
import { createServer } from 'node:http';
import swaggerUi from 'swagger-ui-express';
import openapi from './openapi.js';
import { attachRealtime, broadcastRooms } from './realtime.js';
import db from './db.js';


if (process.env.NODE_ENV !== 'test' && (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32 || process.env.JWT_SECRET === 'replace_with_a_random_secret_at_least_32_characters')) {
  throw new Error('JWT_SECRET is required and must be a random value of at least 32 characters. Copy .env.example and configure it before starting the server.');
}

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(openapi));
app.get('/api/openapi.json', (req, res) => res.json(openapi));

app.use('/api/auth', authRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/squads', squadRoutes);
app.use('/api/workspace', workspaceRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', service: 'StudySquad Sync API', version: '6.2.0' });
});

const httpServer = createServer(app);
attachRealtime(httpServer, db);

// Start background cron worker for hold cleanup
const cleanupInterval = Number(process.env.HOLD_CLEANUP_INTERVAL_MS) || 10000;
startHoldCleanupWorker(cleanupInterval, () => broadcastRooms(db, 'rooms:updated'));

if (process.env.NODE_ENV !== 'test') {
  httpServer.listen(PORT, () => {
    logger.info(`StudySquad Sync server listening on port ${PORT}`);
  });
}

export { httpServer };
export default app;
