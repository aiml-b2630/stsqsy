import express from 'express';
import db from '../db.js';
import { authenticateToken } from '../middleware/auth.js';
import { validateSquadCreation } from '../middleware/validate.js';
import logger from '../logger.js';

const router = express.Router();

router.get('/', (req, res) => {
  res.json({ success: true, squads: db.getSquads() });
});

router.post('/:id/join', authenticateToken, (req, res) => {
  const result = db.joinSquad(req.params.id);
  if (!result.success) return res.status(result.error === 'Study squad not found.' ? 404 : 409).json(result);
  res.json({ success: true, squad: result.squad, message: 'You joined the study squad.' });
});

router.post('/', authenticateToken, validateSquadCreation, (req, res) => {
  const newSquad = db.createSquad({
    ...req.body,
    creator: req.user.username || 'Student User'
  });
  res.status(201).json({ success: true, squad: newSquad });
});

export default router;
