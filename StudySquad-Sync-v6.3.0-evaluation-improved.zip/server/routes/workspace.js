import express from 'express';
import db from '../db.js';
import { authenticateToken } from '../middleware/auth.js';
import { broadcastWorkspace } from '../realtime.js';

const router = express.Router();

router.get('/tasks', authenticateToken, (req, res) => {
  res.json({ success: true, tasks: db.getWorkspaceTasks() });
});

router.put('/tasks', authenticateToken, (req, res) => {
  const tasks = req.body?.tasks;
  if (!Array.isArray(tasks) || tasks.length > 100) {
    return res.status(400).json({ success: false, error: 'Tasks must be an array with at most 100 items.' });
  }
  const valid = tasks.every(task =>
    task && typeof task.id === 'string' && task.id.length > 0 && task.id.length <= 80 &&
    typeof task.text === 'string' && task.text.trim().length > 0 && task.text.length <= 120 &&
    typeof task.done === 'boolean'
  );
  if (!valid) return res.status(400).json({ success: false, error: 'Each task needs a valid id, text, and completion state.' });
  const saved = db.replaceWorkspaceTasks(tasks);
  broadcastWorkspace(saved);
  res.json({ success: true, tasks: saved });
});

export default router;
