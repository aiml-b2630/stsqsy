import express from 'express';
import db from '../db.js';
import { authenticateToken } from '../middleware/auth.js';
import logger from '../logger.js';
import { broadcastRooms } from '../realtime.js';

const router = express.Router();

router.get('/', (req, res) => {
  res.json({ success: true, rooms: db.getRooms() });
});

router.post('/:id/release', authenticateToken, (req, res) => {
  const result = db.releaseRoom(req.params.id);
  if (!result.room) return res.status(404).json({ success: false, error: 'Room not found.' });
  if (!result.success) return res.status(409).json({ success: false, error: 'This room has no active hold.' });
  broadcastRooms(db, 'rooms:updated');
  res.json({ success: true, room: result.room, message: 'Room hold released.' });
});

router.post('/:id/reserve', authenticateToken, (req, res) => {
  const roomId = req.params.id;
  const { version, duration_minutes = 20 } = req.body;

  if (version === undefined) {
    return res.status(400).json({ success: false, error: "Optimistic concurrency 'version' required." });
  }

  if (!Number.isInteger(duration_minutes) || duration_minutes < 5 || duration_minutes > 60) {
    return res.status(400).json({ success: false, error: 'Hold duration must be between 5 and 60 minutes.' });
  }
  const holdUntilMs = Date.now() + (duration_minutes * 60 * 1000);
  const result = db.reserveRoom(roomId, version, holdUntilMs);

  if (!result.success) {
    return res.status(409).json(result);
  }

  broadcastRooms(db, 'rooms:updated');
  res.json({ success: true, room: result.room, message: `Room held for ${duration_minutes} minutes.` });
});

export default router;
