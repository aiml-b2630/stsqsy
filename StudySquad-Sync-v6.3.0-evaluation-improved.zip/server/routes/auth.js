import express from 'express';
import jwt from 'jsonwebtoken';
import logger from '../logger.js';

const router = express.Router();
const attempts = new Map();
const WINDOW_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS = 10;
router.use((req, res, next) => {
  const key = req.ip || req.socket?.remoteAddress || 'unknown';
  const now = Date.now();
  const record = attempts.get(key) || { count: 0, resetAt: now + WINDOW_MS };
  if (now > record.resetAt) { record.count = 0; record.resetAt = now + WINDOW_MS; }
  if (record.count >= MAX_ATTEMPTS) {
    res.set('Retry-After', String(Math.ceil((record.resetAt - now) / 1000)));
    return res.status(429).json({ success: false, error: 'Too many login attempts. Please try again later.' });
  }
  record.count += 1;
  attempts.set(key, record);
  // Keep the limiter map bounded and discard expired entries.
  if (attempts.size > 5000) for (const [entry, value] of attempts) if (value.resetAt <= now) attempts.delete(entry);
  next();
});
function getJwtSecret() {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 32 || secret === 'replace_with_a_random_secret_at_least_32_characters') {
    const error = new Error('JWT_SECRET must be configured with a random value of at least 32 characters.');
    error.status = 500;
    throw error;
  }
  return secret;
}
router.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string' || !username.trim() || !password || username.length > 80 || password.length > 256) return res.status(400).json({ success: false, error: 'Valid username and password required' });
  let jwtSecret;
  try { jwtSecret = getJwtSecret(); }
  catch (error) { logger.error('Authentication unavailable: JWT_SECRET is not configured'); return res.status(500).json({ success: false, error: 'Server security misconfiguration.' }); }
  const user = { id: 101, username, role: 'student', student_id: 'STUD-2026-99' };
  const token = jwt.sign(user, jwtSecret, { expiresIn: '8h' });
  logger.info('User logged in successfully', { username });
  res.json({ success: true, token, user });
});
export default router;
