import 'dotenv/config';
import Database from 'better-sqlite3';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import logger from './logger.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const configuredPath = process.env.DB_FILE || path.join(here, '..', 'data', 'studysquad.sqlite');
if (configuredPath !== ':memory:') {
  const fs = await import('node:fs');
  fs.mkdirSync(path.dirname(path.resolve(configuredPath)), { recursive: true });
}

const database = new Database(configuredPath);
database.pragma('journal_mode = WAL');
database.pragma('foreign_keys = ON');
database.exec(`
  CREATE TABLE IF NOT EXISTS rooms (
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, building TEXT NOT NULL, floor TEXT NOT NULL,
    capacity INTEGER NOT NULL, occupied_chairs INTEGER NOT NULL DEFAULT 0, noise_db INTEGER NOT NULL DEFAULT 35,
    amenities TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL DEFAULT 'available',
    version INTEGER NOT NULL DEFAULT 1, hold_until INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status);
  CREATE INDEX IF NOT EXISTS idx_rooms_building ON rooms(building);
  CREATE TABLE IF NOT EXISTS squads (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subject TEXT NOT NULL,
    creator TEXT NOT NULL, max_members INTEGER NOT NULL, current_members INTEGER NOT NULL DEFAULT 1,
    schedule TEXT, target_goal TEXT, room_name TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_squads_subject ON squads(subject);
  CREATE TABLE IF NOT EXISTS workspace_tasks (
    id TEXT PRIMARY KEY, text TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0, sort_order INTEGER NOT NULL DEFAULT 0
  );
`);

const seedRooms = [
 [1,'Library Pod A1','Central Library','3rd Floor',4,1,38,['Whiteboard','Power Sockets','Silent Zone'],'available'],
 [2,'Eng Discussion Room 102','Engineering Block','1st Floor',6,4,62,['Whiteboard','Dual Monitors','Group Discussion'],'available'],
 [3,'Silent Study Alcove 3','Central Library','2nd Floor',2,2,32,['Power Sockets','Silent Zone'],'occupied'],
 [4,'Innovation Lab Suite','Student Center','Ground',8,3,58,['Whiteboard','Power Sockets','Dual Monitors','Group Discussion'],'available'],
 [5,'Math Finals Cell 5','Science Tower','4th Floor',4,0,35,['Whiteboard','Power Sockets'],'available'],
 [6,'Media Commons Room B','Student Center','2nd Floor',5,1,48,['Dual Monitors','Group Discussion'],'available']
];
const insertRoom = database.prepare(`INSERT OR IGNORE INTO rooms
 (id,name,building,floor,capacity,occupied_chairs,noise_db,amenities,status) VALUES (?,?,?,?,?,?,?,?,?)`);
const seed = database.transaction(() => seedRooms.forEach(r => insertRoom.run(...r.slice(0,7), JSON.stringify(r[7]), r[8])));
seed();
const seedSquads = [
 [1,'Linear Algebra Exam Prep','Mathematics','Alex Chen',4,3,'Afternoon','Solve Chapter 5-7 Practice Problems','Library Pod A1'],
 [2,'Operating Systems Finals Squad','Computer Science','Elena Rostova',5,2,'Late Night','Concurrency & Process Scheduling','Eng Discussion Room 102'],
 [3,'GATE Mechanical Revision','Engineering','Marcus Vance',3,2,'Morning','Thermodynamics Mock Test','Silent Study Alcove 3']
];
const insertSquad = database.prepare(`INSERT OR IGNORE INTO squads
 (id,title,subject,creator,max_members,current_members,schedule,target_goal,room_name) VALUES (?,?,?,?,?,?,?,?,?)`);
database.transaction(() => seedSquads.forEach(s => insertSquad.run(...s)))();

const initialTasks = [
  ['task-1', 'Agree on the session learning goal', 1, 0],
  ['task-2', 'Review notes and key concepts', 0, 1],
  ['task-3', 'Work through practice problems together', 0, 2]
];
const taskCount = database.prepare('SELECT COUNT(*) AS count FROM workspace_tasks').get().count;
if (!taskCount) {
  const insertTask = database.prepare('INSERT INTO workspace_tasks (id,text,done,sort_order) VALUES (?,?,?,?)');
  database.transaction(() => initialTasks.forEach(task => insertTask.run(...task)))();
}
const mapRoom = row => row ? { ...row, amenities: JSON.parse(row.amenities) } : null;
export const db = {
  raw: database,
  getRooms: () => database.prepare('SELECT * FROM rooms ORDER BY id').all().map(mapRoom),
  getRoomById: id => mapRoom(database.prepare('SELECT * FROM rooms WHERE id = ?').get(Number(id))),
  reserveRoom(id, currentVersion, holdUntilMs) {
    const result = database.prepare(`UPDATE rooms SET status='reserved', version=version+1, hold_until=?
      WHERE id=? AND version=? AND status='available'`).run(holdUntilMs, Number(id), Number(currentVersion));
    if (!result.changes) {
      const room = this.getRoomById(id);
      return { success: false, error: !room ? 'Room not found' : room.version !== Number(currentVersion)
        ? 'Concurrency conflict: room status was modified by another user.' : 'Room is not available.' };
    }
    const room = this.getRoomById(id);
    logger.info('Room reserved successfully with SQLite optimistic concurrency lock', { roomId: id, newVersion: room.version });
    return { success: true, room };
  },
  releaseRoom(id) {
    const result = database.prepare(`UPDATE rooms SET status='available', hold_until=NULL, version=version+1
      WHERE id=? AND status='reserved'`).run(Number(id));
    const room = this.getRoomById(id);
    return { success: result.changes > 0 || room?.status === 'available', room };
  },
  releaseExpiredHolds() {
    const result = database.prepare(`UPDATE rooms SET status='available', hold_until=NULL, version=version+1
      WHERE status='reserved' AND hold_until IS NOT NULL AND hold_until <= ?`).run(Date.now());
    if (result.changes) logger.info('Expired room holds released', { count: result.changes });
    return result.changes;
  },
  getSquads: () => database.prepare('SELECT * FROM squads ORDER BY id DESC').all(),
  createSquad(data) {
    const result = database.prepare(`INSERT INTO squads (title,subject,creator,max_members,current_members,schedule,target_goal,room_name)
      VALUES (@title,@subject,@creator,@max_members,1,@schedule,@target_goal,@room_name)`).run(data);
    return database.prepare('SELECT * FROM squads WHERE id=?').get(result.lastInsertRowid);
  },
  joinSquad(id) {
    const update = database.prepare(`UPDATE squads SET current_members=current_members+1
      WHERE id=? AND current_members < max_members`).run(Number(id));
    const squad = database.prepare('SELECT * FROM squads WHERE id=?').get(Number(id));
    if (!squad) return { success: false, error: 'Study squad not found.' };
    if (!update.changes) return { success: false, error: 'This squad is already full.' };
    return { success: true, squad };
  },
  getWorkspaceTasks: () => database.prepare('SELECT id, text, done FROM workspace_tasks ORDER BY sort_order, rowid').all()
    .map(task => ({ ...task, done: Boolean(task.done) })),
  replaceWorkspaceTasks(tasks) {
    const replace = database.transaction(items => {
      database.prepare('DELETE FROM workspace_tasks').run();
      const insert = database.prepare('INSERT INTO workspace_tasks (id,text,done,sort_order) VALUES (?,?,?,?)');
      items.forEach((task, index) => insert.run(String(task.id), String(task.text), task.done ? 1 : 0, index));
    });
    replace(tasks);
    return this.getWorkspaceTasks();
  },
  close: () => database.close()
};
export default db;
