import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false }; }
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch(error, info) { console.error('StudySquad UI error:', error, info); }
  render() {
    if (this.state.hasError) return <main className="auth-shell"><section className="glass-card auth-card"><h1>Something went wrong</h1><p className="muted">The interface encountered an unexpected error. Reload the app to try again.</p><button className="primary-button" onClick={() => window.location.reload()}>Reload application</button></section></main>;
    return this.props.children;
  }
}
