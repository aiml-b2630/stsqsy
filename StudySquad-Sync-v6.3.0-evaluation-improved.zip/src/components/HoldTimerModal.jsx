import React, { useCallback } from 'react';
import { useHoldTimer } from '../hooks/useHoldTimer';
import { Clock, XCircle } from 'lucide-react';

export default function HoldTimerModal({ activeHold, onRelease }) {
  const release = useCallback(() => { if (activeHold) onRelease(activeHold.roomId); }, [activeHold, onRelease]);
  const { formatted } = useHoldTimer(activeHold?.holdUntil, release);
  if (!activeHold) return null;
  return (
    <div className="modal-backdrop">
      <section className="modal-card glass-card hold-modal" role="dialog" aria-modal="true">
        <span className="hold-icon"><Clock size={28} /></span><p className="eyebrow">TEMPORARY RESERVATION</p><h2>Room held for you</h2>
        <p className="muted">{activeHold.roomName}</p><strong className="hold-countdown">{formatted}</strong>
        <p className="muted">Arrive before the timer expires. Your hold will be released automatically when the countdown ends.</p>
        <button className="danger-button" onClick={release}><XCircle size={16} /> Cancel hold</button>
      </section>
    </div>
  );
}
