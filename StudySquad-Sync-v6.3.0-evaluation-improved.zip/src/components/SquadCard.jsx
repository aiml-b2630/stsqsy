import React from 'react';
import { Users, Clock, MapPin, BookOpen, ArrowRight } from 'lucide-react';

export default function SquadCard({ squad, matchScore, onJoin }) {
  const full = Number(squad.current_members) >= Number(squad.max_members);
  return (
    <article className="squad-card glass-card">
      <div className="card-topline"><span className="subject-tag">{squad.subject}</span><span className="match-tag">{matchScore}% match</span></div>
      <h3>{squad.title}</h3><p className="muted">{squad.target_goal || 'A focused study session with peers.'}</p>
      <div className="squad-details">
        <span><Clock size={15} /> {squad.schedule || 'Schedule flexible'}</span>
        <span><MapPin size={15} /> {squad.room_name || 'Room to be decided'}</span>
        <span><Users size={15} /> {squad.current_members} / {squad.max_members} members</span>
        <span><BookOpen size={15} /> Hosted by {squad.creator}</span>
      </div>
      <button className="primary-button" disabled={full} onClick={onJoin}>{full ? 'Squad is full' : 'Join squad'} <ArrowRight size={16} /></button>
    </article>
  );
}
