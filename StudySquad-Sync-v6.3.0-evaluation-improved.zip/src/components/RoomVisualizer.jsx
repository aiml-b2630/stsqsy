import React, { useMemo, useState } from 'react';
import { useSquad } from '../contexts/SquadContext';
import RoomCard from './RoomCard';
import HoldTimerModal from './HoldTimerModal';
import { Search, SlidersHorizontal, RefreshCw, Radio } from 'lucide-react';

export default function RoomVisualizer() {
  const { rooms, reserveRoomHold, activeHold, releaseHold, loading, error, refresh } = useSquad();
  const [selectedAmenity, setSelectedAmenity] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [actionError, setActionError] = useState('');

  const filteredRooms = useMemo(() => rooms.filter(room => {
    const matchesAmenity = selectedAmenity === 'All' || (room.amenities || []).includes(selectedAmenity);
    const query = searchQuery.toLowerCase();
    return matchesAmenity && `${room.name} ${room.building} ${room.floor}`.toLowerCase().includes(query);
  }), [rooms, selectedAmenity, searchQuery]);

  const handleReserve = async id => {
    setActionError('');
    try { await reserveRoomHold(id); }
    catch (err) { setActionError(err.message); }
  };

  return (
    <section>
      <div className="section-heading">
        <div><p className="eyebrow">CAMPUS AVAILABILITY</p><h2>Find your study space</h2><p className="muted">Live occupancy and room conditions, synchronized across connected clients.</p></div>
        <span className="live-pill"><span /> Live room feed</span>
      </div>
      <div className="stats-row">
        <div className="stat-card"><span>Rooms tracked</span><strong>{rooms.length}</strong></div>
        <div className="stat-card"><span>Available now</span><strong>{rooms.filter(r => r.status === 'available').length}</strong></div>
        <div className="stat-card"><span>Currently occupied</span><strong>{rooms.filter(r => r.status === 'occupied').length}</strong></div>
      </div>
      <div className="toolbar glass-card">
        <label className="search-box"><Search size={17} /><input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search rooms or buildings…" /></label>
        <label className="filter-box"><SlidersHorizontal size={17} /><select value={selectedAmenity} onChange={e => setSelectedAmenity(e.target.value)}>
          <option>All</option><option>Whiteboard</option><option>Power Sockets</option><option>Silent Zone</option><option>Dual Monitors</option><option>Group Discussion</option>
        </select></label>
        <button className="secondary-button" onClick={refresh}><RefreshCw size={15} /> Refresh</button>
      </div>
      {(error || actionError) && <div className="alert error-alert">{actionError || error}</div>}
      {loading ? <div className="empty-state"><Radio className="pulse" size={28} /><h3>Loading campus rooms…</h3></div> :
        filteredRooms.length ? <div className="grid-responsive">{filteredRooms.map(room => <RoomCard key={room.id} room={room} onReserve={handleReserve} />)}</div> :
        <div className="empty-state"><h3>No rooms match your filters</h3><p>Try another search term or amenity.</p></div>}
      <HoldTimerModal activeHold={activeHold} onRelease={async id => {
        try { await releaseHold(id); setActionError(''); } catch (err) { setActionError(err.message); }
      }} />
    </section>
  );
}
