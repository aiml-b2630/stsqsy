import React, { useMemo, useState } from 'react';
import { useSquad } from '../contexts/SquadContext';
import SquadCard from './SquadCard';
import CreateSquadModal from './CreateSquadModal';
import { calculateSquadMatchScore } from '../utils/matchingEngine';
import { Plus, Sparkles } from 'lucide-react';

export default function SquadMatcher({ onOpenWorkspace }) {
  const { squads, createSquad, joinSquad, loading, error } = useSquad();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [userProfile, setUserProfile] = useState({ subject: 'Mathematics', schedule: 'Afternoon' });
  const [actionError, setActionError] = useState('');
  const [notice, setNotice] = useState('');

  const sortedSquads = useMemo(() => [...squads].sort((a, b) =>
    calculateSquadMatchScore(userProfile, b) - calculateSquadMatchScore(userProfile, a)), [squads, userProfile]);

  const handleJoin = async squad => {
    setActionError(''); setNotice('');
    try { await joinSquad(squad.id); setNotice(`You joined "${squad.title}". Your focus workspace is ready.`); onOpenWorkspace?.(); }
    catch (err) { setActionError(err.message); }
  };

  return (
    <section>
      <div className="section-heading">
        <div><p className="eyebrow">PEER MATCHING</p><h2>Find your study squad</h2><p className="muted">Discover groups by subject, schedule, and shared learning goals.</p></div>
        <button className="primary-button" onClick={() => setIsModalOpen(true)}><Plus size={17} /> Create a squad</button>
      </div>
      <div className="profile-panel glass-card">
        <div><Sparkles size={19} /><div><strong>Personalize your matches</strong><small>Choose your study subject and preferred time.</small></div></div>
        <label>Subject<input value={userProfile.subject} onChange={e => setUserProfile(p => ({ ...p, subject: e.target.value }))} /></label>
        <label>Schedule<select value={userProfile.schedule} onChange={e => setUserProfile(p => ({ ...p, schedule: e.target.value }))}><option>Morning</option><option>Afternoon</option><option>Late Night</option></select></label>
      </div>
      {(error || actionError) && <div className="alert error-alert">{actionError || error}</div>}
      {notice && <div className="alert success-alert">{notice}</div>}
      {loading ? <div className="empty-state">Loading study squads…</div> :
        sortedSquads.length ? <div className="grid-responsive">{sortedSquads.map(squad => <SquadCard key={squad.id} squad={squad} matchScore={calculateSquadMatchScore(userProfile, squad)} onJoin={() => handleJoin(squad)} />)}</div> :
        <div className="empty-state"><h3>No squads yet</h3><p>Create the first study squad and invite classmates.</p></div>}
      <CreateSquadModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onCreate={createSquad} />
    </section>
  );
}
