import React, { useEffect, useState } from 'react';
import PomodoroTimer from './PomodoroTimer';
import StreakTracker from './StreakTracker';
import { CheckCircle2, Circle, Plus, Trash2, Users, Target } from 'lucide-react';
import { api } from '../utils/api';

export default function SquadWorkspace() {
  const [tasks, setTasks] = useState([]);
  const [tasksLoading, setTasksLoading] = useState(true);
  const [taskError, setTaskError] = useState('');
  const [newTask, setNewTask] = useState('');

  useEffect(() => {
    let active = true;
    api.getWorkspaceTasks().then(result => { if (active) setTasks(result.tasks || []); })
      .catch(err => { if (active) setTaskError(err.message || 'Unable to load shared tasks.'); })
      .finally(() => { if (active) setTasksLoading(false); });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    let disposed = false;
    let socket;
    let retryTimer;
    let retryDelay = 1000;
    const connect = () => {
      if (disposed) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      socket = new WebSocket(`${protocol}//${window.location.host}/ws`);
      socket.onopen = () => { retryDelay = 1000; };
      socket.onmessage = event => {
        try { const message = JSON.parse(event.data); if (message.type === 'workspace:updated' && Array.isArray(message.tasks)) setTasks(message.tasks); }
        catch (err) { console.warn('Ignoring malformed workspace update.', err); }
      };
      socket.onerror = () => socket?.close();
      socket.onclose = () => {
        if (!disposed) { retryTimer = window.setTimeout(connect, retryDelay); retryDelay = Math.min(retryDelay * 2, 15000); }
      };
    };
    connect();
    return () => { disposed = true; window.clearTimeout(retryTimer); socket?.close(); };
  }, []);

  useEffect(() => {
    if (tasksLoading || taskError) return undefined;
    const timer = window.setTimeout(() => api.saveWorkspaceTasks(tasks).catch(err => setTaskError(err.message || 'Unable to save shared tasks.')), 350);
    return () => window.clearTimeout(timer);
  }, [tasks, tasksLoading, taskError]);

  const addTask = event => {
    event.preventDefault();
    const text = newTask.trim();
    if (!text) return;
    setTasks(current => [...current, { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, text, done: false }]);
    setNewTask('');
  };
  const completed = tasks.filter(task => task.done).length;

  return (
    <section>
      <div className="section-heading"><div><p className="eyebrow">SYNCHRONIZED FOCUS WORKSPACE</p><h2>Make this session count</h2><p className="muted">A shared-session layout with a focus timer, goals, and progress tracking.</p></div><span className="live-pill"><span /> Workspace active</span></div>
      <div className="workspace-banner glass-card"><div className="workspace-icon"><Users size={22} /></div><div><strong>Study together, stay accountable</strong><p className="muted">Keep the session goal visible, work in focused intervals, and check off progress as your squad moves forward.</p></div></div>
      <div className="grid-responsive workspace-grid">
        <PomodoroTimer />
        <StreakTracker />
      </div>
      <section className="glass-card task-panel">
        <div className="task-header"><div><p className="eyebrow">SESSION PLAN</p><h3><Target size={19} /> Session target checklist</h3></div><span className="progress-count">{completed}/{tasks.length} complete</span></div>
        <div className="progress-track"><span style={{ width: `${tasks.length ? completed / tasks.length * 100 : 0}%` }} /></div>
        {taskError && <div className="alert error-alert">{taskError}</div>}
        {tasksLoading ? <p className="muted">Loading shared session tasks…</p> : <ul className="task-list">{tasks.map(task => <li key={task.id}>
          <button className={`task-toggle ${task.done ? 'done' : ''}`} onClick={() => setTasks(current => current.map(item => item.id === task.id ? { ...item, done: !item.done } : item))} aria-label={task.done ? 'Mark task incomplete' : 'Mark task complete'}>{task.done ? <CheckCircle2 size={20} /> : <Circle size={20} />}</button>
          <span className={task.done ? 'task-done' : ''}>{task.text}</span>
          <button className="icon-button subtle" onClick={() => setTasks(current => current.filter(item => item.id !== task.id))} aria-label="Delete task"><Trash2 size={15} /></button>
        </li>)}</ul>}
        <form className="add-task-form" onSubmit={addTask}><input value={newTask} onChange={e => setNewTask(e.target.value)} placeholder="Add a session task…" maxLength="120" /><button className="secondary-button" disabled={!newTask.trim()}><Plus size={16} /> Add task</button></form>
        <p className="muted tiny-note">Checklist changes are saved to the shared workspace and broadcast to connected squad members.</p>
      </section>
    </section>
  );
}
