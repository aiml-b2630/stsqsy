import React, { useEffect, useState } from 'react';
import { Play, Pause, RotateCcw, Coffee, Brain, Bell } from 'lucide-react';

const FOCUS_SECONDS = 25 * 60;
const BREAK_SECONDS = 5 * 60;

export default function PomodoroTimer() {
  const [mode, setMode] = useState('focus');
  const [remaining, setRemaining] = useState(FOCUS_SECONDS);
  const [running, setRunning] = useState(false);
  const [completedCycles, setCompletedCycles] = useState(0);

  useEffect(() => {
    if (!running) return undefined;
    const timer = window.setTimeout(() => {
      if (remaining <= 1) {
        setRunning(false);
        if (mode === 'focus') {
          setMode('break');
          setCompletedCycles(count => count + 1);
          setRemaining(BREAK_SECONDS);
        } else {
          setMode('focus');
          setRemaining(FOCUS_SECONDS);
        }
      } else {
        setRemaining(value => value - 1);
      }
    }, 1000);
    return () => window.clearTimeout(timer);
  }, [running, remaining, mode]);

  const reset = () => { setRunning(false); setMode('focus'); setRemaining(focusMinutes * 60); };\n  const changeFocus = value => { const n = Math.max(5, Math.min(90, Number(value) || 25)); setFocusMinutes(n); if (mode === 'focus' && !running) setRemaining(n * 60); };\n  const changeBreak = value => { const n = Math.max(1, Math.min(30, Number(value) || 5)); setBreakMinutes(n); if (mode === 'break' && !running) setRemaining(n * 60); };
  const minutes = String(Math.floor(remaining / 60)).padStart(2, '0');
  const seconds = String(remaining % 60).padStart(2, '0');
  const progress = ((mode === 'focus' ? FOCUS_SECONDS : BREAK_SECONDS) - remaining) / (mode === 'focus' ? FOCUS_SECONDS : BREAK_SECONDS) * 100;

  return (
    <section className="glass-card pomodoro-card">
      <div className="timer-heading"><div><p className="eyebrow">POMODORO TIMER</p><h3>{mode === 'focus' ? <Brain size={19} /> : <Coffee size={19} />} {mode === 'focus' ? 'Deep focus' : 'Take a break'}</h3></div><span className="cycle-count">{completedCycles} cycles completed</span></div>
      <div className="timer-ring" style={{ '--progress': `${progress}%` }}><div><strong>{minutes}:{seconds}</strong><span>{mode === 'focus' ? 'FOCUS SESSION' : 'BREAK TIME'}</span></div></div>
      <p className="timer-caption">{mode === 'focus' ? 'One task at a time. You’ve got this.' : 'Step away, stretch, and recharge.'}</p>
      <div className="timer-actions"><button className="primary-button" onClick={() => setRunning(value => !value)}>{running ? <Pause size={16} /> : <Play size={16} />}{running ? 'Pause' : 'Start timer'}</button><button className="secondary-button" onClick={reset}><RotateCcw size={16} /> Reset</button></div>
      <div className="timer-hint"><Bell size={14} /> Focus: {focusMinutes} min <span>•</span> Break: {breakMinutes} min</div>
      <div className="timer-settings"><label>Focus minutes <input type="number" min="5" max="90" value={focusMinutes} onChange={e => changeFocus(e.target.value)} disabled={running}/></label><label>Break minutes <input type="number" min="1" max="30" value={breakMinutes} onChange={e => changeBreak(e.target.value)} disabled={running}/></label></div>
    </section>
  );
}
