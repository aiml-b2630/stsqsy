import React, { useState } from 'react';
import { Radio, LockKeyhole, UserRound } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function LoginScreen() {
  const { login, loading, error } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [localError, setLocalError] = useState('');

  const submit = async event => {
    event.preventDefault();
    setLocalError('');
    if (!username.trim() || !password) {
      setLocalError('Enter both your username and password.');
      return;
    }
    try { await login(username, password); }
    catch { /* The provider exposes the server error. */ }
  };

  return (
    <main className="auth-shell">
      <section className="glass-card auth-card">
        <div className="brand-mark"><Radio size={28} /><span>StudySquad Sync</span></div>
        <p className="eyebrow">SMART CAMPUS • BETTER STUDY SESSIONS</p>
        <h1>Welcome back</h1>
        <p className="muted">Sign in to find a study space, connect with a squad, and focus together.</p>
        <form onSubmit={submit} className="stack-form">
          <label>Username
            <span className="input-wrap"><UserRound size={17} /><input autoComplete="username" value={username} onChange={e => setUsername(e.target.value)} placeholder="Your username" /></span>
          </label>
          <label>Password
            <span className="input-wrap"><LockKeyhole size={17} /><input type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Your password" /></span>
          </label>
          {(localError || error) && <p className="form-error">{localError || error}</p>}
          <button className="primary-button" disabled={loading}>{loading ? 'Signing in…' : 'Sign in'}</button>
        </form>
        <p className="auth-note">Use the student credentials configured for your StudySquad API.</p>
      </section>
    </main>
  );
}
