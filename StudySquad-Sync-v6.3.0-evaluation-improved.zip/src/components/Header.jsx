import React from 'react';
import { Shield, Radio, Users, BookOpen, Clock, Moon, Sun, LogOut, Menu } from 'lucide-react';

const tabs = [
  { id: 'radar', label: 'Room Radar', Icon: Radio },
  { id: 'squads', label: 'Study Squads', Icon: Users },
  { id: 'workspace', label: 'Focus Workspace', Icon: Clock },
  { id: 'how', label: 'How It Works', Icon: BookOpen }
];

export default function Header({ activeTab, setActiveTab, theme, toggleTheme, user, onLogout }) {
  return (
    <header className="topbar glass-card">
      <div className="brand">
        <span className="brand-icon"><Radio size={25} /></span>
        <div><h1>StudySquad Sync</h1><p>Smart Campus Room Radar & Peer Matching</p></div>
      </div>
      <nav className="main-nav" aria-label="Main navigation">
        {tabs.map(({ id, label, Icon }) => (
          <button key={id} className={`nav-button ${activeTab === id ? 'active' : ''}`} onClick={() => setActiveTab(id)}>
            <Icon size={16} /><span>{label}</span>
          </button>
        ))}
      </nav>
      <div className="header-actions">
        <span className="user-chip"><Shield size={14} /> {user?.username || 'Student'}</span>
        <button className="icon-button" onClick={toggleTheme} aria-label="Toggle theme">{theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}</button>
        <button className="icon-button" onClick={onLogout} aria-label="Sign out"><LogOut size={18} /></button>
      </div>
    </header>
  );
}
