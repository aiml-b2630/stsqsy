import React from 'react';
import { Volume2, Users, Clock, MapPin, Zap } from 'lucide-react';

export default function RoomCard({ room, onReserve }) {
  const status = room.status || 'available';
  const isAvailable = status === 'available';
  const occupancy = `${room.occupied_chairs ?? 0} / ${room.capacity}`;
  return (
    <article className="room-card glass-card">
      <div className="card-topline"><span className={`status-pill ${status}`}>{status}</span><span className="room-floor"><MapPin size={13} /> {room.floor}</span></div>
      <h3>{room.name}</h3><p className="muted room-building">{room.building}</p>
      <div className="room-metrics">
        <span><Users size={15} /> {occupancy} seats</span><span><Volume2 size={15} /> {room.noise_db ?? '—'} dB</span>
      </div>
      <div className="amenity-list">{(room.amenities || []).map(item => <span key={item}><Zap size={11} />{item}</span>)}</div>
      <button className={isAvailable ? 'primary-button' : 'secondary-button'} disabled={!isAvailable} onClick={() => onReserve(room.id)}>
        <Clock size={16} /> {isAvailable ? 'Place 20-minute hold' : status === 'reserved' ? 'Temporarily held' : 'Currently occupied'}
      </button>
    </article>
  );
}
