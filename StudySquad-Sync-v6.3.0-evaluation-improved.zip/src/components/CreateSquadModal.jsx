import React, { useState } from 'react';
import { validateSquadInput } from '../utils/validationSchemas';
import { X } from 'lucide-react';

const initialForm = { title: '', subject: 'Computer Science', max_members: 4, schedule: 'Afternoon', target_goal: '', room_name: 'Library Pod A1' };

export default function CreateSquadModal({ isOpen, onClose, onCreate }) {
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [serverError, setServerError] = useState('');
  if (!isOpen) return null;

  const update = (key, value) => setFormData(current => ({ ...current, [key]: value }));
  const handleSubmit = async event => {
    event.preventDefault();
    const validation = validateSquadInput(formData);
    if (!validation.isValid) { setErrors(validation.errors); return; }
    setSaving(true); setServerError('');
    try { await onCreate(formData); setFormData(initialForm); setErrors({}); onClose(); }
    catch (err) { setServerError(err.message || 'Unable to create squad.'); }
    finally { setSaving(false); }
  };

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="modal-card glass-card" role="dialog" aria-modal="true" aria-labelledby="create-squad-title">
        <div className="modal-heading"><div><p className="eyebrow">BUILD YOUR TEAM</p><h2 id="create-squad-title">Create a study squad</h2></div><button className="icon-button" onClick={onClose} aria-label="Close"><X size={18} /></button></div>
        <form onSubmit={handleSubmit} className="stack-form">
          <label>Squad title<input required maxLength="80" value={formData.title} onChange={e => update('title', e.target.value)} placeholder="e.g. Data Structures Revision" />{errors.title && <small className="form-error">{errors.title}</small>}</label>
          <label>Subject<input required maxLength="50" value={formData.subject} onChange={e => update('subject', e.target.value)} /></label>
          <div className="form-grid">
            <label>Maximum members<input type="number" min="2" max="12" value={formData.max_members} onChange={e => update('max_members', Number(e.target.value))} /></label>
            <label>Schedule<select value={formData.schedule} onChange={e => update('schedule', e.target.value)}><option>Morning</option><option>Afternoon</option><option>Late Night</option></select></label>
          </div>
          <label>Session goal<input required maxLength="160" value={formData.target_goal} onChange={e => update('target_goal', e.target.value)} placeholder="What will your squad accomplish?" /></label>
          <label>Preferred room<input value={formData.room_name} onChange={e => update('room_name', e.target.value)} /></label>
          {serverError && <p className="form-error">{serverError}</p>}
          <div className="modal-actions"><button type="button" className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" disabled={saving}>{saving ? 'Creating…' : 'Create squad'}</button></div>
        </form>
      </section>
    </div>
  );
}
