import React from 'react';
import { Award, Flame, Timer, CheckCircle2 } from 'lucide-react';

export default function StreakTracker() {
  return (
    <section className="glass-card streak-card">
      <div className="streak-top"><span className="streak-icon"><Flame size={25} /></span><span className="subject-tag">STUDY MOMENTUM</span></div>
      <p className="eyebrow">YOUR FOCUS HABITS</p><h3>Build a steady rhythm</h3>
      <p className="muted">Complete focus cycles and session goals to build a consistent study routine.</p>
      <div className="streak-metrics"><div><Timer size={18} /><strong>25 min</strong><span>Focus interval</span></div><div><CheckCircle2 size={18} /><strong>1 goal</strong><span>At a time</span></div></div>
      <div className="streak-foot"><Award size={16} /> Every completed session is progress.</div>
    </section>
  );
}
