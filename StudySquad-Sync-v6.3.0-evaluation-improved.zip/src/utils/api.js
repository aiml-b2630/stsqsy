const API_BASE = import.meta.env.VITE_API_BASE || '/api';

export async function fetchApi(endpoint, options = {}) {
  const token = localStorage.getItem('studysquad_token');
  const headers = {
    ...(options.body ? { 'Content-Type': 'application/json' } : {}),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers
  };

  const response = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json() : null;
  if (!response.ok) throw new Error(data?.error || `Request failed (${response.status})`);
  return data;
}

export const api = {
  getRooms: () => fetchApi('/rooms'),
  reserveRoom: (id, version, duration_minutes = 20) => fetchApi(`/rooms/${id}/reserve`, {
    method: 'POST', body: JSON.stringify({ version, duration_minutes })
  }),
  releaseRoom: id => fetchApi(`/rooms/${id}/release`, { method: 'POST', body: JSON.stringify({}) }),
  getSquads: () => fetchApi('/squads'),
  createSquad: squadData => fetchApi('/squads', { method: 'POST', body: JSON.stringify(squadData) }),
  joinSquad: id => fetchApi(`/squads/${id}/join`, { method: 'POST', body: JSON.stringify({}) }),
  getWorkspaceTasks: () => fetchApi('/workspace/tasks'),
  saveWorkspaceTasks: tasks => fetchApi('/workspace/tasks', { method: 'PUT', body: JSON.stringify({ tasks }) }),
  login: (username, password) => fetchApi('/auth/login', {
    method: 'POST', body: JSON.stringify({ username, password })
  })
};
