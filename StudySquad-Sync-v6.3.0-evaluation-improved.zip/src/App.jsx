import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { SquadProvider } from './contexts/SquadContext';
import ErrorBoundary from './components/ErrorBoundary';
import Header from './components/Header';
import LoginScreen from './components/LoginScreen';
import RoomVisualizer from './components/RoomVisualizer';
import SquadMatcher from './components/SquadMatcher';
import SquadWorkspace from './components/SquadWorkspace';
import HowItWorks from './components/HowItWorks';
import './styles/custom.css';

function Application() {
  const { isAuthenticated, logout, user } = useAuth();
  const [activeTab, setActiveTab] = useState('radar');
  const [theme, setTheme] = useState(() => localStorage.getItem('studysquad_theme') || 'dark');

  React.useEffect(() => { document.documentElement.setAttribute('data-theme', theme); }, [theme]);
  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('studysquad_theme', next);
    setTheme(next);
  };

  if (!isAuthenticated) return <LoginScreen />;

  return (
    <SquadProvider>
      <div className="app-shell">
        <Header activeTab={activeTab} setActiveTab={setActiveTab} theme={theme} toggleTheme={toggleTheme} user={user} onLogout={logout} />
        <main className="main-content">
          {activeTab === 'radar' && <RoomVisualizer />}
          {activeTab === 'squads' && <SquadMatcher onOpenWorkspace={() => setActiveTab('workspace')} />}
          {activeTab === 'workspace' && <SquadWorkspace />}
          {activeTab === 'how' && <HowItWorks />}
        </main>
        <footer className="app-footer">StudySquad Sync <span>•</span> Find your space. Find your people. Find your focus.</footer>
      </div>
    </SquadProvider>
  );
}

export default function App() {
  return <ErrorBoundary><AuthProvider><Application /></AuthProvider></ErrorBoundary>;
}
