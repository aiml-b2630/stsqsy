import React, { createContext, useContext, useMemo, useState } from 'react';
import { api } from '../utils/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('studysquad_token'));
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('studysquad_user') || 'null'); }
    catch { return null; }
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const login = async (username, password) => {
    setLoading(true);
    setError('');
    try {
      const result = await api.login(username.trim(), password);
      if (!result?.token || !result?.user) throw new Error('The server returned an invalid login response.');
      localStorage.setItem('studysquad_token', result.token);
      localStorage.setItem('studysquad_user', JSON.stringify(result.user));
      setToken(result.token);
      setUser(result.user);
      return result.user;
    } catch (err) {
      setError(err.message || 'Unable to sign in.');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('studysquad_token');
    localStorage.removeItem('studysquad_user');
    setToken(null);
    setUser(null);
  };

  const value = useMemo(() => ({
    user, token, loading, error, isAuthenticated: Boolean(token && user), login, logout
  }), [user, token, loading, error]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
