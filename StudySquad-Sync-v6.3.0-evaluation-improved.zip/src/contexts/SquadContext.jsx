import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from '../utils/api';

const SquadContext = createContext(null);

export function SquadProvider({ children }) {
  const [rooms, setRooms] = useState([]);
  const [squads, setSquads] = useState([]);
  const [activeHold, setActiveHold] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    setError('');
    try {
      const [roomResult, squadResult] = await Promise.all([api.getRooms(), api.getSquads()]);
      setRooms(roomResult.rooms || []);
      setSquads(squadResult.squads || []);
    } catch (err) {
      setError(err.message || 'Unable to load StudySquad data.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  // Reconnect safely if the WebSocket server restarts or the network drops.
  useEffect(() => {
    let socket;
    let retryTimer;
    let disposed = false;
    const connect = () => {
      if (disposed) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      socket = new WebSocket(`${protocol}//${window.location.host}/ws`);
      socket.onmessage = event => {
        try {
          const message = JSON.parse(event.data);
          if ((message.type === 'rooms:snapshot' || message.type === 'rooms:updated') && Array.isArray(message.rooms)) {
            setRooms(message.rooms);
          }
        } catch (err) { console.error('Invalid room update received.', err); }
      };
      socket.onclose = () => { if (!disposed) retryTimer = window.setTimeout(connect, 2500); };
      socket.onerror = () => socket?.close();
    };
    connect();
    return () => {
      disposed = true;
      window.clearTimeout(retryTimer);
      socket?.close();
    };
  }, []);

  const reserveRoomHold = useCallback(async roomId => {
    const room = rooms.find(item => String(item.id) === String(roomId));
    if (!room || room.status !== 'available') throw new Error('This room is no longer available.');
    const result = await api.reserveRoom(room.id, room.version, 20);
    if (result?.room) {
      setRooms(current => current.map(item => item.id === result.room.id ? result.room : item));
      setActiveHold({
        roomId: result.room.id,
        roomName: result.room.name,
        holdUntil: result.room.hold_until
      });
    }
    return result;
  }, [rooms]);

  const releaseHold = useCallback(async roomId => {
    await api.releaseRoom(roomId);
    setActiveHold(null);
    await refresh();
  }, [refresh]);

  const createSquad = useCallback(async squadData => {
    const result = await api.createSquad(squadData);
    if (result?.squad) setSquads(current => [result.squad, ...current]);
    return result?.squad;
  }, []);

  const joinSquad = useCallback(async squadId => {
    const result = await api.joinSquad(squadId);
    if (result?.squad) setSquads(current => current.map(item => item.id === result.squad.id ? result.squad : item));
    return result?.squad;
  }, []);

  const value = useMemo(() => ({
    rooms, squads, activeHold, loading, error, refresh,
    reserveRoomHold, releaseHold, createSquad, joinSquad
  }), [rooms, squads, activeHold, loading, error, refresh, reserveRoomHold, releaseHold, createSquad, joinSquad]);

  return <SquadContext.Provider value={value}>{children}</SquadContext.Provider>;
}

export const useSquad = () => useContext(SquadContext);
