import React, { createContext, useContext, useState } from 'react';
import { useIoTSensorSim } from '../hooks/useIoTSensorSim';

const SquadContext = createContext();

const initialRooms = [
  { id: 'room-1', name: 'Library Discussion Pod 3A', building: 'Central Library', floor: 3, capacity: 4, occupiedSeats: 2, status: 'available', noiseLevel: 38, amenities: ['Whiteboard', 'Power Sockets'], version: 1 },
  { id: 'room-2', name: 'Silent Study Alcove 4B', building: 'Central Library', floor: 4, capacity: 2, occupiedSeats: 2, status: 'occupied', noiseLevel: 32, amenities: ['Silent Zone', 'Power Sockets'], version: 1 },
  { id: 'room-3', name: 'Engineering Lab Workroom 102', building: 'Engineering Block', floor: 1, capacity: 6, occupiedSeats: 3, status: 'available', noiseLevel: 55, amenities: ['Whiteboard', 'Dual Monitors', 'Group Discussion'], version: 1 },
  { id: 'room-4', name: 'Student Center Collab Lounge', building: 'Student Union', floor: 2, capacity: 8, occupiedSeats: 4, status: 'available', noiseLevel: 62, amenities: ['Group Discussion', 'Whiteboard'], version: 1 },
  { id: 'room-5', name: 'Math & Physics Tower Room 204', building: 'Science Complex', floor: 2, capacity: 4, occupiedSeats: 4, status: 'occupied', noiseLevel: 45, amenities: ['Whiteboard', 'Silent Zone'], version: 1 },
  { id: 'room-6', name: 'CS Research Discussion Pod 1', building: 'Tech Hall', floor: 3, capacity: 5, occupiedSeats: 1, status: 'available', noiseLevel: 40, amenities: ['Dual Monitors', 'Power Sockets', 'Whiteboard'], version: 1 }
];

const initialSquads = [
  { id: 'sq-101', title: 'Operating Systems Finals Prep', subject: 'Computer Science', topic: 'Virtual Memory & Concurrency', meetingTime: '4:00 PM', scheduleBlock: 'Afternoon', maxSize: 4, currentMembers: 3, location: 'Library Pod 3A', creatorId: 'alex_r', members: ['Alex Rivera', 'Jordan Lee', 'Taylor Swift'] },
  { id: 'sq-102', title: 'Linear Algebra Problem Set 4', subject: 'Mathematics', topic: 'Eigenvalues & Diagonalization', meetingTime: '6:30 PM', scheduleBlock: 'Evening', maxSize: 5, currentMembers: 2, location: 'Math Tower 204', creatorId: 'sam_k', members: ['Sam Kim', 'Morgan Vance'] },
  { id: 'sq-103', title: 'Data Structures Sprint', subject: 'Computer Science', topic: 'Red-Black Trees & Graphs', meetingTime: '8:00 PM', scheduleBlock: 'Late Night', maxSize: 4, currentMembers: 4, location: 'CS Tech Pod 1', creatorId: 'devon_p', members: ['Devon P.', 'Chris T.', 'Pat M.', 'Sasha R.'] }
];

export function SquadProvider({ children }) {
  const [rooms, setRooms] = useState(initialRooms);
  const [squads, setSquads] = useState(initialSquads);
  const [activeHold, setActiveHold] = useState(null);
  const [activeSquad, setActiveSquad] = useState(initialSquads[0]);
  const [toast, setToast] = useState(null);

  useIoTSensorSim(setRooms);

  const showToast = (message, type = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const placeRoomHold = (roomId, studentName) => {
    const room = rooms.find(r => r.id === roomId);
    if (!room || room.status !== 'available') {
      showToast("Room is no longer available for hold.", "error");
      return false;
    }

    const holdExpiresAt = Date.now() + 20 * 60 * 1000;
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, status: 'reserved', holdExpiresAt, heldByStudent: studentName, version: r.version + 1 } : r));
    setActiveHold({ roomId, roomName: room.name, holdExpiresAt });
    showToast(`20-Minute Hold placed on ${room.name}!`, 'success');
    return true;
  };

  const releaseRoomHold = (roomId) => {
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, status: 'available', holdExpiresAt: null, heldByStudent: null } : r));
    if (activeHold && activeHold.roomId === roomId) {
      setActiveHold(null);
    }
    showToast("Hold released back to campus availability.", "info");
  };

  const createSquad = (squadData) => {
    const newSquad = {
      id: 'sq_' + Date.now(),
      ...squadData,
      currentMembers: 1,
      creatorId: 'user_alex',
      members: ['Alex Rivera']
    };
    setSquads(prev => [newSquad, ...prev]);
    setActiveSquad(newSquad);
    showToast(`Study Squad '${newSquad.title}' created!`, 'success');
  };

  const joinSquad = (squadId) => {
    setSquads(prev => prev.map(sq => {
      if (sq.id === squadId && sq.currentMembers < sq.maxSize) {
        const updated = { ...sq, currentMembers: sq.currentMembers + 1, members: [...sq.members, 'Alex Rivera'] };
        setActiveSquad(updated);
        showToast(`Joined squad '${sq.title}'!`, 'success');
        return updated;
      }
      return sq;
    }));
  };

  return (
    <SquadContext.Provider value={{ rooms, squads, activeHold, activeSquad, setActiveSquad, placeRoomHold, releaseRoomHold, createSquad, joinSquad, toast, showToast }}>
      {children}
    </SquadContext.Provider>
  );
}

export function useSquad() {
  return useContext(SquadContext);
}
