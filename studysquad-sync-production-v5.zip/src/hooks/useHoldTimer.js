import { useState, useEffect } from 'react';

export function useHoldTimer(initialExpiresAt, onExpired) {
  const [timeLeft, setTimeLeft] = useState(() => {
    if (!initialExpiresAt) return 0;
    return Math.max(0, Math.floor((initialExpiresAt - Date.now()) / 1000));
  });

  useEffect(() => {
    if (!initialExpiresAt) return;
    const interval = setInterval(() => {
      const remaining = Math.max(0, Math.floor((initialExpiresAt - Date.now()) / 1000));
      setTimeLeft(remaining);
      if (remaining === 0) {
        clearInterval(interval);
        if (onExpired) onExpired();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [initialExpiresAt, onExpired]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return {
    timeLeft,
    formatted: `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`,
    isExpired: timeLeft === 0
  };
}
