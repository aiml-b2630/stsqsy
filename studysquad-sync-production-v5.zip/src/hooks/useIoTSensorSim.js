import { useEffect } from 'react';

export function useIoTSensorSim(setRooms) {
  useEffect(() => {
    const interval = setInterval(() => {
      setRooms(prevRooms => prevRooms.map(room => {
        if (room.status === 'reserved') return room; // Protect active holds

        // Simulate random motion sensor seating change & decibel noise meter fluctuation
        const seatsDelta = Math.random() > 0.6 ? (Math.random() > 0.5 ? 1 : -1) : 0;
        const newSeats = Math.min(room.capacity, Math.max(0, room.occupiedSeats + seatsDelta));
        const noiseDelta = Math.floor(Math.random() * 7) - 3;
        const newNoise = Math.min(75, Math.max(30, room.noiseLevel + noiseDelta));

        let newStatus = room.status;
        if (newSeats === 0) newStatus = 'available';
        else if (newSeats >= room.capacity) newStatus = 'occupied';

        return {
          ...room,
          occupiedSeats: newSeats,
          noiseLevel: newNoise,
          status: newStatus
        };
      }));
    }, 6000);

    return () => clearInterval(interval);
  }, [setRooms]);
}
