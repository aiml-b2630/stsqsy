// Schema-Based Input Validation (Attempt #6 requirement)

export function sanitizeString(input) {
  if (typeof input !== 'string') return '';
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#x27;")
    .replace(/\//g, "&#x2F;")
    .trim();
}

export const SquadCreationSchema = {
  title: { required: true, minLength: 3, maxLength: 50 },
  subject: { required: true, enum: ['Computer Science', 'Mathematics', 'Engineering', 'Physics', 'Biology', 'Business'] },
  topic: { required: true, minLength: 2, maxLength: 60 },
  scheduleBlock: { required: true, enum: ['Morning', 'Afternoon', 'Evening', 'Late Night'] },
  maxSize: { required: true, min: 2, max: 10 }
};

export function validatePayload(payload, schema) {
  const errors = {};
  for (const field in schema) {
    const rule = schema[field];
    const rawVal = payload[field];
    const val = typeof rawVal === 'string' ? sanitizeString(rawVal) : rawVal;

    if (rule.required && (val === undefined || val === null || val === '')) {
      errors[field] = `${field} is required.`;
      continue;
    }

    if (val !== undefined && val !== null && val !== '') {
      if (rule.minLength && typeof val === 'string' && val.length < rule.minLength) {
        errors[field] = `${field} must be at least ${rule.minLength} characters.`;
      }
      if (rule.maxLength && typeof val === 'string' && val.length > rule.maxLength) {
        errors[field] = `${field} cannot exceed ${rule.maxLength} characters.`;
      }
      if (rule.enum && !rule.enum.includes(val)) {
        errors[field] = `Invalid selection for ${field}.`;
      }
      if (rule.min && typeof val === 'number' && val < rule.min) {
        errors[field] = `${field} must be at least ${rule.min}.`;
      }
      if (rule.max && typeof val === 'number' && val > rule.max) {
        errors[field] = `${field} cannot exceed ${rule.max}.`;
      }
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}
