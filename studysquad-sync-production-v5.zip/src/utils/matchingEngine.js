// Multi-Dimensional Vector & Jaccard Subject Matching Engine
export function computeJaccardSimilarity(textA, textB) {
  const setA = new Set(textA.toLowerCase().split(/\s+/));
  const setB = new Set(textB.toLowerCase().split(/\s+/));
  const intersection = new Set([...setA].filter(x => setB.has(x)));
  const union = new Set([...setA, ...setB]);
  if (union.size === 0) return 0;
  return intersection.size / union.size;
}

export function computeScheduleScore(blockA, blockB) {
  if (blockA === blockB) return 1.0;
  const blocks = ['Morning', 'Afternoon', 'Evening', 'Late Night'];
  const indexA = blocks.indexOf(blockA);
  const indexB = blocks.indexOf(blockB);
  if (indexA !== -1 && indexB !== -1 && Math.abs(indexA - indexB) === 1) {
    return 0.5; // Adjacent time block partial score
  }
  return 0.0;
}

export function rankSquadMatches(userPrefs, squads) {
  return squads.map(squad => {
    const jaccardSubj = computeJaccardSimilarity(userPrefs.subject || '', squad.subject || '');
    const jaccardTopic = computeJaccardSimilarity(userPrefs.topic || '', squad.topic || '');
    const subjectScore = (jaccardSubj * 0.7) + (jaccardTopic * 0.3);
    const scheduleScore = computeScheduleScore(userPrefs.scheduleBlock, squad.scheduleBlock);
    
    // Weighted combination score
    const totalMatchScore = Math.round(((subjectScore * 0.55) + (scheduleScore * 0.45)) * 100);

    return {
      ...squad,
      matchScore: totalMatchScore,
      subjectScorePercent: Math.round(subjectScore * 100),
      scheduleScorePercent: Math.round(scheduleScore * 100)
    };
  }).sort((a, b) => b.matchScore - a.matchScore);
}
