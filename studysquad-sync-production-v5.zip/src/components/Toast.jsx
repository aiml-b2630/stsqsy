import React from 'react';
import { CheckCircle2, AlertCircle, Info } from 'lucide-react';

export function Toast({ toast }) {
  if (!toast) return null;
  const icons = {
    success: <CheckCircle2 size={18} color="#10B981" />,
    error: <AlertCircle size={18} color="#EF4444" />,
    info: <Info size={18} color="#3B82F6" />
  };

  return (
    <div className={`toast-container toast-${toast.type}`}>
      {icons[toast.type] || icons.info}
      <span>{toast.message}</span>
    </div>
  );
}
