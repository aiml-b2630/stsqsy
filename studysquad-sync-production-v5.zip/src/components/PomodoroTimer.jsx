import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Flame } from 'lucide-react';

export function PomodoroTimer() {
  const [minutes, setMinutes] = useState(25);
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState('focus'); // focus or break

  useEffect(() => {
    let interval = null;
    if (isActive) {
      interval = setInterval(() => {
        if (seconds > 0) {
          setSeconds(seconds - 1);
        } else if (minutes > 0) {
          setMinutes(minutes - 1);
          setSeconds(59);
        } else {
          setIsActive(false);
          if (mode === 'focus') {
            setMode('break');
            setMinutes(5);
          } else {
            setMode('focus');
            setMinutes(25);
          }
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isActive, minutes, seconds, mode]);

  return (
    <div className="pomodoro-card glass-panel">
      <h3>Synchronized Squad Focus Timer</h3>
      <span className="mode-badge">{mode === 'focus' ? '🎯 25-Min Focus Sprint' : '☕ 5-Min Rest Break'}</span>
      <div className="pomodoro-time">
        {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
      </div>
      <div className="timer-controls">
        <button className="btn-primary" onClick={() => setIsActive(!isActive)}>
          {isActive ? <Pause size={16} /> : <Play size={16} />} {isActive ? 'Pause' : 'Start'}
        </button>
        <button className="btn-secondary" onClick={() => { setIsActive(false); setMinutes(25); setSeconds(0); }}>
          <RotateCcw size={16} /> Reset
        </button>
      </div>
    </div>
  );
}
