import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import { RoomCard } from './RoomCard';
import { HoldTimerModal } from './HoldTimerModal';
import { Filter, SlidersHorizontal, MapPin } from 'lucide-react';

export function RoomVisualizer() {
  const { rooms } = useSquad();
  const [selectedAmenity, setSelectedAmenity] = useState('All');
  const [selectedBuilding, setSelectedBuilding] = useState('All');
  const [selectedRoomForHold, setSelectedRoomForHold] = useState(null);

  const filteredRooms = rooms.filter(room => {
    const matchesAmenity = selectedAmenity === 'All' || room.amenities.includes(selectedAmenity);
    const matchesBuilding = selectedBuilding === 'All' || room.building === selectedBuilding;
    return matchesAmenity && matchesBuilding;
  });

  return (
    <div className="view-container">
      <div className="view-header">
        <div>
          <h2><MapPin size={24} /> RoomRadar Telemetry & Hold System</h2>
          <p>Real-time campus library & facility room occupancy visualization (PIR Motion & Noise Meter Sim)</p>
        </div>
        <div className="filter-controls">
          <div className="select-wrapper">
            <Filter size={14} />
            <select value={selectedAmenity} onChange={e => setSelectedAmenity(e.target.value)}>
              <option value="All">All Amenities</option>
              <option value="Whiteboard">Whiteboard</option>
              <option value="Power Sockets">Power Sockets</option>
              <option value="Silent Zone">Silent Zone</option>
              <option value="Dual Monitors">Dual Monitors</option>
            </select>
          </div>
          <div className="select-wrapper">
            <SlidersHorizontal size={14} />
            <select value={selectedBuilding} onChange={e => setSelectedBuilding(e.target.value)}>
              <option value="All">All Buildings</option>
              <option value="Central Library">Central Library</option>
              <option value="Engineering Block">Engineering Block</option>
              <option value="Student Union">Student Union</option>
              <option value="Science Complex">Science Complex</option>
            </select>
          </div>
        </div>
      </div>

      <div className="room-grid">
        {filteredRooms.map(room => (
          <RoomCard key={room.id} room={room} onSelectHold={setSelectedRoomForHold} />
        ))}
      </div>

      {selectedRoomForHold && (
        <HoldTimerModal room={selectedRoomForHold} onClose={() => setSelectedRoomForHold(null)} />
      )}
    </div>
  );
}
