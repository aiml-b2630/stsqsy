import React from 'react';
import { useHoldTimer } from '../hooks/useHoldTimer';
import { useSquad } from '../context/SquadContext';
import { Clock, ShieldAlert, CheckCircle } from 'lucide-react';

export function HoldTimerModal({ room, onClose }) {
  const { placeRoomHold, releaseRoomHold, activeHold } = useSquad();
  const { formatted, isExpired } = useHoldTimer(activeHold?.holdExpiresAt, () => releaseRoomHold(room.id));

  const handleConfirmHold = () => {
    placeRoomHold(room.id, 'Alex Rivera');
  };

  return (
    <div className="modal-backdrop">
      <div className="modal-content glass-panel">
        <div className="modal-header">
          <h2><Clock size={22} /> 20-Minute Temporary Room Hold</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>

        <div className="modal-body">
          <p className="modal-desc">
            Lock seat availability in <strong>{room.name}</strong> for 20 minutes while walking across campus. Ghost bookings automatically release if unconfirmed.
          </p>

          {activeHold?.roomId === room.id ? (
            <div className="countdown-box">
              <span className="countdown-label">Time Remaining En Route</span>
              <div className="countdown-digits">{formatted}</div>
              <p className="countdown-sub">Status: Locked via Version {room.version}</p>
              <button className="btn-danger full-width" onClick={() => releaseRoomHold(room.id)}>
                Release Hold Early
              </button>
            </div>
          ) : (
            <div className="confirm-box">
              <div className="room-summary-chip">
                <span>{room.building} Pod</span> • <span>{room.capacity} Max Chairs</span> • <span>{room.noiseLevel} dB</span>
              </div>
              <button className="btn-primary full-width margin-top" onClick={handleConfirmHold}>
                <CheckCircle size={18} /> Confirm 20-Minute Hold
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
