import React from 'react';
import { Volume2, Users, Clock, ShieldCheck, Check } from 'lucide-react';
import { useSquad } from '../context/SquadContext';

export function RoomCard({ room, onSelectHold }) {
  const { activeHold } = useSquad();
  const isHeld = activeHold?.roomId === room.id;

  const getStatusBadge = () => {
    if (isHeld) return <span className="badge badge-reserved">Held by You</span>;
    if (room.status === 'available') return <span className="badge badge-available">Available</span>;
    if (room.status === 'reserved') return <span className="badge badge-reserved">Hold Reserved</span>;
    return <span className="badge badge-occupied">Occupied</span>;
  };

  return (
    <div className={`room-card ${room.status}`}>
      <div className="room-card-header">
        <div>
          <h3 className="room-title">{room.name}</h3>
          <p className="room-location">{room.building} • Floor {room.floor}</p>
        </div>
        {getStatusBadge()}
      </div>

      <div className="room-telemetry-grid">
        <div className="telemetry-item">
          <Users size={16} />
          <span>{room.occupiedSeats} / {room.capacity} Chairs</span>
        </div>
        <div className="telemetry-item">
          <Volume2 size={16} />
          <span>{room.noiseLevel} dB (Noise)</span>
        </div>
      </div>

      <div className="room-amenities">
        {room.amenities.map(a => (
          <span key={a} className="amenity-chip"><Check size={12} /> {a}</span>
        ))}
      </div>

      <div className="room-card-actions">
        {room.status === 'available' && !activeHold && (
          <button className="btn-primary full-width" onClick={() => onSelectHold(room)}>
            <Clock size={16} /> Place 20-Min Hold
          </button>
        )}
        {isHeld && (
          <button className="btn-secondary full-width disabled" disabled>
            Active Hold in Progress
          </button>
        )}
        {room.status === 'occupied' && (
          <button className="btn-secondary full-width disabled" disabled>
            Room Fully Occupied
          </button>
        )}
      </div>
    </div>
  );
}
