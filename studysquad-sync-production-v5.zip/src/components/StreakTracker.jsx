import React from 'react';
import { Flame, Award, ShieldCheck } from 'lucide-react';

export function StreakTracker() {
  return (
    <div className="streak-card glass-panel">
      <div className="streak-header">
        <Flame size={28} color="#F59E0B" />
        <div>
          <h3>Peer Study Streak</h3>
          <p>4 Consecutive Days Active</p>
        </div>
      </div>
      <div className="streak-badges">
        <span className="badge-chip">🔥 4-Day Streak</span>
        <span className="badge-chip">⚡ 12 Hours Group Sprint</span>
        <span className="badge-chip">🏆 Library Champion</span>
      </div>
    </div>
  );
}
