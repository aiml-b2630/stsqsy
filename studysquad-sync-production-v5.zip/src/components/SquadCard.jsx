import React from 'react';
import { Users, Clock, BookOpen, MapPin, Sparkles } from 'lucide-react';

export function SquadCard({ squad, onJoin, onSelectWorkspace }) {
  return (
    <div className="squad-card">
      <div className="squad-card-header">
        <div>
          <span className="subject-tag">{squad.subject}</span>
          <h3 className="squad-title">{squad.title}</h3>
        </div>
        {squad.matchScore && (
          <div className="match-badge">
            <Sparkles size={12} /> {squad.matchScore}% Match
          </div>
        )}
      </div>

      <p className="squad-topic">Topic: {squad.topic}</p>

      <div className="squad-meta-grid">
        <div><Clock size={14} /> {squad.meetingTime} ({squad.scheduleBlock})</div>
        <div><MapPin size={14} /> {squad.location}</div>
        <div><Users size={14} /> {squad.currentMembers} / {squad.maxSize} Members</div>
      </div>

      <div className="squad-actions">
        <button className="btn-secondary flex-1" onClick={() => onSelectWorkspace(squad)}>
          View Workspace
        </button>
        <button className="btn-primary flex-1" onClick={() => onJoin(squad.id)} disabled={squad.currentMembers >= squad.maxSize}>
          {squad.currentMembers >= squad.maxSize ? 'Full' : 'Join Squad'}
        </button>
      </div>
    </div>
  );
}
