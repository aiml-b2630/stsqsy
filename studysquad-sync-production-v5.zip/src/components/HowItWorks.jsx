import React from 'react';
import { MapPin, Clock, Users, ShieldCheck } from 'lucide-react';

export function HowItWorks() {
  return (
    <div className="view-container">
      <div className="how-it-works-hero glass-panel">
        <h2>How StudySquad Sync Works</h2>
        <p>Eliminate wasted time hunting for campus study spaces and compatible study partners.</p>
        <div className="steps-grid">
          <div className="step-card">
            <MapPin size={32} color="#3B82F6" />
            <h3>1. Check RoomRadar</h3>
            <p>Live PIR motion and noise sensor telemetry maps 12 campus library pods & quiet halls.</p>
          </div>
          <div className="step-card">
            <Clock size={32} color="#10B981" />
            <h3>2. Place a 20-Min Hold</h3>
            <p>Reserve a desk while walking across campus. Auto-releases ghost bookings if unconfirmed.</p>
          </div>
          <div className="step-card">
            <Users size={32} color="#8B5CF6" />
            <h3>3. Match & Focus</h3>
            <p>Find peer squads by study schedule & subject topic using weighted vector heuristics.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
