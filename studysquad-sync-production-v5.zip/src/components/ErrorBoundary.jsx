import React from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("ErrorBoundary caught an exception:", error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="error-fallback-card">
          <AlertCircle size={48} color="#EF4444" />
          <h2>Something went wrong</h2>
          <p>{this.state.error?.message || "State corruption or component failure occurred."}</p>
          <button className="btn-primary" onClick={this.handleReset}>
            <RefreshCw size={16} /> Reset Application State
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
