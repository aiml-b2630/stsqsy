import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import { rankSquadMatches } from '../utils/matchingEngine';
import { SquadCard } from './SquadCard';
import { CreateSquadModal } from './CreateSquadModal';
import { Users, Plus, Sparkles } from 'lucide-react';

export function SquadMatcher({ onSelectWorkspace }) {
  const { squads, joinSquad } = useSquad();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [userPrefs, setUserPrefs] = useState({
    subject: 'Computer Science',
    topic: 'Memory',
    scheduleBlock: 'Afternoon'
  });

  const rankedSquads = rankSquadMatches(userPrefs, squads);

  return (
    <div className="view-container">
      <div className="view-header">
        <div>
          <h2><Users size={24} /> Academic Study Squad Matcher</h2>
          <p>Multi-dimensional vector heuristic schedule & subject compatibility engine</p>
        </div>
        <button className="btn-primary" onClick={() => setShowCreateModal(true)}>
          <Plus size={16} /> Create Squad
        </button>
      </div>

      <div className="prefs-bar glass-panel">
        <div className="pref-item">
          <label>Filter Subject</label>
          <select value={userPrefs.subject} onChange={e => setUserPrefs({ ...userPrefs, subject: e.target.value })}>
            <option value="Computer Science">Computer Science</option>
            <option value="Mathematics">Mathematics</option>
            <option value="Engineering">Engineering</option>
            <option value="Physics">Physics</option>
          </select>
        </div>
        <div className="pref-item">
          <label>Target Schedule Block</label>
          <select value={userPrefs.scheduleBlock} onChange={e => setUserPrefs({ ...userPrefs, scheduleBlock: e.target.value })}>
            <option value="Morning">Morning</option>
            <option value="Afternoon">Afternoon</option>
            <option value="Evening">Evening</option>
            <option value="Late Night">Late Night</option>
          </select>
        </div>
      </div>

      <div className="squad-grid">
        {rankedSquads.map(sq => (
          <SquadCard key={sq.id} squad={sq} onJoin={joinSquad} onSelectWorkspace={onSelectWorkspace} />
        ))}
      </div>

      {showCreateModal && <CreateSquadModal onClose={() => setShowCreateModal(false)} />}
    </div>
  );
}
