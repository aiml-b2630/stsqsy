import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import { validatePayload, SquadCreationSchema } from '../utils/validationSchemas';
import { Users, PlusCircle } from 'lucide-react';

export function CreateSquadModal({ onClose }) {
  const { createSquad } = useSquad();
  const [formData, setFormData] = useState({
    title: '',
    subject: 'Computer Science',
    topic: '',
    scheduleBlock: 'Afternoon',
    maxSize: 4,
    meetingTime: '4:00 PM',
    location: 'Central Library Pod 3A'
  });
  const [formErrors, setFormErrors] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();
    const validation = validatePayload(formData, SquadCreationSchema);
    if (!validation.isValid) {
      setFormErrors(validation.errors);
      return;
    }
    createSquad(formData);
    onClose();
  };

  return (
    <div className="modal-backdrop">
      <div className="modal-content glass-panel">
        <div className="modal-header">
          <h2><PlusCircle size={22} /> Create Study Squad</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>

        <form onSubmit={handleSubmit} className="modal-body">
          <div className="form-group">
            <label>Squad Title</label>
            <input type="text" value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} placeholder="e.g. Operating Systems Finals Group" />
            {formErrors.title && <span className="field-error">{formErrors.title}</span>}
          </div>

          <div className="form-grid-2">
            <div className="form-group">
              <label>Subject</label>
              <select value={formData.subject} onChange={e => setFormData({ ...formData, subject: e.target.value })}>
                <option value="Computer Science">Computer Science</option>
                <option value="Mathematics">Mathematics</option>
                <option value="Engineering">Engineering</option>
                <option value="Physics">Physics</option>
                <option value="Business">Business</option>
              </select>
            </div>
            <div className="form-group">
              <label>Schedule Time Block</label>
              <select value={formData.scheduleBlock} onChange={e => setFormData({ ...formData, scheduleBlock: e.target.value })}>
                <option value="Morning">Morning (8AM - 12PM)</option>
                <option value="Afternoon">Afternoon (12PM - 5PM)</option>
                <option value="Evening">Evening (5PM - 9PM)</option>
                <option value="Late Night">Late Night (9PM - 1AM)</option>
              </select>
            </div>
          </div>

          <div className="form-group">
            <label>Focus Topic</label>
            <input type="text" value={formData.topic} onChange={e => setFormData({ ...formData, topic: e.target.value })} placeholder="e.g. Virtual Memory & Dynamic Indexing" />
            {formErrors.topic && <span className="field-error">{formErrors.topic}</span>}
          </div>

          <button type="submit" className="btn-primary full-width margin-top">Launch Squad</button>
        </form>
      </div>
    </div>
  );
}
