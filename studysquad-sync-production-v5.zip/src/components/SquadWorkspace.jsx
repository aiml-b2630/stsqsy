import React from 'react';
import { useSquad } from '../context/SquadContext';
import { PomodoroTimer } from './PomodoroTimer';
import { StreakTracker } from './StreakTracker';
import { Users, CheckSquare, MapPin } from 'lucide-react';

export function SquadWorkspace() {
  const { activeSquad } = useSquad();
  if (!activeSquad) return <div className="view-container">Select a squad to view workspace.</div>;

  return (
    <div className="view-container">
      <div className="view-header">
        <div>
          <h2>{activeSquad.title}</h2>
          <p>Location: {activeSquad.location} • Subject: {activeSquad.subject}</p>
        </div>
      </div>

      <div className="workspace-grid">
        <div className="main-workspace-col">
          <PomodoroTimer />
          <div className="goals-card glass-panel">
            <h3><CheckSquare size={18} /> Session Goals & Checklist</h3>
            <ul className="goals-list">
              <li><input type="checkbox" defaultChecked /> Review Virtual Memory Paging concepts</li>
              <li><input type="checkbox" defaultChecked /> Solve Problem Set #3 questions</li>
              <li><input type="checkbox" /> Simulate Concurrency Deadlock scenarios</li>
            </ul>
          </div>
        </div>

        <div className="side-workspace-col">
          <StreakTracker />
          <div className="roster-card glass-panel">
            <h3><Users size={18} /> Squad Member Roster ({activeSquad.members?.length || 1})</h3>
            <ul className="roster-list">
              {(activeSquad.members || ['Alex Rivera']).map((m, idx) => (
                <li key={idx}><span className="avatar-dot"></span> {m}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
