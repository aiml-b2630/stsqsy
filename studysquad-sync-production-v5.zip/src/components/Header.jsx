import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useSquad } from '../context/SquadContext';
import { ShieldCheck, Moon, Sun, Users, MapPin, Sparkles } from 'lucide-react';

export function Header({ activeTab, setActiveTab, darkMode, setDarkMode }) {
  const { user, isAuthenticated, login, logout } = useAuth();
  const { activeHold } = useSquad();

  return (
    <header className="header-glass">
      <div className="header-container">
        <div className="brand-logo" onClick={() => setActiveTab('rooms')}>
          <div className="logo-icon"><Sparkles size={22} /></div>
          <div>
            <h1 className="brand-title">StudySquad <span className="highlight">Sync</span></h1>
            <p className="brand-subtitle">Smart Campus RoomRadar & Squad Matcher</p>
          </div>
        </div>

        <nav className="nav-tabs">
          <button className={`nav-btn ${activeTab === 'rooms' ? 'active' : ''}`} onClick={() => setActiveTab('rooms')}>
            <MapPin size={16} /> RoomRadar
          </button>
          <button className={`nav-btn ${activeTab === 'squads' ? 'active' : ''}`} onClick={() => setActiveTab('squads')}>
            <Users size={16} /> Squad Matcher
          </button>
          <button className={`nav-btn ${activeTab === 'workspace' ? 'active' : ''}`} onClick={() => setActiveTab('workspace')}>
            Workspace
          </button>
          <button className={`nav-btn ${activeTab === 'how' ? 'active' : ''}`} onClick={() => setActiveTab('how')}>
            How it Works
          </button>
        </nav>

        <div className="header-actions">
          {activeHold && (
            <div className="active-hold-badge" onClick={() => setActiveTab('rooms')}>
              <span className="pulse-dot"></span> 20m Hold Active
            </div>
          )}

          <button className="theme-toggle" onClick={() => setDarkMode(!darkMode)}>
            {darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          {isAuthenticated ? (
            <div className="user-profile">
              <ShieldCheck size={16} className="role-icon" />
              <span>{user?.name} ({user?.role})</span>
              <button className="btn-logout" onClick={logout}>Exit</button>
            </div>
          ) : (
            <button className="btn-login" onClick={() => login({ id: 'user_alex', name: 'Alex Rivera', role: 'Student' }, 'mock_jwt')}>
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
