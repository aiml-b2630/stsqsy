import { describe, it, expect } from 'vitest';
import { sanitizeString, validatePayload, SquadCreationSchema } from '../utils/validationSchemas.js';
import { rankSquadMatches, computeJaccardSimilarity } from '../utils/matchingEngine.js';

describe('V5 Validation & Matching Heuristics Test Suite', () => {
  it('Sanitizes malicious script tags (XSS protection)', () => {
    const input = '<script>alert("XSS")</script>';
    const sanitized = sanitizeString(input);
    expect(sanitized).not.toContain('<script>');
    expect(sanitized).toContain('&lt;script&gt;');
  });

  it('Validates squad creation schema correctly', () => {
    const invalidPayload = { title: 'AB', subject: 'Unknown', topic: '' };
    const res = validatePayload(invalidPayload, SquadCreationSchema);
    expect(res.isValid).toBe(false);
    expect(res.errors.title).toBeDefined();
  });

  it('Computes correct Jaccard similarity vector for subject match', () => {
    const sim = computeJaccardSimilarity('Computer Science Finals', 'Computer Science Data Structures');
    expect(sim).toBeGreaterThan(0.3);
  });

  it('Ranks squads by weighted schedule & subject compatibility score', () => {
    const prefs = { subject: 'Computer Science', scheduleBlock: 'Afternoon' };
    const squads = [
      { id: '1', subject: 'Mathematics', topic: 'Algebra', scheduleBlock: 'Morning' },
      { id: '2', subject: 'Computer Science', topic: 'Virtual Memory', scheduleBlock: 'Afternoon' }
    ];
    const ranked = rankSquadMatches(prefs, squads);
    expect(ranked[0].id).toBe('2');
    expect(ranked[0].matchScore).toBeGreaterThan(ranked[1].matchScore);
  });
});
