import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { SquadProvider, useSquad } from './context/SquadContext';
import { Header } from './components/Header';
import { Toast } from './components/Toast';
import { ErrorBoundary } from './components/ErrorBoundary';
import { RoomVisualizer } from './components/RoomVisualizer';
import { SquadMatcher } from './components/SquadMatcher';
import { SquadWorkspace } from './components/SquadWorkspace';
import { HowItWorks } from './components/HowItWorks';
import './custom.css';

function MainApp() {
  const [activeTab, setActiveTab] = useState('rooms');
  const [darkMode, setDarkMode] = useState(true);
  const { toast } = useSquad();

  return (
    <div className={`app-shell ${darkMode ? 'dark-theme' : 'light-theme'}`}>
      <Header activeTab={activeTab} setActiveTab={setActiveTab} darkMode={darkMode} setDarkMode={setDarkMode} />
      <Toast toast={toast} />

      <main className="main-content">
        <ErrorBoundary>
          {activeTab === 'rooms' && <RoomVisualizer />}
          {activeTab === 'squads' && <SquadMatcher onSelectWorkspace={() => setActiveTab('workspace')} />}
          {activeTab === 'workspace' && <SquadWorkspace />}
          {activeTab === 'how' && <HowItWorks />}
        </ErrorBoundary>
      </main>

      <footer className="footer-bar">
        <p>StudySquad Sync v5.0.0 — Production Release Candidate • University Hackathon</p>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <SquadProvider>
        <MainApp />
      </SquadProvider>
    </AuthProvider>
  );
}
