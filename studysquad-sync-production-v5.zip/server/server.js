import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { logger } from './logger.js';
import roomRoutes from './routes/rooms.js';
import squadRoutes from './routes/squads.js';
import authRoutes from './routes/auth.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());

// Request logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    logger.info(`HTTP ${req.method} ${req.url}`, {
      status: res.statusCode,
      durationMs: Date.now() - start,
      ip: req.ip
    });
  });
  next();
});

// API Routes
app.use('/api/rooms', roomRoutes);
app.use('/api/squads', squadRoutes);
app.use('/api/auth', authRoutes);

// Global Error Handler
app.use((err, req, res, next) => {
  logger.error("Unhandled Exception caught by Express", { error: err.message, stack: err.stack });
  res.status(500).json({ error: "Internal Server Error", message: err.message });
});

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    logger.info(`StudySquad Sync Express Server running on port ${PORT}`);
  });
}

export default app;
