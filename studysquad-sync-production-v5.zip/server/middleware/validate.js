import { logger } from '../logger.js';

export function validateSchema(schema) {
  return (req, res, next) => {
    const errors = [];
    for (const field in schema) {
      const rules = schema[field];
      const val = req.body[field];

      if (rules.required && (val === undefined || val === null || val === '')) {
        errors.push(`Field '${field}' is required.`);
        continue;
      }
      if (val !== undefined && val !== null) {
        if (rules.type === 'string' && typeof val !== 'string') {
          errors.push(`Field '${field}' must be a string.`);
        }
        if (rules.type === 'number' && typeof val !== 'number') {
          errors.push(`Field '${field}' must be a number.`);
        }
        if (rules.minLength && typeof val === 'string' && val.length < rules.minLength) {
          errors.push(`Field '${field}' must be at least ${rules.minLength} characters.`);
        }
        if (rules.enum && !rules.enum.includes(val)) {
          errors.push(`Field '${field}' must be one of: ${rules.enum.join(', ')}.`);
        }
      }
    }

    if (errors.length > 0) {
      logger.warn("Validation failed for request", { path: req.path, errors });
      return res.status(400).json({ error: "Validation Error", details: errors });
    }

    next();
  };
}
