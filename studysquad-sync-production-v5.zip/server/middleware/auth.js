import jwt from 'jsonwebtoken';
import { logger } from '../logger.js';

const JWT_SECRET = process.env.JWT_SECRET || 'super_secret_studysquad_jwt_key_2026_v5';

export function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    logger.warn("Unauthorized access attempt missing bearer token", { ip: req.ip, path: req.path });
    return res.status(401).json({ error: "Authentication token required" });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    logger.warn("Invalid or expired JWT token", { error: err.message });
    return res.status(403).json({ error: "Invalid or expired token" });
  }
}
