import express from 'express';
import db from '../db.js';
import { requireAuth } from '../middleware/auth.js';
import { validateSchema } from '../middleware/validate.js';
import { logger } from '../logger.js';

const router = express.Router();

router.get('/', (req, res) => {
  db.all("SELECT * FROM squads ORDER BY createdAt DESC", [], (err, rows) => {
    if (err) {
      logger.error("Error fetching squads", { error: err.message });
      return res.status(500).json({ error: "Database error" });
    }
    res.json(rows);
  });
});

const createSquadSchema = {
  title: { type: 'string', required: true, minLength: 3 },
  subject: { type: 'string', required: true },
  topic: { type: 'string', required: true },
  scheduleBlock: { type: 'string', required: true, enum: ['Morning', 'Afternoon', 'Evening', 'Late Night'] },
  maxSize: { type: 'number', required: true }
};

router.post('/', requireAuth, validateSchema(createSquadSchema), (req, res) => {
  const { title, subject, topic, meetingTime, scheduleBlock, maxSize, location } = req.body;
  const id = 'squad_' + Date.now();
  const creatorId = req.user.id || 'student_1';
  const createdAt = Date.now();

  db.run(
    `INSERT INTO squads (id, title, subject, topic, meetingTime, scheduleBlock, maxSize, currentMembers, location, creatorId, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)`,
    [id, title, subject, topic, meetingTime || '4:00 PM', scheduleBlock, maxSize, location || 'Library Pod #3', creatorId, createdAt],
    function(err) {
      if (err) {
        logger.error("Error creating squad", { error: err.message });
        return res.status(500).json({ error: "Failed to create squad" });
      }

      // Add creator as first member
      db.run(
        `INSERT INTO squad_members (id, squad_id, user_id, user_name, role, joined_at)
         VALUES (?, ?, ?, ?, 'creator', ?)`,
        ['mem_' + Date.now(), id, creatorId, req.user.name || 'Group Creator', createdAt]
      );

      logger.info("Squad created successfully", { squadId: id, title, subject });
      res.status(201).json({ id, title, subject, topic, scheduleBlock, maxSize, currentMembers: 1 });
    }
  );
});

export default router;
