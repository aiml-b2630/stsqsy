import express from 'express';
import jwt from 'jsonwebtoken';
import { validateSchema } from '../middleware/validate.js';
import { logger } from '../logger.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'super_secret_studysquad_jwt_key_2026_v5';

const loginSchema = {
  username: { type: 'string', required: true, minLength: 3 },
  password: { type: 'string', required: true, minLength: 4 }
};

router.post('/login', validateSchema(loginSchema), (req, res) => {
  const { username } = req.body;
  const user = {
    id: 'user_' + username.toLowerCase().replace(/[^a-z0-9]/g, ''),
    name: username,
    role: username.toLowerCase().includes('admin') ? 'Admin' : 'Student',
    major: 'Computer Science'
  };

  const token = jwt.sign(user, JWT_SECRET, { expiresIn: '24h' });
  logger.info("User authenticated successfully", { username, role: user.role });
  res.json({ token, user });
});

export default router;
