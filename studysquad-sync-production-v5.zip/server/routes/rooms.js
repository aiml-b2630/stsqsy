import express from 'express';
import db from '../db.js';
import { requireAuth } from '../middleware/auth.js';
import { validateSchema } from '../middleware/validate.js';
import { logger } from '../logger.js';

const router = express.Router();

// GET /api/rooms - Get all rooms with optional indexed status filter
router.get('/', (req, res) => {
  const { status, building } = req.query;
  let query = "SELECT * FROM rooms";
  const params = [];

  if (status && building) {
    query += " WHERE status = ? AND building = ?";
    params.push(status, building);
  } else if (status) {
    query += " WHERE status = ?";
    params.push(status);
  } else if (building) {
    query += " WHERE building = ?";
    params.push(building);
  }

  db.all(query, params, (err, rows) => {
    if (err) {
      logger.error("Error fetching rooms", { error: err.message });
      return res.status(500).json({ error: "Database error" });
    }
    const formatted = rows.map(r => ({ ...r, amenities: JSON.parse(r.amenities || '[]') }));
    res.json(formatted);
  });
});

// POST /api/rooms/:id/hold - 20 minute hold with optimistic concurrency control
const holdSchema = {
  studentId: { type: 'string', required: true, minLength: 2 },
  version: { type: 'number', required: true }
};

router.post('/:id/hold', requireAuth, validateSchema(holdSchema), (req, res) => {
  const { id } = req.params;
  const { studentId, version } = req.body;
  const holdExpiresAt = Date.now() + 20 * 60 * 1000;

  db.get("SELECT * FROM rooms WHERE id = ?", [id], (err, room) => {
    if (err || !room) {
      return res.status(404).json({ error: "Room not found" });
    }

    if (room.status !== 'available') {
      return res.status(409).json({ error: "Room is currently occupied or reserved" });
    }

    // Optimistic Concurrency Control Check
    db.run(
      `UPDATE rooms SET status = 'reserved', holdExpiresAt = ?, heldByStudent = ?, version = version + 1
       WHERE id = ? AND version = ?`,
      [holdExpiresAt, studentId, id, version],
      function(err) {
        if (err) {
          logger.error("Hold update database failure", { error: err.message });
          return res.status(500).json({ error: "Failed to reserve room" });
        }
        if (this.changes === 0) {
          logger.warn("Concurrency conflict on room hold", { roomId: id, expectedVersion: version });
          return res.status(409).json({ error: "Concurrency conflict: Room status updated by another student." });
        }
        logger.info("Room hold successfully registered", { roomId: id, studentId, holdExpiresAt });
        res.json({ message: "20-Minute room hold placed successfully", roomId: id, holdExpiresAt });
      }
    );
  });
});

export default router;
