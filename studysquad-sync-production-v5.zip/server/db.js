import sqlite3 from 'sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';
import { logger } from './logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = process.env.DB_PATH || path.join(__dirname, 'studysquad.sqlite');

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    logger.error("Failed to connect to SQLite database", { error: err.message });
  } else {
    logger.info("Connected to SQLite database", { path: dbPath });
  }
});

db.serialize(() => {
  // Create Rooms table
  db.run(`
    CREATE TABLE IF NOT EXISTS rooms (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      building TEXT NOT NULL,
      floor INTEGER NOT NULL,
      capacity INTEGER NOT NULL,
      occupiedSeats INTEGER NOT NULL DEFAULT 0,
      status TEXT CHECK(status IN ('available', 'occupied', 'reserved')) DEFAULT 'available',
      noiseLevel INTEGER NOT NULL DEFAULT 40,
      amenities TEXT NOT NULL,
      holdExpiresAt INTEGER,
      heldByStudent TEXT,
      version INTEGER NOT NULL DEFAULT 1
    );
  `);

  // Create Squads table
  db.run(`
    CREATE TABLE IF NOT EXISTS squads (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      subject TEXT NOT NULL,
      topic TEXT NOT NULL,
      meetingTime TEXT NOT NULL,
      scheduleBlock TEXT NOT NULL,
      maxSize INTEGER NOT NULL,
      currentMembers INTEGER NOT NULL DEFAULT 1,
      location TEXT NOT NULL,
      creatorId TEXT NOT NULL,
      createdAt INTEGER NOT NULL
    );
  `);

  // Create Squad Members table
  db.run(`
    CREATE TABLE IF NOT EXISTS squad_members (
      id TEXT PRIMARY KEY,
      squad_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      user_name TEXT NOT NULL,
      role TEXT DEFAULT 'member',
      joined_at INTEGER NOT NULL,
      FOREIGN KEY (squad_id) REFERENCES squads(id)
    );
  `);

  // CREATE INDEXES for high-performance querying (Attempt #6 requirement)
  db.run(`CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status);`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_rooms_building ON rooms(building);`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_squads_subject ON squads(subject);`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_squad_members_squad_id ON squad_members(squad_id);`);

  logger.info("Database schema and performance indexes verified successfully.");
});

export default db;
