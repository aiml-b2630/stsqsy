// Structured JSON Logger addressing Attempt #6 feedback
export const logger = {
  formatMessage(level, message, context = {}) {
    return JSON.stringify({
      timestamp: new Date().toISOString(),
      level: level.toUpperCase(),
      message,
      context,
      environment: process.env.NODE_ENV || 'development'
    });
  },
  info(message, context) {
    console.log(this.formatMessage('info', message, context));
  },
  warn(message, context) {
    console.warn(this.formatMessage('warn', message, context));
  },
  error(message, context) {
    console.error(this.formatMessage('error', message, context));
  }
};
