import { db } from '../db/database.js';
import { logger } from '../utils/logger.js';

export function startHoldCleanupWorker(intervalMs = 30000) {
  logger.info(`Starting background hold cleanup worker (interval: ${intervalMs}ms)...`);
  setInterval(() => {
    try {
      const expiredIds = db.getExpiredHolds();
      if (expiredIds.length > 0) {
        expiredIds.forEach(id => {
          db.releaseRoom(id);
          logger.info(`[Auto-Release Cleanup] Expired hold on Room ${id} released to public status.`);
        });
      }
    } catch (err) {
      logger.error(`Error in hold cleanup worker: ${err.message}`);
    }
  }, intervalMs);
}
