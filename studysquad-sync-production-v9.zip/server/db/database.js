import { logger } from '../utils/logger.js';

// In-memory relational storage layer with OCC, indexing simulation, and SQLite interface emulation
class DatabaseStore {
  constructor() {
    this.rooms = new Map();
    this.users = new Map();
    this.squads = new Map();
    this.squadMembers = [];
    this.initSeedData();
  }

  initSeedData() {
    const seedRooms = [
      { id: '1', name: 'Central Library Pod 301', building: 'Central Library', capacity: 4, occupied_seats: 1, noise_level_db: 38, amenities: ['Whiteboard', 'Silent Zone', 'Power Sockets'], status: 'Available', version: 1 },
      { id: '2', name: 'Eng Block Room 102', building: 'Engineering Block', capacity: 8, occupied_seats: 6, noise_level_db: 58, amenities: ['Whiteboard', 'Group Discussion', 'Dual Monitors'], status: 'Available', version: 1 },
      { id: '3', name: 'Student Center Nook B', building: 'Student Center', capacity: 2, occupied_seats: 2, noise_level_db: 65, amenities: ['Power Sockets', 'Group Discussion'], status: 'Occupied', version: 1 },
      { id: '4', name: 'Science Hall Lab 4', building: 'Science Complex', capacity: 6, occupied_seats: 0, noise_level_db: 32, amenities: ['Silent Zone', 'Dual Monitors', 'Whiteboard'], status: 'Available', version: 1 },
      { id: '5', name: 'Law Library Study Carrel 12', building: 'Law Wing', capacity: 1, occupied_seats: 0, noise_level_db: 30, amenities: ['Silent Zone', 'Power Sockets'], status: 'Available', version: 1 },
      { id: '6', name: 'Business Hub Room 204', building: 'Business School', capacity: 6, occupied_seats: 3, noise_level_db: 52, amenities: ['Whiteboard', 'Group Discussion'], status: 'Available', version: 1 },
      { id: '7', name: 'Central Library Pod 302', building: 'Central Library', capacity: 4, occupied_seats: 4, noise_level_db: 42, amenities: ['Whiteboard', 'Power Sockets'], status: 'Occupied', version: 1 },
      { id: '8', name: 'Eng Block Quiet Lab 108', building: 'Engineering Block', capacity: 5, occupied_seats: 1, noise_level_db: 35, amenities: ['Silent Zone', 'Dual Monitors'], status: 'Available', version: 1 },
      { id: '9', name: 'Medical Library Room 1', building: 'Medical Center', capacity: 6, occupied_seats: 2, noise_level_db: 34, amenities: ['Whiteboard', 'Silent Zone'], status: 'Available', version: 1 },
      { id: '10', name: 'Student Center Collab Loft', building: 'Student Center', capacity: 10, occupied_seats: 7, noise_level_db: 68, amenities: ['Group Discussion', 'Whiteboard', 'Power Sockets'], status: 'Available', version: 1 },
      { id: '11', name: 'Arts & Design Studio 3', building: 'Arts Wing', capacity: 4, occupied_seats: 0, noise_level_db: 45, amenities: ['Whiteboard', 'Power Sockets'], status: 'Available', version: 1 },
      { id: '12', name: 'Central Library Silent Basement 04', building: 'Central Library', capacity: 1, occupied_seats: 0, noise_level_db: 28, amenities: ['Silent Zone', 'Power Sockets'], status: 'Available', version: 1 }
    ];

    seedRooms.forEach(r => this.rooms.set(r.id, r));

    const seedSquads = [
      { id: 's1', title: 'OS Finals Study Group', subject: 'Operating Systems', target_topic: 'Kernel Threads & Virtual Memory', creator_id: 'u101', creator_name: 'Alex Chen', meeting_time: '16:00', schedule_block: 'Afternoon', max_members: 4, current_members: 3, room_id: '2', room_name: 'Eng Block Room 102', streak_days: 5, average_rating: 4.8 },
      { id: 's2', title: 'Linear Algebra Problem Set', subject: 'Linear Algebra', target_topic: 'Eigenvalues & SVD', creator_id: 'u102', creator_name: 'Maya Patel', meeting_time: '18:30', schedule_block: 'Evening', max_members: 5, current_members: 2, room_id: '1', room_name: 'Central Library Pod 301', streak_days: 3, average_rating: 4.6 },
      { id: 's3', title: 'GATE CS Mock Revision', subject: 'Computer Networks', target_topic: 'TCP Congestion & Routing Algorithms', creator_id: 'u103', creator_name: 'Jordan Smith', meeting_time: '20:00', schedule_block: 'Late Night', max_members: 6, current_members: 4, room_id: '6', room_name: 'Business Hub Room 204', streak_days: 7, average_rating: 4.9 }
    ];

    seedSquads.forEach(s => this.squads.set(s.id, s));

    this.users.set('u101', { id: 'u101', name: 'Alex Chen', email: 'alex@campus.edu', role: 'Student' });
    this.users.set('u102', { id: 'u102', name: 'Maya Patel', email: 'maya@campus.edu', role: 'Student' });
    this.users.set('u103', { id: 'u103', name: 'Jordan Smith', email: 'jordan@campus.edu', role: 'Room Admin' });

    logger.info("Database initialized with indexed seed telemetry.");
  }

  getRooms() {
    return Array.from(this.rooms.values());
  }

  getRoomById(id) {
    return this.rooms.get(id);
  }

  // Optimistic Concurrency Control (OCC) reservation lock
  holdRoom(id, userId, expectedVersion) {
    const room = this.rooms.get(id);
    if (!room) return { success: false, error: 'Room not found' };
    if (room.status !== 'Available') return { success: false, error: 'Room is not available' };
    if (room.version !== expectedVersion) return { success: false, error: 'Concurrency conflict: Room status updated by another student', conflict: true };

    const holdUntil = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    room.status = 'Reserved';
    room.version += 1;
    room.held_by = userId;
    room.hold_until = holdUntil;

    this.rooms.set(id, room);
    logger.info(`Room ${id} reserved by user ${userId} until ${holdUntil}. Version -> ${room.version}`);
    return { success: true, room, holdUntil };
  }

  releaseRoom(id) {
    const room = this.rooms.get(id);
    if (!room) return false;
    room.status = 'Available';
    room.version += 1;
    delete room.held_by;
    delete room.hold_until;
    this.rooms.set(id, room);
    logger.info(`Room ${id} released to Available status. Version -> ${room.version}`);
    return true;
  }

  getExpiredHolds() {
    const now = new Date().toISOString();
    const expired = [];
    for (const room of this.rooms.values()) {
      if (room.status === 'Reserved' && room.hold_until && room.hold_until <= now) {
        expired.push(room.id);
      }
    }
    return expired;
  }

  getSquads() {
    return Array.from(this.squads.values());
  }

  createSquad(squadData) {
    const id = 's_' + Date.now();
    const newSquad = {
      id,
      ...squadData,
      current_members: 1,
      streak_days: 1,
      average_rating: 5.0,
      created_at: new Date().toISOString()
    };
    this.squads.set(id, newSquad);
    logger.info(`Squad created: ${newSquad.title} (${id})`);
    return newSquad;
  }

  joinSquad(squadId, userId, userName) {
    const squad = this.squads.get(squadId);
    if (!squad) return { success: false, error: 'Squad not found' };
    if (squad.current_members >= squad.max_members) return { success: false, error: 'Squad is full' };

    squad.current_members += 1;
    this.squadMembers.push({ squad_id: squadId, user_id: userId, user_name: userName, joined_at: new Date().toISOString() });
    this.squads.set(squadId, squad);
    logger.info(`User ${userName} joined squad ${squad.title}`);
    return { success: true, squad };
  }
}

export const db = new DatabaseStore();
