import jwt from 'jsonwebtoken';
import { logger } from '../utils/logger.js';

export const authController = {
  login: (req, res) => {
    const { email, password } = req.body;
    const jwtSecret = process.env.JWT_SECRET || 'production_jwt_secret_key_studysquad_2026_v9_secure';

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required.' });
    }

    const user = {
      id: 'u_' + Math.floor(Math.random() * 1000),
      name: email.split('@')[0].replace('.', ' '),
      email: email,
      role: email.includes('admin') ? 'Room Admin' : 'Student'
    };

    const token = jwt.sign(user, jwtSecret, { expiresIn: '8h' });
    logger.info(`User logged in: ${user.email} (${user.role})`);

    return res.json({ success: true, token, user });
  },

  getProfile: (req, res) => {
    return res.json({ success: true, user: req.user });
  }
};
