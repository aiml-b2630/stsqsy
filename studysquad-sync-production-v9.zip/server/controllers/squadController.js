import { db } from '../db/database.js';
import { logger } from '../utils/logger.js';

export const squadController = {
  getSquads: (req, res) => {
    try {
      const squads = db.getSquads();
      return res.json({ success: true, count: squads.length, data: squads });
    } catch (err) {
      logger.error(`Failed to fetch squads: ${err.message}`);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
  },

  createSquad: (req, res) => {
    try {
      const { title, subject, targetTopic, meetingTime, scheduleBlock, maxMembers, roomId } = req.body;
      const creatorId = req.user ? req.user.id : 'u101';
      const creatorName = req.user ? req.user.name : 'Student Creator';

      const room = db.getRoomById(roomId);
      const roomName = room ? room.name : 'Campus Library';

      const newSquad = db.createSquad({
        title,
        subject,
        target_topic: targetTopic,
        creator_id: creatorId,
        creator_name: creatorName,
        meeting_time: meetingTime,
        schedule_block: scheduleBlock || 'Afternoon',
        max_members: parseInt(maxMembers, 10) || 4,
        room_id: roomId,
        room_name: roomName
      });

      return res.status(201).json({ success: true, squad: newSquad });
    } catch (err) {
      logger.error(`Error creating squad: ${err.message}`);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
  },

  joinSquad: (req, res) => {
    try {
      const { id } = req.params;
      const userId = req.user ? req.user.id : 'u_' + Date.now();
      const userName = req.user ? req.user.name : 'Peer Student';

      const result = db.joinSquad(id, userId, userName);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      return res.json({ success: true, squad: result.squad });
    } catch (err) {
      logger.error(`Error joining squad: ${err.message}`);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
  }
};
