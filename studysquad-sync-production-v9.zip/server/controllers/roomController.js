import { db } from '../db/database.js';
import { logger } from '../utils/logger.js';

export const roomController = {
  getRooms: (req, res) => {
    try {
      const rooms = db.getRooms();
      return res.json({ success: true, count: rooms.length, data: rooms });
    } catch (err) {
      logger.error(`Failed to fetch rooms: ${err.message}`);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
  },

  holdRoom: (req, res) => {
    try {
      const { roomId, expectedVersion } = req.body;
      const userId = req.user ? req.user.id : 'anonymous_student';

      const result = db.holdRoom(roomId, userId, parseInt(expectedVersion, 10));
      if (!result.success) {
        if (result.conflict) {
          return res.status(409).json({ error: result.error, conflict: true });
        }
        return res.status(400).json({ error: result.error });
      }

      return res.json({
        success: true,
        message: 'Room held successfully for 20 minutes',
        room: result.room,
        holdUntil: result.holdUntil
      });
    } catch (err) {
      logger.error(`Error processing room hold: ${err.message}`);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
  },

  releaseRoom: (req, res) => {
    try {
      const { id } = req.params;
      const released = db.releaseRoom(id);
      if (!released) {
        return res.status(404).json({ error: 'Room not found' });
      }
      return res.json({ success: true, message: 'Room released to Available status' });
    } catch (err) {
      logger.error(`Error releasing room: ${err.message}`);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
  }
};
