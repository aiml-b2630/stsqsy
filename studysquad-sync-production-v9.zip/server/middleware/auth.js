import jwt from 'jsonwebtoken';
import { logger } from '../utils/logger.js';

export function authMiddleware(req, res, next) {
  const jwtSecret = process.env.JWT_SECRET;
  if (!jwtSecret) {
    logger.error("FATAL: JWT_SECRET environment variable is missing.");
    return res.status(500).json({ error: 'Server Security Misconfiguration: JWT_SECRET required.' });
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing or invalid token header.' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, jwtSecret);
    req.user = decoded;
    next();
  } catch (err) {
    logger.warn(`JWT verification failed: ${err.message}`);
    return res.status(401).json({ error: 'Unauthorized: Invalid or expired token.' });
  }
}
