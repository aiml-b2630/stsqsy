export function validateRequestBody(requiredFields) {
  return (req, res, next) => {
    if (!req.body || typeof req.body !== 'object') {
      return res.status(400).json({ error: 'Bad Request: Missing request payload.' });
    }
    const missing = requiredFields.filter(field => req.body[field] === undefined || req.body[field] === null || req.body[field] === '');
    if (missing.length > 0) {
      return res.status(400).json({ error: `Bad Request: Missing required field(s): ${missing.join(', ')}` });
    }
    next();
  };
}
