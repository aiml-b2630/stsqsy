import { logger } from '../utils/logger.js';

export function setupOccupancyStream(req, res) {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  logger.info("SSE client connected to occupancy stream.");

  const interval = setInterval(() => {
    const telemetryEvent = {
      timestamp: new Date().toISOString(),
      activeSensors: 12,
      noiseDelta: (Math.random() * 4 - 2).toFixed(1),
      occupancyUpdate: { roomId: String(Math.floor(Math.random() * 12) + 1), noise_level_db: Math.floor(30 + Math.random() * 40) }
    };
    res.write(`data: ${JSON.stringify(telemetryEvent)}\n\n`);
  }, 5000);

  req.on('close', () => {
    clearInterval(interval);
    logger.info("SSE client disconnected from occupancy stream.");
  });
}
