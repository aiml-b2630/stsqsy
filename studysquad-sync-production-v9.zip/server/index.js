import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { logger } from './utils/logger.js';
import { authMiddleware } from './middleware/auth.js';
import { validateRequestBody } from './middleware/validate.js';
import { roomController } from './controllers/roomController.js';
import { squadController } from './controllers/squadController.js';
import { authController } from './controllers/authController.js';
import { startHoldCleanupWorker } from './workers/holdCleanupWorker.js';
import { setupOccupancyStream } from './events/occupancyStream.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(cors());
app.use(express.json());

// Health & Docs
app.get('/api/health', (req, res) => res.json({ status: 'UP', timestamp: new Date().toISOString(), system: 'StudySquad Sync v9.0.0' }));
app.get('/api/docs', (req, res) => {
  const swaggerFile = path.join(__dirname, 'docs', 'swagger.json');
  if (fs.existsSync(swaggerFile)) {
    return res.sendFile(swaggerFile);
  }
  return res.json({ openapi: '3.0.0', info: { title: 'StudySquad Sync API' } });
});

// Real-time Telemetry Stream
app.get('/api/rooms/stream', setupOccupancyStream);

// Auth Routes
app.post('/api/auth/login', validateRequestBody(['email', 'password']), authController.login);
app.get('/api/auth/me', authMiddleware, authController.getProfile);

// Room Radar Endpoints
app.get('/api/rooms', roomController.getRooms);
app.post('/api/rooms/hold', authMiddleware, validateRequestBody(['roomId', 'expectedVersion']), roomController.holdRoom);
app.post('/api/rooms/release/:id', authMiddleware, roomController.releaseRoom);

// Squad Matching Endpoints
app.get('/api/squads', squadController.getSquads);
app.post('/api/squads', authMiddleware, validateRequestBody(['title', 'subject', 'meetingTime', 'roomId']), squadController.createSquad);
app.post('/api/squads/join/:id', authMiddleware, squadController.joinSquad);

// Start Background Cleanup Worker
startHoldCleanupWorker(30000);

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    logger.info(`StudySquad Sync Production Server v9 running on port ${PORT}`);
  });
}

export default app;
