import { describe, it, expect } from 'vitest';
import request from 'supertest';
import express from 'express';
import { roomController } from '../controllers/roomController.js';
import { squadController } from '../controllers/squadController.js';

const app = express();
app.use(express.json());
app.get('/api/rooms', roomController.getRooms);
app.post('/api/rooms/hold', (req, res, next) => { req.user = { id: 'test_user' }; next(); }, roomController.holdRoom);
app.get('/api/squads', squadController.getSquads);

describe('Express REST API Integration Suite', () => {
  it('GET /api/rooms returns 12 study rooms', async () => {
    const res = await request(app).get('/api/rooms');
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.count).toBe(12);
  });

  it('POST /api/rooms/hold reserves room with OCC version matching', async () => {
    const res = await request(app).post('/api/rooms/hold').send({ roomId: '4', expectedVersion: 1 });
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.room.status).toBe('Reserved');
  });

  it('POST /api/rooms/hold rejects concurrency mismatch with 409 conflict', async () => {
    const res = await request(app).post('/api/rooms/hold').send({ roomId: '4', expectedVersion: 1 });
    expect(res.status).toBe(409);
    expect(res.body.conflict).toBe(true);
  });

  it('GET /api/squads returns active squad feed', async () => {
    const res = await request(app).get('/api/squads');
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
  });
});
