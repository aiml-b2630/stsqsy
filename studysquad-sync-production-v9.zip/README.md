# StudySquad Sync: RoomRadar Hack — Production Release (v9.0.0)

## 📌 Problem & Executive Summary
During exam periods, university students waste hours wandering between library wings searching for vacant, quiet study rooms. Concurrently, solo students preparing for competitive exams (GATE, GRE, CAT) struggle to find compatible peer study partners who share their exact subject goals and schedules.

**StudySquad Sync** solves both challenges through an integrated 3-tier smart study platform that maps live library room availability via PIR motion sensors, enables 20-minute reservation holds to eliminate ghost bookings, and pairs students into focused study squads using a multi-factor weighted Jaccard matrix matching algorithm.

---

## 🏗️ 3-Tier Production System Architecture

### 1. Presentation Tier (React 18 + Glassmorphism UI)
- **`RoomVisualizer.jsx` & `RoomCard.jsx`**: Live occupancy grid mapping 12 campus study pods with decibel noise meters (30–75 dB) and amenity filters (*Whiteboard, Silent Zone, Group Discussion, Power Sockets, Dual Monitors*).
- **`HoldTimerModal.jsx` & `useHoldTimer.js`**: Active 20-minute countdown timer with auto-release callbacks for unconfirmed arrival holds.
- **`SquadMatcher.jsx` & `SquadCard.jsx`**: Peer study group matching feed using schedule time blocks (*Morning, Afternoon, Evening, Late Night*) and subject token vectors.
- **`SquadWorkspace.jsx`**: **Synchronized Focus Workspace** featuring member rosters, session goal checklists, agenda items, Pomodoro timer (`PomodoroTimer.jsx`), and streak badges (`StreakTracker.jsx`).
- **`Header.jsx`, `Toast.jsx`, `ErrorBoundary.jsx`, `HowItWorks.jsx`**: Responsive navigation shell, dark/light theme toggle, and error boundaries.

### 2. Application Logic Tier (Node.js + Express REST API)
- **Modular Controllers (`/server/controllers/`)**:
  - `roomController.js`: Room inventory, 20-minute hold reservation with OCC version locking, and manual/auto releases.
  - `squadController.js`: Squad creation, subject matching, and member roster joins.
  - `authController.js`: Cryptographic JWT token issuance.
- **Background Hold Cleanup Worker (`server/workers/holdCleanupWorker.js`)**: Background interval worker scanning SQLite for expired holds (`status = 'Reserved' AND hold_until <= NOW()`) and auto-releasing ghost bookings.
- **Real-Time SSE Telemetry Stream (`server/events/occupancyStream.js`)**: Server-Sent Events stream (`/api/rooms/stream`) broadcasting live PIR motion updates and decibel noise fluctuations.
- **OpenAPI 3.0 / Swagger Specs (`server/docs/swagger.json`)**: Served at `/api/docs`.

### 3. Database Tier (SQLite3 Persistence & OCC Locks)
- **Database Engine (`server/db/database.js`)**: Structured SQLite database tier with foreign key enforcement (`PRAGMA foreign_keys = ON`).
- **SQL Indexes**: Explicit performance indexes on `rooms(status)`, `rooms(building)`, `squads(subject)`, and `squad_members(squad_id)`.
- **Optimistic Concurrency Control (OCC)**: Version locking (`UPDATE rooms SET status='Reserved', version=version+1 WHERE id=? AND version=?`) to prevent simultaneous double-booking race conditions.

---

## 📊 Heuristic Matching Algorithm Formula

The matching engine pairs students using a 5-factor weighted algorithm:

$$\\text{Score} = (0.35 \\times S_{\\text{schedule}}) + (0.30 \\times S_{\\text{subject}}) + (0.15 \\times S_{\\text{amenity}}) + (0.10 \\times S_{\\text{streak}}) + (0.10 \\times S_{\\text{rating}})$$

1. **Schedule Block Overlap (35%)**: Compares discrete availability blocks (*Morning, Afternoon, Evening, Late Night*).
2. **Subject Token Jaccard Similarity (30%)**: Calculates tokenized string intersection over union on exam topics.
3. **Amenity Match (15%)**: Verifies room equipment requirements (*Whiteboard, Dual Monitors*).
4. **Peer Study Streak (10%)**: Rewards active groups with continuous study streaks.
5. **Peer Rating Score (10%)**: Factors historical peer review ratings.

---

## ⚡ Quick Start & Setup Instructions

### Prerequisites
- Node.js (v18.0.0 or higher)
- npm (v9.0.0 or higher)

### Installation
```bash
# 1. Install dependencies
npm install

# 2. Configure environment variables
cp .env.example .env

# 3. Run full-stack application (Server + Vite Client)
npm run dev
```

### Running Automated Test Suites
```bash
# Run Vitest unit & Supertest API integration tests
npm test
```

---

## 🔒 Security & Quality Compliance
- **JWT Cryptographic Authentication**: Enforced token header validation (`Authorization: Bearer <token>`) with strict `process.env.JWT_SECRET` check.
- **XSS & Input Sanitization**: Client & server-side payload sanitization via `sanitizeString` and input bounds validation.
- **Resilience**: React Error Boundaries (`ErrorBoundary.jsx`) handling state corruption and local storage fallbacks.
