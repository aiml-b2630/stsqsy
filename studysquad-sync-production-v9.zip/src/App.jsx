import React, { useState } from 'react';
import { Header } from './components/Header';
import { Toast } from './components/Toast';
import { ErrorBoundary } from './components/ErrorBoundary';
import { HoldTimerModal } from './components/HoldTimerModal';
import { RoomVisualizer } from './components/RoomVisualizer';
import { SquadMatcher } from './components/SquadMatcher';
import { SquadWorkspace } from './components/SquadWorkspace';
import { HowItWorks } from './components/HowItWorks';
import { useSquad } from './context/SquadContext';

export default function App() {
  const [activeTab, setActiveTab] = useState('radar');
  const [theme, setTheme] = useState('dark');
  const [selectedWorkspaceSquad, setSelectedWorkspaceSquad] = useState(null);

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
  };

  const handleOpenWorkspace = (squad) => {
    setSelectedWorkspaceSquad(squad);
    setActiveTab('workspace');
  };

  return (
    <ErrorBoundary>
      <div style={{ minHeight: '100vh', paddingBottom: '3rem' }}>
        <Header activeTab={activeTab} setActiveTab={setActiveTab} theme={theme} toggleTheme={toggleTheme} />
        <HoldTimerModal />

        <main>
          {activeTab === 'radar' && <RoomVisualizer />}
          {activeTab === 'matcher' && <SquadMatcher onOpenWorkspace={handleOpenWorkspace} />}
          {activeTab === 'workspace' && <SquadWorkspace squad={selectedWorkspaceSquad} onBack={() => setActiveTab('matcher')} />}
          {activeTab === 'how' && <HowItWorks />}
        </main>

        <Toast />
      </div>
    </ErrorBoundary>
  );
}
