import { useState, useEffect } from 'react';

export function useHoldTimer(targetHoldTimeISO, onExpired) {
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(0);

  useEffect(() => {
    if (!targetHoldTimeISO) {
      setTimeLeftSeconds(0);
      return;
    }

    const calculateRemaining = () => {
      const diffMs = new Date(targetHoldTimeISO).getTime() - new Date().getTime();
      const seconds = Math.max(0, Math.floor(diffMs / 1000));
      setTimeLeftSeconds(seconds);

      if (seconds === 0 && onExpired) {
        onExpired();
      }
    };

    calculateRemaining();
    const interval = setInterval(calculateRemaining, 1000);
    return () => clearInterval(interval);
  }, [targetHoldTimeISO, onExpired]);

  const minutes = Math.floor(timeLeftSeconds / 60);
  const seconds = timeLeftSeconds % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  return { timeLeftSeconds, formattedTime, isExpired: timeLeftSeconds === 0 && !!targetHoldTimeISO };
}
