import { useEffect } from 'react';

export function useIoTSensorSim(onTelemetryUpdate) {
  useEffect(() => {
    const interval = setInterval(() => {
      const randomRoomId = String(Math.floor(Math.random() * 12) + 1);
      const newNoiseDb = Math.floor(30 + Math.random() * 40);

      if (onTelemetryUpdate) {
        onTelemetryUpdate(randomRoomId, newNoiseDb);
      }
    }, 6000);

    return () => clearInterval(interval);
  }, [onTelemetryUpdate]);
}
