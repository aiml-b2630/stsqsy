import { sanitizeString } from './validation.js';

export function calculateMatchScore(studentPreferences, squad) {
  if (!studentPreferences || !squad) return 0;

  // 1. Schedule Block Overlap (Weight: 35%)
  const prefSchedule = studentPreferences.preferredScheduleBlock || 'Afternoon';
  const scheduleScore = (squad.schedule_block === prefSchedule) ? 1.0 : 0.3;

  // 2. Tokenized Jaccard Similarity for Subjects (Weight: 30%)
  const studentSubjectTokens = new Set((studentPreferences.subject || '').toLowerCase().split(/\s+/).map(sanitizeString));
  const squadSubjectTokens = new Set((squad.subject || '').toLowerCase().split(/\s+/).map(sanitizeString));

  const intersection = new Set([...studentSubjectTokens].filter(x => squadSubjectTokens.has(x) && x.length > 2));
  const union = new Set([...studentSubjectTokens, ...squadSubjectTokens]);
  const jaccardSubjectScore = union.size > 0 ? (intersection.size / union.size) : 0;

  // 3. Amenity & Quiet Level Match (Weight: 15%)
  const desiredAmenity = studentPreferences.desiredAmenity;
  const amenityScore = (desiredAmenity && squad.amenities && squad.amenities.includes(desiredAmenity)) ? 1.0 : 0.5;

  // 4. Peer Study Streak Weight (Weight: 10%)
  const streakScore = Math.min((squad.streak_days || 1) / 7, 1.0);

  // 5. Peer Rating Score (Weight: 10%)
  const ratingScore = ((squad.average_rating || 4.5) - 3.0) / 2.0;

  const totalWeightedScore = (
    (scheduleScore * 0.35) +
    (jaccardSubjectScore * 0.30) +
    (amenityScore * 0.15) +
    (streakScore * 0.10) +
    (ratingScore * 0.10)
  );

  return Math.round(totalWeightedScore * 100);
}

export function findTopSquadMatches(studentPreferences, squadList) {
  if (!Array.isArray(squadList)) return [];
  return squadList
    .map(squad => ({
      ...squad,
      matchScore: calculateMatchScore(studentPreferences, squad)
    }))
    .sort((a, b) => b.matchScore - a.matchScore);
}
