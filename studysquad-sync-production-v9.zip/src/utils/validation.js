export function sanitizeString(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .trim();
}

export function validateSquadInput(input) {
  const errors = {};
  if (!input.title || input.title.trim().length < 3) errors.title = 'Title must be at least 3 characters.';
  if (!input.subject) errors.subject = 'Subject selection is required.';
  if (!input.maxMembers || input.maxMembers < 2 || input.maxMembers > 10) errors.maxMembers = 'Group capacity must be between 2 and 10.';
  return { isValid: Object.keys(errors).length === 0, errors };
}
