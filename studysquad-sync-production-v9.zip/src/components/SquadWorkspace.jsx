import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import { PomodoroTimer } from './PomodoroTimer';
import { StreakTracker } from './StreakTracker';
import { Users, CheckSquare, MapPin, Clock, ArrowLeft } from 'lucide-react';

export function SquadWorkspace({ squad: propsSquad, onBack }) {
  const { activeWorkspaceSquad } = useSquad();
  const squad = propsSquad || activeWorkspaceSquad;

  const [goals, setGoals] = useState([
    { id: 1, text: 'Review Virtual Memory Paging & TLB Hit Ratios', completed: true },
    { id: 2, text: 'Solve 2024 Exam Question 4 on Inverted Page Tables', completed: false },
    { id: 3, text: 'Compare Segmentation vs Paging Trade-offs', completed: false }
  ]);

  const toggleGoal = (id) => {
    setGoals(prev => prev.map(g => g.id === id ? { ...g, completed: !g.completed } : g));
  };

  if (!squad) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem' }}>
        <p>No active squad selected. Choose a squad from the Squad Matcher tab.</p>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 1rem' }}>
      <button
        onClick={onBack}
        style={{ padding: '0.4rem 0.8rem', background: 'transparent', border: '1px solid var(--glass-border)', color: 'var(--text-muted)', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.3rem', marginBottom: '1rem' }}
      >
        <ArrowLeft size={16} /> Back to Matcher
      </button>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div className="glass-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
              <h2 style={{ margin: 0, fontSize: '1.5rem' }}>{squad.title}</h2>
              <span className="badge badge-available">Active Focus Workspace</span>
            </div>
            <div style={{ color: 'var(--accent-primary)', fontWeight: 600, marginBottom: '1rem' }}>
              {squad.subject} • <span style={{ color: 'var(--text-muted)' }}>{squad.target_topic}</span>
            </div>

            <div style={{ display: 'flex', gap: '1.5rem', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <MapPin size={16} color="var(--accent-primary)" /> {squad.room_name}
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <Clock size={16} color="var(--accent-primary)" /> {squad.meeting_time} ({squad.schedule_block})
              </span>
            </div>
          </div>

          <StreakTracker streakDays={squad.streak_days || 5} />

          <div className="glass-card">
            <h3 style={{ margin: '0 0 1rem 0', fontSize: '1.1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <CheckSquare size={18} color="var(--accent-primary)" /> Session Focus Agenda & Goals
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {goals.map(goal => (
                <label key={goal.id} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0.6rem', borderRadius: '8px', background: 'rgba(255,255,255,0.03)', cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={goal.completed}
                    onChange={() => toggleGoal(goal.id)}
                    style={{ accentColor: 'var(--accent-primary)', width: '16px', height: '16px' }}
                  />
                  <span style={{ textDecoration: goal.completed ? 'line-through' : 'none', color: goal.completed ? 'var(--text-muted)' : 'var(--text-main)', fontSize: '0.9rem' }}>
                    {goal.text}
                  </span>
                </label>
              ))}
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <PomodoroTimer />

          <div className="glass-card">
            <h3 style={{ margin: '0 0 1rem 0', fontSize: '1.1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Users size={18} color="var(--accent-primary)" /> Squad Roster ({squad.current_members}/{squad.max_members})
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.5rem', background: 'rgba(255,255,255,0.03)', borderRadius: '6px' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{squad.creator_name}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Squad Creator</div>
                </div>
                <span className="badge badge-available">Online</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.5rem', background: 'rgba(255,255,255,0.03)', borderRadius: '6px' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>Maya Patel</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Peer Member</div>
                </div>
                <span className="badge badge-available">In Room</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
