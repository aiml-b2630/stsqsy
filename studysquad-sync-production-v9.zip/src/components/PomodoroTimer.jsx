import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Bell } from 'lucide-react';

export function PomodoroTimer() {
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState('focus'); // focus or break

  useEffect(() => {
    let interval = null;
    if (isRunning && secondsLeft > 0) {
      interval = setInterval(() => setSecondsLeft(prev => prev - 1), 1000);
    } else if (secondsLeft === 0) {
      if (mode === 'focus') {
        setMode('break');
        setSecondsLeft(5 * 60);
      } else {
        setMode('focus');
        setSecondsLeft(25 * 60);
      }
      setIsRunning(false);
    }
    return () => clearInterval(interval);
  }, [isRunning, secondsLeft, mode]);

  const toggleTimer = () => setIsRunning(!isRunning);
  const resetTimer = () => {
    setIsRunning(false);
    setMode('focus');
    setSecondsLeft(25 * 60);
  };

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  return (
    <div className="glass-card" style={{ textAlign: 'center', padding: '1.25rem' }}>
      <div style={{ fontSize: '0.8rem', textTransform: 'uppercase', tracking: '1px', color: mode === 'focus' ? 'var(--accent-primary)' : '#22c55e', fontWeight: 700, marginBottom: '0.25rem' }}>
        {mode === 'focus' ? '🎯 Synchronized Focus Sprint' : '☕ 5-Minute Break Refresh'}
      </div>
      <div style={{ fontSize: '2.5rem', fontWeight: 800, letterSpacing: '2px', margin: '0.5rem 0' }}>
        {formattedTime}
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', gap: '0.5rem' }}>
        <button
          onClick={toggleTimer}
          style={{ padding: '0.4rem 1rem', background: isRunning ? '#ef4444' : 'var(--accent-primary)', color: '#fff', border: 'none', borderRadius: '6px', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
        >
          {isRunning ? <Pause size={14} /> : <Play size={14} />} {isRunning ? 'Pause' : 'Start Sprint'}
        </button>
        <button
          onClick={resetTimer}
          style={{ padding: '0.4rem 0.75rem', background: 'transparent', border: '1px solid var(--glass-border)', color: 'var(--text-main)', borderRadius: '6px', cursor: 'pointer' }}
        >
          <RotateCcw size={14} />
        </button>
      </div>
    </div>
  );
}
