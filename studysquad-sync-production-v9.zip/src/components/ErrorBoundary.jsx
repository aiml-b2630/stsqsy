import React from 'react';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("UI Exception Intercepted by ErrorBoundary:", error, errorInfo);
  }

  handleReset = () => {
    localStorage.clear();
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '3rem', textAlign: 'center', maxWidth: '600px', margin: '4rem auto' }} className="glass-card">
          <h2>Application State Exception</h2>
          <p style={{ color: 'var(--text-muted)' }}>An unhandled UI error occurred. Resetting browser state will restore normal operation.</p>
          <button
            onClick={this.handleReset}
            style={{ padding: '0.75rem 1.5rem', background: 'var(--accent-primary)', color: '#fff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 600 }}
          >
            Reset Application State
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
