import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import { PlusCircle, X } from 'lucide-react';

export function CreateSquadModal({ isOpen, onClose }) {
  const { rooms, createSquad } = useSquad();
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('Operating Systems');
  const [targetTopic, setTargetTopic] = useState('');
  const [meetingTime, setMeetingTime] = useState('16:00');
  const [scheduleBlock, setScheduleBlock] = useState('Afternoon');
  const [maxMembers, setMaxMembers] = useState(4);
  const [roomId, setRoomId] = useState('1');

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !targetTopic) return;

    createSquad({
      title,
      subject,
      target_topic: targetTopic,
      meeting_time: meetingTime,
      schedule_block: scheduleBlock,
      max_members: parseInt(maxMembers, 10),
      room_id: roomId,
      room_name: rooms.find(r => r.id === roomId)?.name || 'Central Library Pod'
    });

    onClose();
  };

  return (
    <div style={{
      position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
      background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9000
    }}>
      <div className="glass-card" style={{ maxWidth: '500px', width: '90%' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h3 style={{ margin: 0, fontSize: '1.25rem' }}>Create Peer Study Squad</h3>
          <button onClick={onClose} style={{ background: 'transparent', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>Squad Title</label>
            <input
              type="text"
              required
              placeholder="e.g. OS Finals Review Squad"
              value={title}
              onChange={e => setTitle(e.target.value)}
              style={{ width: '100%', padding: '0.5rem', borderRadius: '6px', border: '1px solid var(--glass-border)', background: 'var(--bg-primary)', color: 'var(--text-main)' }}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <div>
              <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>Subject</label>
              <select
                value={subject}
                onChange={e => setSubject(e.target.value)}
                style={{ width: '100%', padding: '0.5rem', borderRadius: '6px', border: '1px solid var(--glass-border)', background: 'var(--bg-primary)', color: 'var(--text-main)' }}
              >
                <option value="Operating Systems">Operating Systems</option>
                <option value="Linear Algebra">Linear Algebra</option>
                <option value="Computer Networks">Computer Networks</option>
                <option value="Data Structures">Data Structures</option>
                <option value="Calculus III">Calculus III</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>Schedule Block</label>
              <select
                value={scheduleBlock}
                onChange={e => setScheduleBlock(e.target.value)}
                style={{ width: '100%', padding: '0.5rem', borderRadius: '6px', border: '1px solid var(--glass-border)', background: 'var(--bg-primary)', color: 'var(--text-main)' }}
              >
                <option value="Morning">Morning (08:00 - 12:00)</option>
                <option value="Afternoon">Afternoon (12:00 - 17:00)</option>
                <option value="Evening">Evening (17:00 - 21:00)</option>
                <option value="Late Night">Late Night (21:00+)</option>
              </select>
            </div>
          </div>

          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>Target Topic Goals</label>
            <input
              type="text"
              required
              placeholder="e.g. Virtual Memory Paging & Page Replacement"
              value={targetTopic}
              onChange={e => setTargetTopic(e.target.value)}
              style={{ width: '100%', padding: '0.5rem', borderRadius: '6px', border: '1px solid var(--glass-border)', background: 'var(--bg-primary)', color: 'var(--text-main)' }}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <div>
              <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>Max Members</label>
              <input
                type="number"
                min="2"
                max="10"
                value={maxMembers}
                onChange={e => setMaxMembers(e.target.value)}
                style={{ width: '100%', padding: '0.5rem', borderRadius: '6px', border: '1px solid var(--glass-border)', background: 'var(--bg-primary)', color: 'var(--text-main)' }}
              />
            </div>
            <div>
              <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>Meeting Location</label>
              <select
                value={roomId}
                onChange={e => setRoomId(e.target.value)}
                style={{ width: '100%', padding: '0.5rem', borderRadius: '6px', border: '1px solid var(--glass-border)', background: 'var(--bg-primary)', color: 'var(--text-main)' }}
              >
                {rooms.map(r => (
                  <option key={r.id} value={r.id}>{r.name}</option>
                ))}
              </select>
            </div>
          </div>

          <button
            type="submit"
            style={{ width: '100%', padding: '0.75rem', background: 'var(--accent-primary)', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 600, cursor: 'pointer', marginTop: '0.5rem' }}
          >
            Launch Study Squad
          </button>
        </form>
      </div>
    </div>
  );
}
