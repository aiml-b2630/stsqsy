import React from 'react';
import { useSquad } from '../context/SquadContext';
import { useHoldTimer } from '../hooks/useHoldTimer';
import { Clock, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

export function HoldTimerModal() {
  const { activeHold, releaseHold, showToast } = useSquad();
  const { formattedTime, isExpired } = useHoldTimer(activeHold?.holdUntil, () => {
    if (activeHold) {
      releaseHold(activeHold.roomId);
      showToast('20-Minute hold expired. Room released to public status.');
    }
  });

  if (!activeHold) return null;

  return (
    <div style={{
      position: 'fixed',
      top: 0, left: 0, right: 0, bottom: 0,
      background: 'rgba(0,0,0,0.7)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9000
    }}>
      <div className="glass-card" style={{ maxWidth: '450px', width: '90%', textAlign: 'center' }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1rem' }}>
          <div style={{ background: 'rgba(245, 158, 11, 0.2)', padding: '1rem', borderRadius: '50%', color: '#f59e0b' }}>
            <Clock size={40} />
          </div>
        </div>

        <h2 style={{ margin: '0 0 0.5rem 0' }}>Active Room Reservation Hold</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', margin: '0 0 1.5rem 0' }}>
          Holding <strong style={{ color: 'var(--text-main)' }}>{activeHold.roomName}</strong> while you walk to campus.
        </p>

        <div style={{ fontSize: '3rem', fontWeight: 800, letterSpacing: '2px', color: 'var(--status-reserved)', marginBottom: '1.5rem' }}>
          {formattedTime}
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button
            onClick={() => {
              showToast('Arrival confirmed! Desk check-in complete.');
            }}
            style={{ flex: 1, padding: '0.75rem', background: '#22c55e', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem' }}
          >
            <CheckCircle size={18} /> Confirm Arrival
          </button>
          <button
            onClick={() => releaseHold(activeHold.roomId)}
            style={{ padding: '0.75rem 1rem', background: 'rgba(239, 68, 68, 0.2)', color: '#ef4444', border: '1px solid #ef4444', borderRadius: '8px', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
          >
            <XCircle size={18} /> Release
          </button>
        </div>
      </div>
    </div>
  );
}
