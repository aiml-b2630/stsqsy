import React from 'react';
import { Users, Volume2, ShieldCheck, Clock } from 'lucide-react';

export function RoomCard({ room, onHold }) {
  const isAvailable = room.status === 'Available';
  const badgeClass = room.status === 'Available' ? 'badge-available' : room.status === 'Reserved' ? 'badge-reserved' : 'badge-occupied';

  return (
    <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', gap: '1rem' }}>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
          <h3 style={{ margin: 0, fontSize: '1.05rem', fontWeight: 600 }}>{room.name}</h3>
          <span className={`badge ${badgeClass}`}>{room.status}</span>
        </div>
        <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.75rem' }}>
          {room.building}
        </div>

        <div style={{ display: 'flex', gap: '1rem', fontSize: '0.85rem', marginBottom: '1rem' }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
            <Users size={15} color="var(--accent-primary)" /> {room.occupied_seats}/{room.capacity} Seats
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
            <Volume2 size={15} color={room.noise_level_db < 40 ? '#22c55e' : '#f59e0b'} /> {room.noise_level_db} dB
          </span>
        </div>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
          {room.amenities.map((amenity, idx) => (
            <span key={idx} style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem', background: 'rgba(255,255,255,0.06)', borderRadius: '4px', color: 'var(--text-muted)' }}>
              {amenity}
            </span>
          ))}
        </div>
      </div>

      <button
        onClick={() => onHold(room.id)}
        disabled={!isAvailable}
        style={{
          width: '100%',
          padding: '0.65rem',
          borderRadius: '8px',
          border: 'none',
          background: isAvailable ? 'var(--accent-primary)' : 'rgba(255,255,255,0.1)',
          color: isAvailable ? '#fff' : 'var(--text-muted)',
          cursor: isAvailable ? 'pointer' : 'not-allowed',
          fontWeight: 600,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.5rem'
        }}
      >
        <Clock size={16} /> {isAvailable ? 'Hold Room (20 Min)' : room.status}
      </button>
    </div>
  );
}
