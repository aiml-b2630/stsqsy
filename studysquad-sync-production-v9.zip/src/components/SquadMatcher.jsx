import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import { SquadCard } from './SquadCard';
import { CreateSquadModal } from './CreateSquadModal';
import { findTopSquadMatches } from '../utils/matchingEngine';
import { PlusCircle, Search, Filter } from 'lucide-react';

export function SquadMatcher({ onOpenWorkspace }) {
  const { squads, joinSquad } = useSquad();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [subjectFilter, setSubjectFilter] = useState('All');
  const [scheduleFilter, setScheduleFilter] = useState('All');

  const studentPreferences = {
    subject: subjectFilter === 'All' ? 'Operating Systems' : subjectFilter,
    preferredScheduleBlock: scheduleFilter === 'All' ? 'Afternoon' : scheduleFilter,
    desiredAmenity: 'Whiteboard'
  };

  const rankedSquads = findTopSquadMatches(studentPreferences, squads).filter(s => {
    const matchesSubject = subjectFilter === 'All' || s.subject === subjectFilter;
    const matchesSchedule = scheduleFilter === 'All' || s.schedule_block === scheduleFilter;
    return matchesSubject && matchesSchedule;
  });

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 1rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ margin: 0, fontSize: '1.5rem' }}>Subject Study Squad Matcher</h2>
          <p style={{ margin: '0.25rem 0 0 0', color: 'var(--text-muted)', fontSize: '0.9rem' }}>
            Multi-factor weighted Jaccard matrix matching students by exam, schedule, and room preferences.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <select
            value={scheduleFilter}
            onChange={e => setScheduleFilter(e.target.value)}
            style={{ padding: '0.5rem 1rem', borderRadius: '8px', border: '1px solid var(--glass-border)', background: 'var(--card-bg)', color: 'var(--text-main)', fontSize: '0.9rem' }}
          >
            <option value="All">All Time Blocks</option>
            <option value="Morning">Morning</option>
            <option value="Afternoon">Afternoon</option>
            <option value="Evening">Evening</option>
            <option value="Late Night">Late Night</option>
          </select>

          <select
            value={subjectFilter}
            onChange={e => setSubjectFilter(e.target.value)}
            style={{ padding: '0.5rem 1rem', borderRadius: '8px', border: '1px solid var(--glass-border)', background: 'var(--card-bg)', color: 'var(--text-main)', fontSize: '0.9rem' }}
          >
            <option value="All">All Subjects</option>
            <option value="Operating Systems">Operating Systems</option>
            <option value="Linear Algebra">Linear Algebra</option>
            <option value="Computer Networks">Computer Networks</option>
          </select>

          <button
            onClick={() => setIsModalOpen(true)}
            style={{ padding: '0.5rem 1rem', background: 'var(--accent-primary)', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
          >
            <PlusCircle size={18} /> Create Squad
          </button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.25rem' }}>
        {rankedSquads.map(squad => (
          <SquadCard key={squad.id} squad={squad} onJoin={joinSquad} onOpenWorkspace={onOpenWorkspace} />
        ))}
      </div>

      <CreateSquadModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
}
