import React from 'react';
import { useSquad } from '../context/SquadContext';
import { Info } from 'lucide-react';

export function Toast() {
  const { toastMessage } = useSquad();
  if (!toastMessage) return null;

  return (
    <div style={{
      position: 'fixed',
      bottom: '24px',
      right: '24px',
      background: 'var(--bg-secondary)',
      color: 'var(--text-main)',
      border: '1px solid var(--accent-primary)',
      padding: '0.85rem 1.25rem',
      borderRadius: '12px',
      boxShadow: '0 10px 25px rgba(0,0,0,0.3)',
      display: 'flex',
      alignItems: 'center',
      gap: '0.5rem',
      zIndex: 9999
    }}>
      <Info size={18} color="var(--accent-primary)" />
      <span style={{ fontSize: '0.9rem', fontWeight: 500 }}>{toastMessage}</span>
    </div>
  );
}
