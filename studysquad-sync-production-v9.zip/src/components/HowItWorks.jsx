import React from 'react';
import { Radio, Clock, Users, ShieldCheck } from 'lucide-react';

export function HowItWorks() {
  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '0 1rem' }}>
      <div className="glass-card" style={{ marginBottom: '1.5rem' }}>
        <h2 style={{ marginTop: 0 }}>How StudySquad Sync Works</h2>
        <p style={{ color: 'var(--text-muted)' }}>
          StudySquad Sync eliminates wasted time hunting for empty campus library rooms or searching for compatible peer study partners.
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1.25rem' }}>
        <div className="glass-card">
          <div style={{ background: 'rgba(99, 102, 241, 0.2)', padding: '0.75rem', borderRadius: '12px', width: 'fit-content', color: 'var(--accent-primary)', marginBottom: '0.75rem' }}>
            <Radio size={24} />
          </div>
          <h3>1. RoomRadar Telemetry</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
            Live PIR motion sensors and decibel noise meters map occupancy across 12 campus study pods in real time.
          </p>
        </div>

        <div className="glass-card">
          <div style={{ background: 'rgba(245, 158, 11, 0.2)', padding: '0.75rem', borderRadius: '12px', width: 'fit-content', color: '#f59e0b', marginBottom: '0.75rem' }}>
            <Clock size={24} />
          </div>
          <h3>2. 20-Minute Hold Lock</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
            Place a temporary 20-minute hold on a desk while walking to campus. Background workers release unconfirmed ghost holds.
          </p>
        </div>

        <div className="glass-card">
          <div style={{ background: 'rgba(34, 197, 94, 0.2)', padding: '0.75rem', borderRadius: '12px', width: 'fit-content', color: '#22c55e', marginBottom: '0.75rem' }}>
            <Users size={24} />
          </div>
          <h3>3. Squad Matcher Engine</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
            Multi-factor weighted Jaccard matrix matches students by exam subjects, discrete schedule time blocks, and peer ratings.
          </p>
        </div>
      </div>
    </div>
  );
}
