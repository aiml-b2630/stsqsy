import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Shield, Sun, Moon, Radio, Users } from 'lucide-react';

export function Header({ activeTab, setActiveTab, theme, toggleTheme }) {
  const { user } = useAuth();

  return (
    <header className="glass-card" style={{ borderRadius: 0, borderTop: 0, borderLeft: 0, borderRight: 0, marginBottom: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{ background: 'var(--accent-primary)', padding: '0.5rem', borderRadius: '12px', display: 'flex' }}>
            <Users size={24} color="#fff" />
          </div>
          <div>
            <h1 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 700 }}>StudySquad Sync</h1>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
              <Radio size={12} color="var(--status-available)" /> RoomRadar Telemetry Active
            </span>
          </div>
        </div>

        <nav style={{ display: 'flex', gap: '0.5rem' }}>
          <button
            onClick={() => setActiveTab('radar')}
            style={{
              padding: '0.5rem 1rem',
              borderRadius: '8px',
              border: 'none',
              cursor: 'pointer',
              background: activeTab === 'radar' ? 'var(--accent-primary)' : 'transparent',
              color: activeTab === 'radar' ? '#fff' : 'var(--text-muted)',
              fontWeight: 600
            }}
          >
            RoomRadar
          </button>
          <button
            onClick={() => setActiveTab('matcher')}
            style={{
              padding: '0.5rem 1rem',
              borderRadius: '8px',
              border: 'none',
              cursor: 'pointer',
              background: activeTab === 'matcher' ? 'var(--accent-primary)' : 'transparent',
              color: activeTab === 'matcher' ? '#fff' : 'var(--text-muted)',
              fontWeight: 600
            }}
          >
            Squad Matcher
          </button>
          <button
            onClick={() => setActiveTab('workspace')}
            style={{
              padding: '0.5rem 1rem',
              borderRadius: '8px',
              border: 'none',
              cursor: 'pointer',
              background: activeTab === 'workspace' ? 'var(--accent-primary)' : 'transparent',
              color: activeTab === 'workspace' ? '#fff' : 'var(--text-muted)',
              fontWeight: 600
            }}
          >
            Focus Workspace
          </button>
          <button
            onClick={() => setActiveTab('how')}
            style={{
              padding: '0.5rem 1rem',
              borderRadius: '8px',
              border: 'none',
              cursor: 'pointer',
              background: activeTab === 'how' ? 'var(--accent-primary)' : 'transparent',
              color: activeTab === 'how' ? '#fff' : 'var(--text-muted)',
              fontWeight: 600
            }}
          >
            How It Works
          </button>
        </nav>

        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button
            onClick={toggleTheme}
            style={{ background: 'transparent', border: '1px solid var(--glass-border)', color: 'var(--text-main)', padding: '0.5rem', borderRadius: '8px', cursor: 'pointer' }}
            title="Toggle Theme"
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <div style={{ fontSize: '0.85rem', textAlign: 'right' }}>
            <div style={{ fontWeight: 600 }}>{user ? user.name : 'Student'}</div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{user ? user.role : 'Student'}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
