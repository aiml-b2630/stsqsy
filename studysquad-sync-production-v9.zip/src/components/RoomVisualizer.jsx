import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import { RoomCard } from './RoomCard';
import { Search, Filter } from 'lucide-react';

export function RoomVisualizer() {
  const { rooms, holdRoom } = useSquad();
  const [search, setSearch] = useState('');
  const [filterAmenity, setFilterAmenity] = useState('All');

  const filteredRooms = rooms.filter(room => {
    const matchesSearch = room.name.toLowerCase().includes(search.toLowerCase()) || room.building.toLowerCase().includes(search.toLowerCase());
    const matchesAmenity = filterAmenity === 'All' || room.amenities.includes(filterAmenity);
    return matchesSearch && matchesAmenity;
  });

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 1rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ margin: 0, fontSize: '1.5rem' }}>Campus Study Room Radar</h2>
          <p style={{ margin: '0.25rem 0 0 0', color: 'var(--text-muted)', fontSize: '0.9rem' }}>
            Live PIR motion telemetry & noise level monitoring across 12 discussion pods.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <div style={{ position: 'relative' }}>
            <Search size={18} color="var(--text-muted)" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              type="text"
              placeholder="Search library, block..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{
                padding: '0.5rem 0.5rem 0.5rem 2.25rem',
                borderRadius: '8px',
                border: '1px solid var(--glass-border)',
                background: 'var(--card-bg)',
                color: 'var(--text-main)',
                fontSize: '0.9rem'
              }}
            />
          </div>

          <select
            value={filterAmenity}
            onChange={(e) => setFilterAmenity(e.target.value)}
            style={{
              padding: '0.5rem 1rem',
              borderRadius: '8px',
              border: '1px solid var(--glass-border)',
              background: 'var(--card-bg)',
              color: 'var(--text-main)',
              fontSize: '0.9rem'
            }}
          >
            <option value="All">All Amenities</option>
            <option value="Whiteboard">Whiteboard</option>
            <option value="Silent Zone">Silent Zone</option>
            <option value="Group Discussion">Group Discussion</option>
            <option value="Power Sockets">Power Sockets</option>
            <option value="Dual Monitors">Dual Monitors</option>
          </select>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1.25rem' }}>
        {filteredRooms.map(room => (
          <RoomCard key={room.id} room={room} onHold={holdRoom} />
        ))}
      </div>
    </div>
  );
}
