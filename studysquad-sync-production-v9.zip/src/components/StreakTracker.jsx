import React from 'react';
import { Flame, Award, ShieldCheck } from 'lucide-react';

export function StreakTracker({ streakDays = 5 }) {
  return (
    <div className="glass-card" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
        <div style={{ background: 'rgba(245, 158, 11, 0.2)', padding: '0.75rem', borderRadius: '12px', color: '#f59e0b' }}>
          <Flame size={24} />
        </div>
        <div>
          <div style={{ fontWeight: 700, fontSize: '1.1rem' }}>{streakDays}-Day Peer Study Streak!</div>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Group completed 14 total focus hours this week</div>
        </div>
      </div>
      <span className="badge badge-available" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
        <Award size={14} /> Streak Master
      </span>
    </div>
  );
}
