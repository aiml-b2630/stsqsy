import React from 'react';
import { Users, Clock, MapPin, Award, Star, Flame } from 'lucide-react';

export function SquadCard({ squad, onJoin, onOpenWorkspace }) {
  const isFull = squad.current_members >= squad.max_members;

  return (
    <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', gap: '1rem' }}>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.4rem' }}>
          <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 700 }}>{squad.title}</h3>
          {squad.matchScore !== undefined && (
            <span style={{ background: 'rgba(99, 102, 241, 0.2)', color: 'var(--accent-primary)', padding: '0.2rem 0.6rem', borderRadius: '12px', fontSize: '0.75rem', fontWeight: 700 }}>
              {squad.matchScore}% Match
            </span>
          )}
        </div>

        <div style={{ color: 'var(--accent-primary)', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.5rem' }}>
          {squad.subject} • <span style={{ color: 'var(--text-muted)' }}>{squad.target_topic}</span>
        </div>

        <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', flexColumn: 'column', gap: '0.3rem', marginBottom: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
            <MapPin size={14} color="var(--accent-primary)" /> {squad.room_name}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
            <Clock size={14} color="var(--accent-primary)" /> {squad.meeting_time} ({squad.schedule_block})
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: '#f59e0b' }}>
            <Flame size={14} /> {squad.streak_days}-Day Streak • <Star size={14} /> {squad.average_rating} Rating
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: '0.5rem' }}>
        <button
          onClick={() => onJoin(squad.id)}
          disabled={isFull}
          style={{
            flex: 1,
            padding: '0.6rem',
            borderRadius: '8px',
            border: 'none',
            background: isFull ? 'rgba(255,255,255,0.1)' : 'var(--accent-primary)',
            color: isFull ? 'var(--text-muted)' : '#fff',
            fontWeight: 600,
            cursor: isFull ? 'not-allowed' : 'pointer'
          }}
        >
          {isFull ? 'Squad Full' : `Join Squad (${squad.current_members}/${squad.max_members})`}
        </button>
        <button
          onClick={() => onOpenWorkspace(squad)}
          style={{
            padding: '0.6rem 0.8rem',
            borderRadius: '8px',
            border: '1px solid var(--glass-border)',
            background: 'transparent',
            color: 'var(--text-main)',
            fontWeight: 600,
            cursor: 'pointer'
          }}
        >
          Workspace
        </button>
      </div>
    </div>
  );
}
