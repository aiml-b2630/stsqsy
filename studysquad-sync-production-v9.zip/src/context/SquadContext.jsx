import React, { createContext, useContext, useState, useEffect } from 'react';

const SquadContext = createContext();

const initialRooms = [
  { id: '1', name: 'Central Library Pod 301', building: 'Central Library', capacity: 4, occupied_seats: 1, noise_level_db: 38, amenities: ['Whiteboard', 'Silent Zone', 'Power Sockets'], status: 'Available', version: 1 },
  { id: '2', name: 'Eng Block Room 102', building: 'Engineering Block', capacity: 8, occupied_seats: 6, noise_level_db: 58, amenities: ['Whiteboard', 'Group Discussion', 'Dual Monitors'], status: 'Available', version: 1 },
  { id: '3', name: 'Student Center Nook B', building: 'Student Center', capacity: 2, occupied_seats: 2, noise_level_db: 65, amenities: ['Power Sockets', 'Group Discussion'], status: 'Occupied', version: 1 },
  { id: '4', name: 'Science Hall Lab 4', building: 'Science Complex', capacity: 6, occupied_seats: 0, noise_level_db: 32, amenities: ['Silent Zone', 'Dual Monitors', 'Whiteboard'], status: 'Available', version: 1 },
  { id: '5', name: 'Law Library Study Carrel 12', building: 'Law Wing', capacity: 1, occupied_seats: 0, noise_level_db: 30, amenities: ['Silent Zone', 'Power Sockets'], status: 'Available', version: 1 },
  { id: '6', name: 'Business Hub Room 204', building: 'Business School', capacity: 6, occupied_seats: 3, noise_level_db: 52, amenities: ['Whiteboard', 'Group Discussion'], status: 'Available', version: 1 },
  { id: '7', name: 'Central Library Pod 302', building: 'Central Library', capacity: 4, occupied_seats: 4, noise_level_db: 42, amenities: ['Whiteboard', 'Power Sockets'], status: 'Occupied', version: 1 },
  { id: '8', name: 'Eng Block Quiet Lab 108', building: 'Engineering Block', capacity: 5, occupied_seats: 1, noise_level_db: 35, amenities: ['Silent Zone', 'Dual Monitors'], status: 'Available', version: 1 },
  { id: '9', name: 'Medical Library Room 1', building: 'Medical Center', capacity: 6, occupied_seats: 2, noise_level_db: 34, amenities: ['Whiteboard', 'Silent Zone'], status: 'Available', version: 1 },
  { id: '10', name: 'Student Center Collab Loft', building: 'Student Center', capacity: 10, occupied_seats: 7, noise_level_db: 68, amenities: ['Group Discussion', 'Whiteboard', 'Power Sockets'], status: 'Available', version: 1 },
  { id: '11', name: 'Arts & Design Studio 3', building: 'Arts Wing', capacity: 4, occupied_seats: 0, noise_level_db: 45, amenities: ['Whiteboard', 'Power Sockets'], status: 'Available', version: 1 },
  { id: '12', name: 'Central Library Silent Basement 04', building: 'Central Library', capacity: 1, occupied_seats: 0, noise_level_db: 28, amenities: ['Silent Zone', 'Power Sockets'], status: 'Available', version: 1 }
];

const initialSquads = [
  { id: 's1', title: 'OS Finals Study Group', subject: 'Operating Systems', target_topic: 'Kernel Threads & Virtual Memory', creator_id: 'u101', creator_name: 'Alex Chen', meeting_time: '16:00', schedule_block: 'Afternoon', max_members: 4, current_members: 3, room_id: '2', room_name: 'Eng Block Room 102', streak_days: 5, average_rating: 4.8 },
  { id: 's2', title: 'Linear Algebra Problem Set', subject: 'Linear Algebra', target_topic: 'Eigenvalues & SVD', creator_id: 'u102', creator_name: 'Maya Patel', meeting_time: '18:30', schedule_block: 'Evening', max_members: 5, current_members: 2, room_id: '1', room_name: 'Central Library Pod 301', streak_days: 3, average_rating: 4.6 },
  { id: 's3', title: 'GATE CS Mock Revision', subject: 'Computer Networks', target_topic: 'TCP Congestion & Routing Algorithms', creator_id: 'u103', creator_name: 'Jordan Smith', meeting_time: '20:00', schedule_block: 'Late Night', max_members: 6, current_members: 4, room_id: '6', room_name: 'Business Hub Room 204', streak_days: 7, average_rating: 4.9 }
];

export function SquadProvider({ children }) {
  const [rooms, setRooms] = useState(initialRooms);
  const [squads, setSquads] = useState(initialSquads);
  const [activeHold, setActiveHold] = useState(null);
  const [activeWorkspaceSquad, setActiveWorkspaceSquad] = useState(initialSquads[0]);
  const [toastMessage, setToastMessage] = useState(null);

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const holdRoom = (roomId) => {
    const targetRoom = rooms.find(r => r.id === roomId);
    if (!targetRoom || targetRoom.status !== 'Available') {
      showToast('Room is not available for hold.');
      return false;
    }

    const holdUntil = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, status: 'Reserved', version: r.version + 1 } : r));
    setActiveHold({ roomId, roomName: targetRoom.name, holdUntil, version: targetRoom.version + 1 });
    showToast(`20-Minute hold confirmed for ${targetRoom.name}!`);
    return true;
  };

  const releaseHold = (roomId) => {
    setRooms(prev => prev.map(r => r.id === roomId ? { ...r, status: 'Available', version: r.version + 1 } : r));
    setActiveHold(null);
    showToast('Room hold released.');
  };

  const createSquad = (squadData) => {
    const newSquad = {
      id: 's_' + Date.now(),
      ...squadData,
      current_members: 1,
      streak_days: 1,
      average_rating: 5.0
    };
    setSquads(prev => [newSquad, ...prev]);
    setActiveWorkspaceSquad(newSquad);
    showToast(`Study squad "${newSquad.title}" created successfully!`);
  };

  const joinSquad = (squadId) => {
    setSquads(prev => prev.map(s => {
      if (s.id === squadId && s.current_members < s.max_members) {
        const updated = { ...s, current_members: s.current_members + 1 };
        setActiveWorkspaceSquad(updated);
        return updated;
      }
      return s;
    }));
    showToast('Joined study squad!');
  };

  return (
    <SquadContext.Provider value={{
      rooms,
      squads,
      activeHold,
      activeWorkspaceSquad,
      setActiveWorkspaceSquad,
      holdRoom,
      releaseHold,
      createSquad,
      joinSquad,
      toastMessage,
      showToast
    }}>
      {children}
    </SquadContext.Provider>
  );
}

export function useSquad() {
  return useContext(SquadContext);
}
