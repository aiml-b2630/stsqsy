import React, { createContext, useContext, useState } from 'react';
import { apiRequest } from '../utils/api';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [token, setToken] = useState(localStorage.getItem('study_token') || 'demo_jwt_token');
  const [user, setUser] = useState({ id: 'u101', name: 'Alex Chen', email: 'alex@campus.edu', role: 'Student' });

  const login = async (email, password) => {
    const res = await apiRequest('/auth/login', 'POST', { email, password });
    if (res.token) {
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem('study_token', res.token);
      return { success: true };
    }
    return { success: false, error: res.error || 'Login failed' };
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('study_token');
  };

  return (
    <AuthContext.Provider value={{ token, user, login, logout, isAuthenticated: !!token }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
