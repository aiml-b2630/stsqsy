import { describe, it, expect } from 'vitest';
import { calculateMatchScore, findTopSquadMatches } from '../utils/matchingEngine';

describe('Heuristic Matching Engine Unit Test Suite', () => {
  const mockSquads = [
    { id: '1', subject: 'Operating Systems', schedule_block: 'Afternoon', amenities: ['Whiteboard'], streak_days: 5, average_rating: 4.8 },
    { id: '2', subject: 'Linear Algebra', schedule_block: 'Morning', amenities: ['Silent Zone'], streak_days: 2, average_rating: 4.2 }
  ];

  it('calculates higher score for matching schedule block and subject tokens', () => {
    const pref = { subject: 'Operating Systems', preferredScheduleBlock: 'Afternoon', desiredAmenity: 'Whiteboard' };
    const score = calculateMatchScore(pref, mockSquads[0]);
    expect(score).toBeGreaterThan(80);
  });

  it('ranks squads by match percentage accurately', () => {
    const pref = { subject: 'Operating Systems', preferredScheduleBlock: 'Afternoon' };
    const ranked = findTopSquadMatches(pref, mockSquads);
    expect(ranked[0].id).toBe('1');
    expect(ranked[0].matchScore).toBeGreaterThan(ranked[1].matchScore);
  });
});
