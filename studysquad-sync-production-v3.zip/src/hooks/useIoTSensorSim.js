import { useEffect } from 'react';

export function useIoTSensorSim(rooms, setRooms) {
  useEffect(() => {
    if (!rooms || rooms.length === 0) return;

    const interval = setInterval(() => {
      setRooms(prevRooms =>
        prevRooms.map(room => {
          if (Math.random() > 0.4) {
            const chairDelta = Math.random() > 0.5 ? 1 : -1;
            const newChairs = Math.max(0, Math.min(room.capacity, room.occupiedChairs + chairDelta));
            const noiseDelta = Math.floor((Math.random() - 0.5) * 6);
            const newNoise = Math.max(30, Math.min(75, room.noiseLevelDb + noiseDelta));
            return {
              ...room,
              occupiedChairs: newChairs,
              noiseLevelDb: newNoise,
              version: (room.version || 1) + 1
            };
          }
          return room;
        })
      );
    }, 6000);

    return () => clearInterval(interval);
  }, [setRooms]);
}
