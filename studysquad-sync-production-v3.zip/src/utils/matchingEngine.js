export function calculateSquadMatchScore(studentPreferences, squad) {
  let score = 0;
  if (!studentPreferences || !squad) return 0;

  if (studentPreferences.subject && squad.subject.toLowerCase().includes(studentPreferences.subject.toLowerCase())) {
    score += 50;
  }
  if (studentPreferences.meetingTime && squad.meetingTime === studentPreferences.meetingTime) {
    score += 30;
  }
  if (squad.members && squad.members.length < squad.maxCapacity) {
    score += 20;
  }
  return score;
}

export function rankSquadsForStudent(studentPreferences, squadsList = []) {
  return squadsList
    .map(squad => ({
      ...squad,
      matchScore: calculateSquadMatchScore(studentPreferences, squad)
    }))
    .sort((a, b) => b.matchScore - a.matchScore);
}
