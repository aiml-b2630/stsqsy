export function sanitizeString(input) {
  if (typeof input !== 'string') return '';
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;')
    .trim();
}

export function validateSquadInput({ title, subject, maxCapacity }) {
  const errors = {};
  if (!title || sanitizeString(title).length < 3) {
    errors.title = 'Squad title must be at least 3 characters long.';
  }
  if (!subject || sanitizeString(subject).length < 2) {
    errors.subject = 'Please specify a valid study subject.';
  }
  const cap = Number(maxCapacity);
  if (isNaN(cap) || cap < 2 || cap > 12) {
    errors.maxCapacity = 'Group capacity must be between 2 and 12 members.';
  }
  return { isValid: Object.keys(errors).length === 0, errors };
}
