import React, { createContext, useContext, useState, useEffect } from 'react';
import { useIoTSensorSim } from '../hooks/useIoTSensorSim';
import { fetchRooms, holdRoomApi, createSquadApi } from '../api/client';
import { useAuth } from './AuthContext';

const SquadContext = createContext();

const initialRooms = [
  { id: 'room_1', name: 'Central Library Pod #1', building: 'Central Library 3rd Floor', capacity: 4, occupiedChairs: 1, noiseLevelDb: 38, isSilent: true, hasWhiteboard: true, hasPower: true, hasDualMonitors: false, holdStatus: { isHeld: false, heldBy: null, expiresAt: null }, version: 1 },
  { id: 'room_2', name: 'Engineering Block Rm 204', building: 'Engineering Complex', capacity: 8, occupiedChairs: 6, noiseLevelDb: 62, isSilent: false, hasWhiteboard: true, hasPower: true, hasDualMonitors: true, holdStatus: { isHeld: false, heldBy: null, expiresAt: null }, version: 1 },
  { id: 'room_3', name: 'Silent Study Alcove C', building: 'West Wing Library', capacity: 2, occupiedChairs: 2, noiseLevelDb: 32, isSilent: true, hasWhiteboard: false, hasPower: true, hasDualMonitors: false, holdStatus: { isHeld: false, heldBy: null, expiresAt: null }, version: 1 },
  { id: 'room_4', name: 'Student Center Discussion Glassroom', building: 'Student Union', capacity: 6, occupiedChairs: 2, noiseLevelDb: 54, isSilent: false, hasWhiteboard: true, hasPower: true, hasDualMonitors: true, holdStatus: { isHeld: false, heldBy: null, expiresAt: null }, version: 1 },
  { id: 'room_5', name: 'Science Hub Pod B', building: 'Science Quad', capacity: 4, occupiedChairs: 0, noiseLevelDb: 35, isSilent: true, hasWhiteboard: true, hasPower: true, hasDualMonitors: false, holdStatus: { isHeld: false, heldBy: null, expiresAt: null }, version: 1 },
  { id: 'room_6', name: 'Graduate Research Lab', building: 'North Campus', capacity: 10, occupiedChairs: 7, noiseLevelDb: 48, isSilent: false, hasWhiteboard: true, hasPower: true, hasDualMonitors: true, holdStatus: { isHeld: false, heldBy: null, expiresAt: null }, version: 1 }
];

const initialSquads = [
  { id: 'squad_1', title: 'OS Finals Review Squad', subject: 'Operating Systems', topic: 'Virtual Memory & Concurrency', meetingTime: 'Afternoon', maxCapacity: 4, roomId: 'room_2', members: [{ id: 'usr_2026', name: 'Alex Rivera', role: 'Leader' }], goalChecklist: ['Review Page Replacement Algorithms', 'Practice Deadlock Problems'] },
  { id: 'squad_2', title: 'Linear Algebra Problem Solving', subject: 'Mathematics', topic: 'Eigenvalues & Vector Spaces', meetingTime: 'Morning', maxCapacity: 5, roomId: 'room_1', members: [{ id: 'usr_999', name: 'Sam Chen', role: 'Leader' }], goalChecklist: ['Solve Chapter 5 Review', 'Proof Practice'] }
];

export function SquadProvider({ children }) {
  const { user, token } = useAuth();
  
  const [rooms, setRooms] = useState(() => {
    try {
      const saved = localStorage.getItem('studysquad_rooms');
      return saved ? JSON.parse(saved) : initialRooms;
    } catch (e) { return initialRooms; }
  });

  const [squads, setSquads] = useState(() => {
    try {
      const saved = localStorage.getItem('studysquad_squads');
      return saved ? JSON.parse(saved) : initialSquads;
    } catch (e) { return initialSquads; }
  });

  const [activeHoldRoom, setActiveHoldRoom] = useState(null);

  // Sync to API on mount if backend live
  useEffect(() => {
    fetchRooms().then(apiRooms => {
      if (apiRooms && apiRooms.length > 0) {
        setRooms(apiRooms);
      }
    });
  }, []);

  // Save state resilience to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('studysquad_rooms', JSON.stringify(rooms));
      localStorage.setItem('studysquad_squads', JSON.stringify(squads));
    } catch (e) {}
  }, [rooms, squads]);

  // IoT Sensor Loop
  useIoTSensorSim(rooms, setRooms);

  const placeHoldOnRoom = async (roomId, durationMinutes = 20) => {
    const room = rooms.find(r => r.id === roomId);
    if (!room) return;

    try {
      // Try backend REST endpoint first
      await holdRoomApi(roomId, room.version, token);
    } catch (err) {
      console.warn('Backend API hold fallback to local state handling:', err.message);
    }

    const expiresAt = Date.now() + durationMinutes * 60 * 1000;
    setRooms(prev => prev.map(r => r.id === roomId ? {
      ...r,
      holdStatus: { isHeld: true, heldBy: user.id, expiresAt },
      version: (r.version || 1) + 1
    } : r));

    setActiveHoldRoom({ roomId, expiresAt });
  };

  const releaseHold = (roomId) => {
    setRooms(prev => prev.map(r => r.id === roomId ? {
      ...r,
      holdStatus: { isHeld: false, heldBy: null, expiresAt: null },
      version: (r.version || 1) + 1
    } : r));
    if (activeHoldRoom?.roomId === roomId) {
      setActiveHoldRoom(null);
    }
  };

  const createSquad = async (newSquadData) => {
    const squadObj = {
      id: `squad_${Date.now()}`,
      ...newSquadData,
      members: [{ id: user.id, name: user.name, role: 'Leader' }],
      goalChecklist: ['Kickoff session & review agenda']
    };

    try {
      await createSquadApi(squadObj, token);
    } catch (e) {}

    setSquads(prev => [squadObj, ...prev]);
  };

  const joinSquad = (squadId) => {
    setSquads(prev => prev.map(sq => {
      if (sq.id === squadId) {
        if (sq.members.some(m => m.id === user.id)) return sq;
        if (sq.members.length >= sq.maxCapacity) return sq;
        return {
          ...sq,
          members: [...sq.members, { id: user.id, name: user.name, role: 'Member' }]
        };
      }
      return sq;
    }));
  };

  return (
    <SquadContext.Provider value={{
      rooms, setRooms, squads, activeHoldRoom, placeHoldOnRoom, releaseHold, createSquad, joinSquad
    }}>
      {children}
    </SquadContext.Provider>
  );
}

export function useSquad() {
  return useContext(SquadContext);
}
