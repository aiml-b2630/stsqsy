import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('studysquad_user');
      return saved ? JSON.parse(saved) : { id: 'usr_2026', name: 'Alex Rivera', role: 'Student', email: 'alex@campus.edu' };
    } catch (e) {
      return { id: 'usr_2026', name: 'Alex Rivera', role: 'Student', email: 'alex@campus.edu' };
    }
  });

  const [token, setToken] = useState(() => localStorage.getItem('studysquad_token') || 'jwt-token-alex-2026');

  useEffect(() => {
    try {
      localStorage.setItem('studysquad_user', JSON.stringify(user));
      localStorage.setItem('studysquad_token', token);
    } catch (e) {}
  }, [user, token]);

  const toggleRole = () => {
    setUser(prev => ({
      ...prev,
      role: prev.role === 'Student' ? 'Room Admin' : 'Student'
    }));
  };

  const login = (email) => {
    const newUser = {
      id: `usr_${Date.now()}`,
      name: email ? email.split('@')[0] : 'Campus Student',
      email: email || 'student@campus.edu',
      role: 'Student'
    };
    setUser(newUser);
    setToken(`jwt-token-${Date.now()}`);
  };

  return (
    <AuthContext.Provider value={{ user, token, toggleRole, login }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
