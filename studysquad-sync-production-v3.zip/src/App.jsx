import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { SquadProvider, useSquad } from './context/SquadContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Header } from './components/Header';
import { Filter, Users, Search, Volume2, Shield, Clock, BookOpen, CheckCircle, Plus } from 'lucide-react';

function RoomRadarView() {
  const { rooms, placeHoldOnRoom } = useSquad();
  const [filterAmenity, setFilterAmenity] = useState('all');
  const [filterSilent, setFilterSilent] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = rooms.filter(room => {
    if (filterSilent && !room.isSilent) return false;
    if (filterAmenity === 'whiteboard' && !room.hasWhiteboard) return false;
    if (filterAmenity === 'power' && !room.hasPower) return false;
    if (filterAmenity === 'monitors' && !room.hasDualMonitors) return false;
    if (searchQuery && !room.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="room-radar-container">
      <div className="filter-bar glass-panel">
        <div className="search-input-wrapper">
          <Search size={16} />
          <input 
            type="text" 
            placeholder="Search campus rooms..." 
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="filter-group">
          <label><Filter size={14} /> Amenity:</label>
          <select value={filterAmenity} onChange={e => setFilterAmenity(e.target.value)}>
            <option value="all">All Facilities</option>
            <option value="whiteboard">Whiteboard</option>
            <option value="power">Power Sockets</option>
            <option value="monitors">Dual Monitors</option>
          </select>
        </div>

        <button 
          className={`toggle-btn ${filterSilent ? 'active' : ''}`}
          onClick={() => setFilterSilent(!filterSilent)}
        >
          🤫 Silent Zones Only
        </button>
      </div>

      <div className="rooms-grid">
        {filtered.map(room => (
          <div key={room.id} className={`room-card glass-panel ${room.holdStatus?.isHeld ? 'is-held' : ''}`}>
            <div className="room-card-header">
              <h3>{room.name}</h3>
              <span className={`status-badge ${room.occupiedChairs >= room.capacity ? 'full' : room.holdStatus?.isHeld ? 'held' : 'available'}`}>
                {room.holdStatus?.isHeld ? '20m Hold Active' : room.occupiedChairs >= room.capacity ? 'Occupied' : 'Available'}
              </span>
            </div>

            <p className="building-sub">{room.building}</p>

            <div className="room-stats">
              <div className="stat-pill">
                <Users size={14} />
                <span>{room.occupiedChairs} / {room.capacity} Chairs Occupied</span>
              </div>
              <div className="stat-pill">
                <Volume2 size={14} />
                <span>{room.noiseLevelDb} dB IoT Meter</span>
              </div>
            </div>

            <div className="amenities-tags">
              {room.isSilent && <span className="tag silent">Silent Zone</span>}
              {room.hasWhiteboard && <span className="tag">Whiteboard</span>}
              {room.hasPower && <span className="tag">Power</span>}
              {room.hasDualMonitors && <span className="tag">Monitors</span>}
            </div>

            <div className="card-actions">
              <button 
                className="hold-btn"
                disabled={room.holdStatus?.isHeld || room.occupiedChairs >= room.capacity}
                onClick={() => placeHoldOnRoom(room.id, 20)}
              >
                ⏱️ Place 20-Min Hold
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SquadsView() {
  const { squads, joinSquad, createSquad } = useSquad();
  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [meetingTime, setMeetingTime] = useState('Afternoon');

  const handleCreate = (e) => {
    e.preventDefault();
    if (!title || !subject) return;
    createSquad({ title, subject, meetingTime, maxCapacity: 4 });
    setTitle('');
    setSubject('');
    setShowModal(false);
  };

  return (
    <div className="squads-container">
      <div className="squads-header">
        <div>
          <h2>Academic Study Squads</h2>
          <p>Find peer study groups sharing your exact schedule & subjects.</p>
        </div>
        <button className="primary-btn" onClick={() => setShowModal(true)}>
          <Plus size={16} /> Create Study Squad
        </button>
      </div>

      <div className="squads-grid">
        {squads.map(sq => (
          <div key={sq.id} className="squad-card glass-panel">
            <div className="squad-card-header">
              <h3>{sq.title}</h3>
              <span className="subject-tag">{sq.subject}</span>
            </div>

            <p className="topic-desc">{sq.topic || 'General exam revision & problem sets'}</p>

            <div className="squad-meta">
              <span>📅 {sq.meetingTime} Session</span>
              <span>👥 {sq.members.length} / {sq.maxCapacity} Members</span>
            </div>

            <div className="member-avatars">
              {sq.members.map((m, idx) => (
                <div key={idx} className="avatar-pill" title={m.name}>
                  {m.name.charAt(0)}
                </div>
              ))}
            </div>

            <button className="join-btn" onClick={() => joinSquad(sq.id)}>
              Join Study Squad
            </button>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content glass-panel">
            <h3>Create New Study Squad</h3>
            <form onSubmit={handleCreate}>
              <div className="form-group">
                <label>Squad Title:</label>
                <input type="text" value={title} onChange={e => setTitle(e.target.value)} required placeholder="e.g., Operating Systems Finals" />
              </div>
              <div className="form-group">
                <label>Subject / Course:</label>
                <input type="text" value={subject} onChange={e => setSubject(e.target.value)} required placeholder="e.g., CS 301" />
              </div>
              <div className="form-group">
                <label>Meeting Time:</label>
                <select value={meetingTime} onChange={e => setMeetingTime(e.target.value)}>
                  <option value="Morning">Morning (9 AM - 12 PM)</option>
                  <option value="Afternoon">Afternoon (1 PM - 5 PM)</option>
                  <option value="Late Night">Late Night (7 PM - 11 PM)</option>
                </select>
              </div>
              <div className="modal-actions">
                <button type="button" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="primary-btn">Create Squad</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function WorkspaceView() {
  return (
    <div className="workspace-container glass-panel">
      <h2>🎯 Active Squad Focus Workspace</h2>
      <p>Synchronized session agenda, goal checklists, and Pomodoro focus timer.</p>
      
      <div className="workspace-layout">
        <div className="pomodoro-box">
          <Clock size={48} color="#3b82f6" />
          <h3>25:00 Focus Timer</h3>
          <p>Phase: <strong>Study Session</strong></p>
          <div className="timer-controls">
            <button className="primary-btn">Start Timer</button>
            <button>Reset</button>
          </div>
        </div>

        <div className="goals-box">
          <h3>Squad Checklist</h3>
          <ul>
            <li><CheckCircle size={16} color="#10b981" /> Review Virtual Memory Paging</li>
            <li><CheckCircle size={16} color="#10b981" /> Solve Deadlock Problem Set</li>
            <li>⚪ Discuss Page Replacement Heuristics</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

function HowView() {
  return (
    <div className="how-container glass-panel">
      <h2>📖 How StudySquad Sync Works</h2>
      <ol className="how-steps">
        <li><strong>Check Room Radar:</strong> View real-time occupancy and simulated IoT decibel meters across campus rooms.</li>
        <li><strong>Place a 20-Min Hold:</strong> Lock your desk en route to prevent ghost bookings.</li>
        <li><strong>Join a Squad:</strong> Match with peers based on shared subjects and study times.</li>
        <li><strong>Focus Together:</strong> Work in synchronized 25-minute Pomodoro sessions.</li>
      </ol>
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState('rooms');

  return (
    <AuthProvider>
      <SquadProvider>
        <ErrorBoundary>
          <div className="app-shell">
            <Header activeTab={activeTab} setActiveTab={setActiveTab} />
            <main className="app-main">
              {activeTab === 'rooms' && <RoomRadarView />}
              {activeTab === 'squads' && <SquadsView />}
              {activeTab === 'workspace' && <WorkspaceView />}
              {activeTab === 'how' && <HowView />}
            </main>
          </div>
        </ErrorBoundary>
      </SquadProvider>
    </AuthProvider>
  );
}
