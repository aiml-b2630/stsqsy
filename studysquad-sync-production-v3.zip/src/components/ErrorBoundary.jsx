import React from 'react';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('StudySquad ErrorBoundary caught an exception:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '2rem', textAlign: 'center', background: 'rgba(239, 68, 68, 0.1)', borderRadius: '12px', border: '1px solid #ef4444', margin: '2rem' }}>
          <h2 style={{ color: '#ef4444' }}>⚠️ StudySquad Application Error</h2>
          <p style={{ color: 'var(--text-secondary)' }}>An unexpected state exception occurred. LocalStorage resilience layer will reset faulty state.</p>
          <button 
            onClick={() => { localStorage.clear(); window.location.reload(); }}
            style={{ padding: '0.6rem 1.2rem', background: '#ef4444', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer', marginTop: '1rem' }}
          >
            Reset Session State & Reload
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
