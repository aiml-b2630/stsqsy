import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useSquad } from '../context/SquadContext';
import { Clock, Shield, User, Sparkles } from 'lucide-react';

export function Header({ activeTab, setActiveTab }) {
  const { user, toggleRole } = useAuth();
  const { activeHoldRoom, releaseHold } = useSquad();

  return (
    <header className="app-header glass-panel">
      <div className="logo-container">
        <div className="logo-badge"><Sparkles size={20} color="#3b82f6" /></div>
        <div className="logo-text">
          <h1>StudySquad Sync</h1>
          <span className="badge-v3">v3.0.0 3-Tier Production</span>
        </div>
      </div>

      <nav className="nav-links">
        <button className={activeTab === 'rooms' ? 'active' : ''} onClick={() => setActiveTab('rooms')}>
          📍 Room Radar
        </button>
        <button className={activeTab === 'squads' ? 'active' : ''} onClick={() => setActiveTab('squads')}>
          👥 Study Squads
        </button>
        <button className={activeTab === 'workspace' ? 'active' : ''} onClick={() => setActiveTab('workspace')}>
          🎯 Squad Workspace
        </button>
        <button className={activeTab === 'how' ? 'active' : ''} onClick={() => setActiveTab('how')}>
          📖 How It Works
        </button>
      </nav>

      <div className="user-controls">
        {activeHoldRoom && (
          <div className="active-hold-pill">
            <Clock size={14} className="spin-slow" />
            <span>20m Hold Active</span>
            <button onClick={() => releaseHold(activeHoldRoom.roomId)}>Release</button>
          </div>
        )}
        <button className="role-switch-btn" onClick={toggleRole}>
          <Shield size={14} />
          <span>{user.role}</span>
        </button>
        <div className="user-profile">
          <User size={16} />
          <span>{user.name}</span>
        </div>
      </div>
    </header>
  );
}
