const API_BASE = 'http://localhost:3001/api';

export async function fetchRooms() {
  try {
    const res = await fetch(`${API_BASE}/rooms`);
    if (!res.ok) throw new Error('API server unavailable');
    const data = await res.json();
    return data.rooms;
  } catch (err) {
    console.warn('Backend REST API unavailable, falling back to local state:', err.message);
    return null;
  }
}

export async function holdRoomApi(roomId, clientVersion, token) {
  try {
    const res = await fetch(`${API_BASE}/rooms/${roomId}/hold`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ durationMinutes: 20, clientVersion })
    });
    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error || 'Failed to place hold');
    }
    return await res.json();
  } catch (err) {
    throw err;
  }
}

export async function createSquadApi(squadData, token) {
  try {
    const res = await fetch(`${API_BASE}/squads`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(squadData)
    });
    if (!res.ok) throw new Error('Failed to create squad on backend API');
    return await res.json();
  } catch (err) {
    return null;
  }
}
