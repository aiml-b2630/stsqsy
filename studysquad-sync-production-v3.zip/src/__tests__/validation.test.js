import { describe, it, expect } from 'vitest';
import { sanitizeString, validateSquadInput } from '../utils/validation';
import { calculateSquadMatchScore } from '../utils/matchingEngine';

describe('Frontend Validation & Security Sanitization', () => {
  it('sanitizes malicious XSS script tags', () => {
    const malicious = '<script>alert("XSS")</script>';
    const cleaned = sanitizeString(malicious);
    expect(cleaned).not.toContain('<script>');
    expect(cleaned).toContain('&lt;script&gt;');
  });

  it('validates squad input correctly', () => {
    const invalid = validateSquadInput({ title: 'ab', subject: '', maxCapacity: 20 });
    expect(invalid.isValid).toBe(false);
    expect(invalid.errors.title).toBeDefined();
    expect(invalid.errors.subject).toBeDefined();
    expect(invalid.errors.maxCapacity).toBeDefined();

    const valid = validateSquadInput({ title: 'Operating Systems Group', subject: 'CS 301', maxCapacity: 4 });
    expect(valid.isValid).toBe(true);
  });

  it('calculates squad match scores accurately', () => {
    const prefs = { subject: 'Mathematics', meetingTime: 'Morning' };
    const squad = { subject: 'Mathematics Finals', meetingTime: 'Morning', members: [{ id: '1' }], maxCapacity: 4 };
    const score = calculateSquadMatchScore(prefs, squad);
    expect(score).toEqual(100);
  });
});
