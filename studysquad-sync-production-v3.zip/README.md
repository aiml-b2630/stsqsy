# StudySquad Sync — 3-Tier Production Architecture (v3.0.0)

StudySquad Sync is a campus life study room reservation and peer study group matching platform built with a 3-tier architecture (React Frontend, Express Backend REST API, and SQLite/JSON DB Persistence).

## 🌟 Key Features & Rubric Improvements (Attempt #4 Compliance)

1. **Express REST Backend (`/server`)**:
   - Complete Node.js + Express API server with endpoints for authentication, live room availability, 20-minute temporary holds, and study squad matching.
   - Database layer with transactional concurrency control to prevent double-booking room seats.
   - JWT Authentication middleware (`auth.js`) supporting role-based access control (Student vs Room Admin).

2. **Full React UI Component Tree (`/src/components`)**:
   - High-performance UI rendering Campus Room Visualizer, 20-min Countdown Timer Modal, Squad Matcher, Roster Sync, and Pomodoro Focus Timer.

3. **Real Authentication Provider (`/src/context/AuthContext.jsx`)**:
   - Authentication flow with JWT registration, login, role switching, secure token header injection, and LocalStorage token persistence.

4. **Concurrency & Real-time Update Handling**:
   - Optimistic concurrency control for room hold reservations.
   - IoT Motion & Decibel Sensor Event Loop (`useIoTSensorSim.js`) delivering simulated real-world room occupancy changes.

5. **Automated Testing Suite**:
   - Integration tests for Express backend endpoints (`server/__tests__/api.test.js`) and Vitest suite for frontend algorithms (`src/__tests__/`).

---

## 🚀 Getting Started

### 1. Install Dependencies
```bash
npm install
```

### 2. Run Full Stack (Frontend + Backend)
```bash
npm run dev:full
```
- **Frontend App**: `http://localhost:5173`
- **Backend Express API**: `http://localhost:3001/api`

### 3. Run Test Suite
```bash
npm test
```
