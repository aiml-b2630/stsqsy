import express from 'express';
import cors from 'cors';
import authRoutes from './routes/auth.js';
import roomsRoutes from './routes/rooms.js';
import squadsRoutes from './routes/squads.js';

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/rooms', roomsRoutes);
app.use('/api/squads', squadsRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'StudySquad Sync API 3-Tier Server', timestamp: new Date() });
});

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    console.log(`StudySquad Express REST Server running on port ${PORT}`);
  });
}

export default app;
