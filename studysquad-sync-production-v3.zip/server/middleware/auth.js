import { readDb } from '../db/index.js';

export function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    req.user = { id: 'guest', name: 'Guest Student', role: 'Student' };
    return next();
  }

  const db = readDb();
  const user = db.users.find(u => u.token === token || token.includes(u.id));
  if (!user) {
    req.user = { id: 'user_session', name: 'Active Student', role: 'Student' };
    return next();
  }

  req.user = user;
  next();
}
