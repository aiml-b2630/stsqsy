import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE = path.join(__dirname, 'data.json');

const initialData = {
  users: [
    { id: 'user_1', name: 'Alex Rivera', email: 'alex@campus.edu', role: 'Student', token: 'mock-jwt-alex-123' },
    { id: 'admin_1', name: 'Campus Admin', email: 'admin@campus.edu', role: 'Room Admin', token: 'mock-jwt-admin-999' }
  ],
  rooms: [
    { id: 'room_1', name: 'Central Library Pod #1', building: 'Central Library 3rd Floor', capacity: 4, occupiedChairs: 1, noiseLevelDb: 38, isSilent: true, hasWhiteboard: true, hasPower: true, hasDualMonitors: false, holdStatus: { isHeld: false, heldBy: null, expiresAt: null }, version: 1 },
    { id: 'room_2', name: 'Engineering Block Rm 204', building: 'Engineering Complex', capacity: 8, occupiedChairs: 6, noiseLevelDb: 62, isSilent: false, hasWhiteboard: true, hasPower: true, hasDualMonitors: true, holdStatus: { isHeld: false, heldBy: null, expiresAt: null }, version: 1 },
    { id: 'room_3', name: 'Silent Study Alcove C', building: 'West Wing Library', capacity: 2, occupiedChairs: 2, noiseLevelDb: 32, isSilent: true, hasWhiteboard: false, hasPower: true, hasDualMonitors: false, holdStatus: { isHeld: false, heldBy: null, expiresAt: null }, version: 1 },
    { id: 'room_4', name: 'Student Center Discussion Glassroom', building: 'Student Union', capacity: 6, occupiedChairs: 2, noiseLevelDb: 54, isSilent: false, hasWhiteboard: true, hasPower: true, hasDualMonitors: true, holdStatus: { isHeld: false, heldBy: null, expiresAt: null }, version: 1 }
  ],
  squads: [
    { id: 'squad_1', title: 'OS Finals Review Squad', subject: 'Operating Systems', topic: 'Virtual Memory & Concurrency', meetingTime: 'Afternoon', maxCapacity: 4, roomId: 'room_2', members: [{ id: 'user_1', name: 'Alex Rivera', role: 'Leader' }], goalChecklist: ['Review Page Replacement Algorithms', 'Practice Deadlock Problems'] },
    { id: 'squad_2', title: 'Linear Algebra Problem Solving', subject: 'Mathematics', topic: 'Eigenvalues & Vector Spaces', meetingTime: 'Morning', maxCapacity: 5, roomId: 'room_1', members: [{ id: 'user_2', name: 'Sam Chen', role: 'Leader' }], goalChecklist: ['Solve Chapter 5 Review', 'Proof Practice'] }
  ]
};

if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2));
}

export function readDb() {
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    return initialData;
  }
}

export function writeDb(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}
