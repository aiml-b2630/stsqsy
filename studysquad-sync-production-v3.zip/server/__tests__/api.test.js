import { describe, it, expect } from 'vitest';
import request from 'supertest';
import app from '../index.js';

describe('Express REST API Tier Endpoints', () => {
  it('GET /api/health returns status 200 and healthy JSON', async () => {
    const res = await request(app).get('/api/health');
    expect(res.statusCode).toEqual(200);
    expect(res.body.status).toEqual('ok');
  });

  it('GET /api/rooms returns a list of campus study spaces', async () => {
    const res = await request(app).get('/api/rooms');
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body.rooms)).toBe(true);
    expect(res.body.rooms.length).toBeGreaterThan(0);
  });

  it('POST /api/auth/login authenticates and returns JWT token stub', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'test@campus.edu' });
    expect(res.statusCode).toEqual(200);
    expect(res.body.token).toBeDefined();
    expect(res.body.user.email).toEqual('test@campus.edu');
  });
});
