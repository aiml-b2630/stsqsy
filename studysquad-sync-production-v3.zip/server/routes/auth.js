import express from 'express';
import { readDb, writeDb } from '../db/index.js';

const router = express.Router();

router.post('/login', (req, res) => {
  const { email } = req.body;
  const db = readDb();
  let user = db.users.find(u => u.email === email);
  if (!user) {
    user = {
      id: `user_${Date.now()}`,
      name: email ? email.split('@')[0] : 'Campus Student',
      email: email || 'student@campus.edu',
      role: 'Student',
      token: `jwt-token-${Date.now()}`
    };
    db.users.push(user);
    writeDb(db);
  }
  res.json({ success: true, user, token: user.token });
});

router.get('/me', (req, res) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  const db = readDb();
  const user = db.users.find(u => u.token === token) || db.users[0];
  res.json({ user });
});

export default router;
