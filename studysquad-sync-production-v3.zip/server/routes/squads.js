import express from 'express';
import { readDb, writeDb } from '../db/index.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

router.get('/', (req, res) => {
  const db = readDb();
  res.json({ squads: db.squads });
});

router.post('/', authenticateToken, (req, res) => {
  const { title, subject, topic, meetingTime, maxCapacity, roomId } = req.body;
  
  if (!title || !subject) {
    return res.status(400).json({ error: 'Title and Subject are required.' });
  }

  const db = readDb();
  const newSquad = {
    id: `squad_${Date.now()}`,
    title: title.trim(),
    subject: subject.trim(),
    topic: (topic || '').trim(),
    meetingTime: meetingTime || 'Afternoon',
    maxCapacity: Number(maxCapacity) || 4,
    roomId: roomId || 'room_1',
    members: [{ id: req.user.id || 'user_1', name: req.user.name || 'Campus Student', role: 'Leader' }],
    goalChecklist: ['Initial setup & goal review']
  };

  db.squads.push(newSquad);
  writeDb(db);

  res.status(201).json({ success: true, squad: newSquad });
});

router.post('/:id/join', authenticateToken, (req, res) => {
  const { id } = req.params;
  const db = readDb();
  const squadIndex = db.squads.findIndex(s => s.id === id);

  if (squadIndex === -1) return res.status(404).json({ error: 'Squad not found' });

  const squad = db.squads[squadIndex];
  if (squad.members.length >= squad.maxCapacity) {
    return res.status(400).json({ error: 'Squad has reached maximum capacity.' });
  }

  const alreadyJoined = squad.members.some(m => m.id === req.user.id);
  if (!alreadyJoined) {
    squad.members.push({ id: req.user.id || `user_${Date.now()}`, name: req.user.name || 'New Member', role: 'Member' });
    db.squads[squadIndex] = squad;
    writeDb(db);
  }

  res.json({ success: true, squad });
});

export default router;
