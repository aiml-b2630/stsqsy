import express from 'express';
import { readDb, writeDb } from '../db/index.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// GET all rooms
router.get('/', (req, res) => {
  const db = readDb();
  // Auto-clean expired holds
  const now = Date.now();
  let updated = false;
  db.rooms.forEach(room => {
    if (room.holdStatus?.isHeld && room.holdStatus.expiresAt && room.holdStatus.expiresAt < now) {
      room.holdStatus = { isHeld: false, heldBy: null, expiresAt: null };
      updated = true;
    }
  });
  if (updated) writeDb(db);

  res.json({ rooms: db.rooms });
});

// POST 20-minute temporary room hold (with optimistic concurrency check)
router.post('/:id/hold', authenticateToken, (req, res) => {
  const { id } = req.params;
  const { durationMinutes = 20, clientVersion } = req.body;
  const db = readDb();
  const roomIndex = db.rooms.findIndex(r => r.id === id);

  if (roomIndex === -1) {
    return res.status(404).json({ error: 'Room not found' });
  }

  const room = db.rooms[roomIndex];

  // Concurrency check
  if (clientVersion !== undefined && clientVersion !== room.version) {
    return res.status(409).json({ error: 'Conflict: Room availability state changed by another student. Please refresh.' });
  }

  if (room.holdStatus?.isHeld && room.holdStatus.heldBy !== req.user.id) {
    return res.status(400).json({ error: 'Room is currently held by another student.' });
  }

  const expiresAt = Date.now() + durationMinutes * 60 * 1000;
  room.holdStatus = {
    isHeld: true,
    heldBy: req.user.id || 'student_guest',
    expiresAt
  };
  room.version = (room.version || 1) + 1;

  db.rooms[roomIndex] = room;
  writeDb(db);

  res.json({ success: true, room });
});

// DELETE / release room hold
router.delete('/:id/hold', authenticateToken, (req, res) => {
  const { id } = req.params;
  const db = readDb();
  const roomIndex = db.rooms.findIndex(r => r.id === id);

  if (roomIndex === -1) return res.status(404).json({ error: 'Room not found' });

  const room = db.rooms[roomIndex];
  room.holdStatus = { isHeld: false, heldBy: null, expiresAt: null };
  room.version = (room.version || 1) + 1;

  db.rooms[roomIndex] = room;
  writeDb(db);

  res.json({ success: true, room });
});

export default router;
