import React, { useState, useEffect, useContext } from 'react';
import { SquadContext } from '../context/SquadContext';
import { MapPin, Volume2, Users, CheckCircle, Clock, Filter, AlertCircle } from 'lucide-react';

export const RoomVisualizer = () => {
  const { rooms, holdRoom, activeHold, cancelHold } = useContext(SquadContext);
  const [filterAmenity, setFilterAmenity] = useState('All');
  const [filterZone, setFilterZone] = useState('All');
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (!activeHold) {
      setTimeLeft(0);
      return;
    }
    const interval = setInterval(() => {
      const remaining = Math.max(0, Math.floor((activeHold.expiry - Date.now()) / 1000));
      setTimeLeft(remaining);
      if (remaining === 0) {
        cancelHold(activeHold.roomId);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [activeHold, cancelHold]);

  const formatTimer = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const filteredRooms = rooms.filter(room => {
    if (filterAmenity !== 'All' && !room.amenities.includes(filterAmenity)) return false;
    if (filterZone !== 'All' && room.noiseZone !== filterZone) return false;
    return true;
  });

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 glass-panel p-6">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <MapPin className="w-6 h-6 text-cyan-400" /> Campus Room Occupancy Visualizer
          </h2>
          <p className="text-sm text-slate-400">Real-time status, decibel (dB) noise tracking, and amenity filters.</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700 text-xs">
            <Filter className="w-4 h-4 text-cyan-400" />
            <span>Amenity:</span>
            <select
              value={filterAmenity}
              onChange={(e) => setFilterAmenity(e.target.value)}
              className="bg-transparent text-cyan-400 font-semibold outline-none cursor-pointer"
            >
              <option value="All">All Amenities</option>
              <option value="Whiteboard">Whiteboard</option>
              <option value="Power Sockets">Power Sockets</option>
              <option value="Silent Zone">Silent Zone</option>
              <option value="Dual Monitors">Dual Monitors</option>
              <option value="Group Friendly">Group Friendly</option>
            </select>
          </div>
        </div>
      </div>

      {activeHold && (
        <div className="glass-panel p-4 bg-emerald-500/10 border-emerald-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Clock className="w-6 h-6 text-emerald-400 animate-pulse" />
            <div>
              <p className="text-sm font-bold text-emerald-300">Temporary Hold Reserved: {activeHold.roomName}</p>
              <p className="text-xs text-slate-400">Space is locked for you while en route to campus.</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xl font-mono font-bold text-emerald-400">{formatTimer(timeLeft)}</span>
            <button
              onClick={() => cancelHold(activeHold.roomId)}
              className="px-3 py-1.5 text-xs bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 rounded-lg transition"
            >
              Release Hold
            </button>
          </div>
        </div>
      )}

      <div className="grid md:grid-cols-3 gap-6">
        {filteredRooms.map((room) => (
          <div key={room.id} className="glass-panel p-5 space-y-4 card-hover-effect relative">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-xs font-semibold text-slate-400">{room.floor}</span>
                <h3 className="font-bold text-lg text-slate-100">{room.name}</h3>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                room.status === 'Available'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : room.status === 'Reserved'
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  : 'bg-red-500/20 text-red-400 border border-red-500/30'
              }`}>
                {room.status}
              </span>
            </div>

            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex justify-between">
                <span>Capacity:</span>
                <span className="font-semibold text-slate-100">{room.occupied} / {room.capacity} seats</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-500 ${
                    (room.occupied / room.capacity) >= 1 ? 'bg-red-500' : 'bg-cyan-400'
                  }`}
                  style={{ width: `${(room.occupied / room.capacity) * 100}%` }}
                />
              </div>

              <div className="flex justify-between items-center pt-2">
                <span className="flex items-center gap-1 text-slate-400">
                  <Volume2 className="w-4 h-4 text-amber-400" /> Noise Level:
                </span>
                <span className="font-semibold text-amber-300">{room.noiseDb} dB ({room.noiseZone})</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 pt-1">
              {room.amenities.map((am, i) => (
                <span key={i} className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300 border border-slate-700">
                  {am}
                </span>
              ))}
            </div>

            {room.status === 'Available' && !activeHold && (
              <button
                onClick={() => holdRoom(room.id, room.name)}
                className="w-full py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold text-xs rounded-xl shadow transition"
              >
                Place 20-Min Hold
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
