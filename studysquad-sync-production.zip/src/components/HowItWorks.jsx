import React from 'react';
import { MapPin, Users, Calendar, Clock, Volume2, ShieldCheck } from 'lucide-react';

export const HowItWorks = ({ onGetStarted }) => {
  return (
    <div className="max-w-6xl mx-auto p-6 space-y-12">
      <div className="text-center space-y-4 py-8">
        <span className="px-4 py-1.5 rounded-full text-xs font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
          Campus Life & Study Group Finder
        </span>
        <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight">
          Find Study Rooms. <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">Build Your Squad.</span>
        </h2>
        <p className="max-w-2xl mx-auto text-slate-400 text-base md:text-lg">
          StudySquad Sync bridges real-time campus room radar with peer study squad matching. Eliminate library room hunting and conquer exams together.
        </p>
        <div className="pt-4 flex justify-center gap-4">
          <button
            onClick={() => onGetStarted('rooms')}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 font-semibold text-white shadow-lg hover:shadow-cyan-500/25 transition transform hover:-translate-y-0.5"
          >
            Explore Room Radar
          </button>
          <button
            onClick={() => onGetStarted('squads')}
            className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold border border-slate-700 transition"
          >
            Join a Study Squad
          </button>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="glass-panel p-6 space-y-4 card-hover-effect">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-bold text-xl border border-cyan-500/20">
            01
          </div>
          <h3 className="text-xl font-bold flex items-center gap-2">
            <MapPin className="w-5 h-5 text-cyan-400" /> Live Room Radar
          </h3>
          <p className="text-sm text-slate-400">
            View real-time room availability across 12 library and campus spots. Filter by noise level (dB), whiteboards, and power sockets.
          </p>
        </div>

        <div className="glass-panel p-6 space-y-4 card-hover-effect">
          <div className="w-12 h-12 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center font-bold text-xl border border-blue-500/20">
            02
          </div>
          <h3 className="text-xl font-bold flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-400" /> 20-Min Space Hold
          </h3>
          <p className="text-sm text-slate-400">
            Place a temporary 20-minute reservation hold on an available room while walking to the library to prevent ghost bookings.
          </p>
        </div>

        <div className="glass-panel p-6 space-y-4 card-hover-effect">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold text-xl border border-emerald-500/20">
            03
          </div>
          <h3 className="text-xl font-bold flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-400" /> Squad Matcher
          </h3>
          <p className="text-sm text-slate-400">
            Create or join study groups based on subject topics and compatible study times. Synchronize focus goals and Pomodoro timers.
          </p>
        </div>
      </div>
    </div>
  );
};
