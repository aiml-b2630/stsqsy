import React, { useState, useContext } from 'react';
import { SquadContext } from '../context/SquadContext';
import { Users, CheckSquare, Clock, Play, Pause, RotateCcw, Award } from 'lucide-react';

export const SquadWorkspace = () => {
  const { squads } = useContext(SquadContext);
  const activeSquad = squads[0] || null;

  const [goals, setGoals] = useState([
    { text: 'Review Mutual Exclusion & Semaphores', done: true },
    { text: 'Solve 2024 Exam Q3', done: false },
    { text: 'Simulate Banker Algorithm in Code', done: false }
  ]);

  const [newGoal, setNewGoal] = useState('');
  const [seconds, setSeconds] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);

  React.useEffect(() => {
    let interval = null;
    if (isActive && seconds > 0) {
      interval = setInterval(() => setSeconds(s => s - 1), 1000);
    } else if (seconds === 0) {
      setIsActive(false);
    }
    return () => clearInterval(interval);
  }, [isActive, seconds]);

  const toggleGoal = (index) => {
    setGoals(prev => prev.map((g, i) => i === index ? { ...g, done: !g.done } : g));
  };

  const addGoal = (e) => {
    e.preventDefault();
    if (!newGoal.trim()) return;
    setGoals(prev => [...prev, { text: newGoal, done: false }]);
    setNewGoal('');
  };

  const formatPomodoro = (sec) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="glass-panel p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
            Active Workspace
          </span>
          <h2 className="text-3xl font-extrabold mt-2 text-slate-100">{activeSquad?.name || 'OS Finals Sprint Squad'}</h2>
          <p className="text-sm text-slate-400">Subject: {activeSquad?.subject} | Location: {activeSquad?.location}</p>
        </div>

        <div className="flex items-center gap-3 bg-slate-800/80 px-4 py-2 rounded-xl border border-slate-700">
          <Award className="w-5 h-5 text-amber-400" />
          <span className="text-xs font-bold text-amber-300">Study Streak: 5 Days</span>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Roster */}
        <div className="glass-panel p-6 space-y-4">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <Users className="w-5 h-5 text-cyan-400" /> Member Roster
          </h3>
          <div className="space-y-3">
            {activeSquad?.members.map((member, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <span className="text-sm font-semibold">{member}</span>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" title="Online & Focused" />
              </div>
            ))}
          </div>
        </div>

        {/* Goals */}
        <div className="glass-panel p-6 space-y-4">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-emerald-400" /> Focus Goals
          </h3>
          <form onSubmit={addGoal} className="flex gap-2">
            <input
              type="text"
              placeholder="Add goal..."
              value={newGoal}
              onChange={e => setNewGoal(e.target.value)}
              className="flex-1 bg-slate-800 border border-slate-700 text-xs px-3 py-2 rounded-lg text-white outline-none"
            />
            <button type="submit" className="px-3 py-2 bg-cyan-500 text-white font-semibold text-xs rounded-lg">Add</button>
          </form>
          <div className="space-y-2">
            {goals.map((goal, idx) => (
              <div
                key={idx}
                onClick={() => toggleGoal(idx)}
                className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/30 cursor-pointer hover:bg-slate-800/60 transition"
              >
                <input type="checkbox" checked={goal.done} readOnly className="rounded accent-cyan-500" />
                <span className={`text-xs ${goal.done ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                  {goal.text}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Pomodoro Squad Timer */}
        <div className="glass-panel p-6 space-y-4 text-center">
          <h3 className="font-bold text-lg flex items-center justify-center gap-2">
            <Clock className="w-5 h-5 text-amber-400" /> Pomodoro Squad Timer
          </h3>
          <div className="text-4xl font-mono font-extrabold text-cyan-400 py-4">
            {formatPomodoro(seconds)}
          </div>
          <div className="flex justify-center gap-3">
            <button
              onClick={() => setIsActive(!isActive)}
              className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-white font-semibold text-xs rounded-lg flex items-center gap-1"
            >
              {isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {isActive ? 'Pause' : 'Start Focus'}
            </button>
            <button
              onClick={() => { setIsActive(false); setSeconds(25 * 60); }}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs rounded-lg flex items-center gap-1 border border-slate-700"
            >
              <RotateCcw className="w-4 h-4" /> Reset
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
