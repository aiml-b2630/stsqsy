import React, { useContext } from 'react';
import { SquadContext } from '../context/SquadContext';
import { Shield, Moon, Sun, Users, MapPin, Clock } from 'lucide-react';

export const Navbar = ({ activeTab, setActiveTab }) => {
  const { theme, toggleTheme, activeHold } = useContext(SquadContext);

  return (
    <nav className="glass-panel sticky top-4 z-50 mx-4 my-2 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
      <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('how-it-works')}>
        <div className="p-2 bg-gradient-to-tr from-cyan-500 to-blue-600 rounded-xl text-white shadow-lg">
          <Users className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">
            StudySquad Sync
          </h1>
          <p className="text-xs text-slate-400">Campus Study Finder & Room Radar</p>
        </div>
      </div>

      <div className="flex items-center gap-2 bg-slate-800/40 p-1.5 rounded-xl border border-slate-700/50">
        <button
          onClick={() => setActiveTab('how-it-works')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition ${activeTab === 'how-it-works' ? 'bg-cyan-500 text-white shadow' : 'text-slate-400 hover:text-white'}`}
        >
          How It Works
        </button>
        <button
          onClick={() => setActiveTab('rooms')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition ${activeTab === 'rooms' ? 'bg-cyan-500 text-white shadow' : 'text-slate-400 hover:text-white'}`}
        >
          Room Radar
        </button>
        <button
          onClick={() => setActiveTab('squads')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition ${activeTab === 'squads' ? 'bg-cyan-500 text-white shadow' : 'text-slate-400 hover:text-white'}`}
        >
          Study Squads
        </button>
        <button
          onClick={() => setActiveTab('workspace')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition ${activeTab === 'workspace' ? 'bg-cyan-500 text-white shadow' : 'text-slate-400 hover:text-white'}`}
        >
          Squad Workspace
        </button>
      </div>

      <div className="flex items-center gap-3">
        {activeHold && (
          <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 px-3 py-1.5 rounded-lg text-xs font-semibold animate-pulse">
            <Clock className="w-4 h-4" />
            Hold Active ({activeHold.roomName})
          </div>
        )}
        <button
          onClick={toggleTheme}
          className="p-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-700 text-amber-400 border border-slate-700 transition"
          title="Toggle Dark/Light Mode"
        >
          {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-700" />}
        </button>
      </div>
    </nav>
  );
};
