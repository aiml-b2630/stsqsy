export const initialRooms = [
  { id: 'room-101', name: 'Central Library Pod 1', floor: '3rd Floor', capacity: 4, occupied: 2, status: 'Available', noiseDb: 35, noiseZone: 'Silent Zone', amenities: ['Whiteboard', 'Power Sockets', 'Silent Zone'] },
  { id: 'room-102', name: 'Central Library Pod 2', floor: '3rd Floor', capacity: 4, occupied: 4, status: 'Occupied', noiseDb: 40, noiseZone: 'Quiet Zone', amenities: ['Power Sockets', 'Dual Monitors'] },
  { id: 'room-103', name: 'Eng Block Room A', floor: '2nd Floor', capacity: 6, occupied: 1, status: 'Available', noiseDb: 58, noiseZone: 'Discussion', amenities: ['Whiteboard', 'Power Sockets', 'Group Friendly'] },
  { id: 'room-104', name: 'Eng Block Room B', floor: '2nd Floor', capacity: 8, occupied: 8, status: 'Occupied', noiseDb: 65, noiseZone: 'Active Discussion', amenities: ['Whiteboard', 'Dual Monitors', 'Group Friendly'] },
  { id: 'room-105', name: 'Student Center Hub 1', floor: '1st Floor', capacity: 5, occupied: 0, status: 'Available', noiseDb: 45, noiseZone: 'Moderate', amenities: ['Whiteboard', 'Power Sockets'] },
  { id: 'room-106', name: 'Silent Reading Hall Desk 12', floor: '4th Floor', capacity: 1, occupied: 0, status: 'Available', noiseDb: 30, noiseZone: 'Silent Zone', amenities: ['Power Sockets', 'Silent Zone'] },
  { id: 'room-107', name: 'Math & Physics Suite', floor: '3rd Floor', capacity: 6, occupied: 3, status: 'Available', noiseDb: 50, noiseZone: 'Moderate', amenities: ['Whiteboard', 'Power Sockets'] },
  { id: 'room-108', name: 'CS Tech Lab Booth 4', floor: '1st Floor', capacity: 4, occupied: 4, status: 'Occupied', noiseDb: 60, noiseZone: 'Discussion', amenities: ['Dual Monitors', 'Power Sockets'] },
  { id: 'room-109', name: 'Graduate Study Room 3', floor: '5th Floor', capacity: 4, occupied: 1, status: 'Available', noiseDb: 32, noiseZone: 'Silent Zone', amenities: ['Whiteboard', 'Silent Zone'] },
  { id: 'room-110', name: 'Bio-Chem Study Lounge', floor: '2nd Floor', capacity: 10, occupied: 6, status: 'Available', noiseDb: 55, noiseZone: 'Discussion', amenities: ['Whiteboard', 'Group Friendly'] },
  { id: 'room-111', name: 'Humanities Quiet Nook', floor: '4th Floor', capacity: 2, occupied: 2, status: 'Occupied', noiseDb: 35, noiseZone: 'Silent Zone', amenities: ['Power Sockets', 'Silent Zone'] },
  { id: 'room-112', name: 'Innovation Hub Collab Zone', floor: 'Ground Floor', capacity: 12, occupied: 5, status: 'Available', noiseDb: 68, noiseZone: 'Active Discussion', amenities: ['Whiteboard', 'Dual Monitors', 'Group Friendly'] }
];

export const initialSquads = [
  {
    id: 'squad-1',
    name: 'OS Finals Sprint Squad',
    subject: 'Operating Systems',
    topic: 'Concurrency & Memory Management',
    maxSize: 4,
    members: ['Alex Chen (Host)', 'Sarah Jenkins'],
    timeSlot: 'Late Night (8 PM - 11 PM)',
    location: 'Central Library Pod 1',
    roomId: 'room-101',
    goals: ['Review Mutual Exclusion & Semaphores', 'Solve 2024 Past Paper Q3', 'Implement Banker Algorithm Simulation']
  },
  {
    id: 'squad-2',
    name: 'Linear Algebra Prep Group',
    subject: 'Mathematics',
    topic: 'Eigenvalues & Vector Spaces',
    maxSize: 5,
    members: ['Marcus Vance (Host)', 'Priya Sharma', 'David Kim'],
    timeSlot: 'Afternoon (2 PM - 5 PM)',
    location: 'Eng Block Room A',
    roomId: 'room-103',
    goals: ['Diagonalization Proofs', 'Gram-Schmidt Process Practice']
  },
  {
    id: 'squad-3',
    name: 'Data Structures & Algo Study',
    subject: 'Computer Science',
    topic: 'Dynamic Programming & Graph Algorithms',
    maxSize: 4,
    members: ['Elena Rostova (Host)', 'Liam O Connor', 'Maya Lin'],
    timeSlot: 'Morning (9 AM - 12 PM)',
    location: 'Math & Physics Suite',
    roomId: 'room-107',
    goals: ['Dijkstra vs A* Algorithm', 'DP Knapsack Problem Variations']
  }
];
