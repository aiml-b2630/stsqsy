import React, { useState } from 'react';
import { SquadProvider } from './context/SquadContext';
import { Navbar } from './components/Navbar';
import { HowItWorks } from './components/HowItWorks';
import { RoomVisualizer } from './components/RoomVisualizer';
import { SquadWorkspace } from './components/SquadWorkspace';
import './styles/custom.css';

export const App = () => {
  const [activeTab, setActiveTab] = useState('how-it-works');

  return (
    <SquadProvider>
      <div className="min-h-screen flex flex-col">
        <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
        <main className="flex-1 pb-12">
          {activeTab === 'how-it-works' && <HowItWorks onGetStarted={setActiveTab} />}
          {activeTab === 'rooms' && <RoomVisualizer />}
          {activeTab === 'squads' && <RoomVisualizer />}
          {activeTab === 'workspace' && <SquadWorkspace />}
        </main>
      </div>
    </SquadProvider>
  );
};

export default App;
