import React, { createContext, useState, useEffect } from 'react';
import { initialRooms, initialSquads } from '../data/mockData';

export const SquadContext = createContext();

export const SquadProvider = ({ children }) => {
  const [rooms, setRooms] = useState(() => {
    const saved = localStorage.getItem('studysquad_rooms');
    return saved ? JSON.parse(saved) : initialRooms;
  });

  const [squads, setSquads] = useState(() => {
    const saved = localStorage.getItem('studysquad_squads');
    return saved ? JSON.parse(saved) : initialSquads;
  });

  const [activeHold, setActiveHold] = useState(() => {
    const saved = localStorage.getItem('studysquad_hold');
    return saved ? JSON.parse(saved) : null;
  });

  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('studysquad_theme') || 'dark';
  });

  useEffect(() => {
    localStorage.setItem('studysquad_rooms', JSON.stringify(rooms));
  }, [rooms]);

  useEffect(() => {
    localStorage.setItem('studysquad_squads', JSON.stringify(squads));
  }, [squads]);

  useEffect(() => {
    if (activeHold) {
      localStorage.setItem('studysquad_hold', JSON.stringify(activeHold));
    } else {
      localStorage.removeItem('studysquad_hold');
    }
  }, [activeHold]);

  useEffect(() => {
    localStorage.setItem('studysquad_theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const holdRoom = (roomId, roomName) => {
    const expiry = Date.now() + 20 * 60 * 1000; // 20 minutes countdown
    const holdData = { roomId, roomName, expiry };
    setActiveHold(holdData);

    setRooms(prevRooms =>
      prevRooms.map(r => r.id === roomId ? { ...r, status: 'Reserved' } : r)
    );
  };

  const cancelHold = (roomId) => {
    setActiveHold(null);
    setRooms(prevRooms =>
      prevRooms.map(r => r.id === roomId ? { ...r, status: 'Available' } : r)
    );
  };

  const createSquad = (newSquad) => {
    const squadObj = {
      ...newSquad,
      id: `squad-${Date.now()}`,
      members: [newSquad.creatorName || 'You (Host)'],
      goals: newSquad.goals || ['Initial Study Goal']
    };
    setSquads(prev => [squadObj, ...prev]);
  };

  const joinSquad = (squadId, memberName = 'You') => {
    setSquads(prev =>
      prev.map(s => {
        if (s.id === squadId && s.members.length < s.maxSize) {
          return { ...s, members: [...s.members, memberName] };
        }
        return s;
      })
    );
  };

  return (
    <SquadContext.Provider value={{
      rooms,
      squads,
      activeHold,
      theme,
      toggleTheme,
      holdRoom,
      cancelHold,
      createSquad,
      joinSquad
    }}>
      {children}
    </SquadContext.Provider>
  );
};
