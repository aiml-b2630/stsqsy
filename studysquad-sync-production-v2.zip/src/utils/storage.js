// Client-side LocalStorage management with safe fallback
const ROOMS_KEY = "studysquad_rooms_v2";
const SQUADS_KEY = "studysquad_squads_v2";
const ACTIVE_HOLD_KEY = "studysquad_active_hold_v2";

export const loadRoomsFromStorage = (fallback) => {
  try {
    const data = localStorage.getItem(ROOMS_KEY);
    return data ? JSON.parse(data) : fallback;
  } catch (err) {
    console.error("Failed to load rooms from storage:", err);
    return fallback;
  }
};

export const saveRoomsToStorage = (rooms) => {
  try {
    localStorage.setItem(ROOMS_KEY, JSON.stringify(rooms));
  } catch (err) {
    console.error("Failed to save rooms to storage:", err);
  }
};

export const loadSquadsFromStorage = (fallback) => {
  try {
    const data = localStorage.getItem(SQUADS_KEY);
    return data ? JSON.parse(data) : fallback;
  } catch (err) {
    console.error("Failed to load squads from storage:", err);
    return fallback;
  }
};

export const saveSquadsToStorage = (squads) => {
  try {
    localStorage.setItem(SQUADS_KEY, JSON.stringify(squads));
  } catch (err) {
    console.error("Failed to save squads to storage:", err);
  }
};

export const loadActiveHold = () => {
  try {
    const data = localStorage.getItem(ACTIVE_HOLD_KEY);
    return data ? JSON.parse(data) : null;
  } catch (err) {
    return null;
  }
};

export const saveActiveHold = (holdObj) => {
  try {
    if (!holdObj) {
      localStorage.removeItem(ACTIVE_HOLD_KEY);
    } else {
      localStorage.setItem(ACTIVE_HOLD_KEY, JSON.stringify(holdObj));
    }
  } catch (err) {
    console.error("Failed to save active hold:", err);
  }
};
