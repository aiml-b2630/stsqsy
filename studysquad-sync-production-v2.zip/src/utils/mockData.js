// Initial dataset of 12 campus study spaces & 6 active study squads
export const INITIAL_ROOMS = [
  {
    id: "rm-101",
    name: "Engineering Pod #3",
    building: "Engineering Block B",
    floor: "1st Floor",
    capacity: 6,
    occupiedChairs: 2,
    status: "Available", // Available, Reserved, Occupied
    noiseDb: 38,
    noiseCategory: "Whisper Quiet",
    amenities: ["Whiteboard", "Power Sockets", "Dual Monitors"],
    holdExpiresAt: null,
    reservedBy: null
  },
  {
    id: "rm-102",
    name: "Central Library Silent Pod A",
    building: "Central Library",
    floor: "3rd Floor",
    capacity: 4,
    occupiedChairs: 4,
    status: "Occupied",
    noiseDb: 32,
    noiseCategory: "Silent Zone",
    amenities: ["Silent Zone", "Power Sockets"],
    holdExpiresAt: null,
    reservedBy: null
  },
  {
    id: "rm-103",
    name: "Discussion Hall #12",
    building: "Student Center",
    floor: "Ground Floor",
    capacity: 8,
    occupiedChairs: 5,
    status: "Available",
    noiseDb: 64,
    noiseCategory: "Group Discussion Friendly",
    amenities: ["Whiteboard", "Group Discussion Friendly", "Power Sockets"],
    holdExpiresAt: null,
    reservedBy: null
  },
  {
    id: "rm-104",
    name: "CS Innovation Lab Room 4",
    building: "Technology Wing",
    floor: "2nd Floor",
    capacity: 6,
    occupiedChairs: 0,
    status: "Available",
    noiseDb: 42,
    noiseCategory: "Whisper Quiet",
    amenities: ["Dual Monitors", "Whiteboard", "Power Sockets"],
    holdExpiresAt: null,
    reservedBy: null
  },
  {
    id: "rm-105",
    name: "Math & Stats Alcove #2",
    building: "Central Library",
    floor: "2nd Floor",
    capacity: 4,
    occupiedChairs: 2,
    status: "Available",
    noiseDb: 35,
    noiseCategory: "Whisper Quiet",
    amenities: ["Whiteboard", "Power Sockets"],
    holdExpiresAt: null,
    reservedBy: null
  },
  {
    id: "rm-106",
    name: "Physics Quantum Study Room",
    building: "Science Complex",
    floor: "4th Floor",
    capacity: 10,
    occupiedChairs: 10,
    status: "Occupied",
    noiseDb: 58,
    noiseCategory: "Group Discussion Friendly",
    amenities: ["Whiteboard", "Dual Monitors", "Power Sockets"],
    holdExpiresAt: null,
    reservedBy: null
  },
  {
    id: "rm-107",
    name: "Law & Ethics Seminar Pod",
    building: "Humanities Hall",
    floor: "1st Floor",
    capacity: 5,
    occupiedChairs: 1,
    status: "Available",
    noiseDb: 30,
    noiseCategory: "Silent Zone",
    amenities: ["Silent Zone", "Power Sockets"],
    holdExpiresAt: null,
    reservedBy: null
  },
  {
    id: "rm-108",
    name: "Bio-Med Research Hub #1",
    building: "Science Complex",
    floor: "3rd Floor",
    capacity: 6,
    occupiedChairs: 3,
    status: "Available",
    noiseDb: 45,
    noiseCategory: "Whisper Quiet",
    amenities: ["Whiteboard", "Dual Monitors", "Power Sockets"],
    holdExpiresAt: null,
    reservedBy: null
  },
  {
    id: "rm-109",
    name: "Central Library Media Room 2",
    building: "Central Library",
    floor: "1st Floor",
    capacity: 4,
    occupiedChairs: 0,
    status: "Available",
    noiseDb: 50,
    noiseCategory: "Group Discussion Friendly",
    amenities: ["Dual Monitors", "Group Discussion Friendly"],
    holdExpiresAt: null,
    reservedBy: null
  },
  {
    id: "rm-110",
    name: "AI & Data Science Lab Pod B",
    building: "Technology Wing",
    floor: "3rd Floor",
    capacity: 8,
    occupiedChairs: 6,
    status: "Available",
    noiseDb: 40,
    noiseCategory: "Whisper Quiet",
    amenities: ["Dual Monitors", "Whiteboard", "Power Sockets"],
    holdExpiresAt: null,
    reservedBy: null
  },
  {
    id: "rm-111",
    name: "Undergrad Honors Lounge",
    building: "Student Center",
    floor: "2nd Floor",
    capacity: 12,
    occupiedChairs: 12,
    status: "Occupied",
    noiseDb: 68,
    noiseCategory: "Group Discussion Friendly",
    amenities: ["Group Discussion Friendly", "Whiteboard", "Power Sockets"],
    holdExpiresAt: null,
    reservedBy: null
  },
  {
    id: "rm-112",
    name: "Postgrad Research Cubicle #7",
    building: "Central Library",
    floor: "4th Floor",
    capacity: 2,
    occupiedChairs: 0,
    status: "Available",
    noiseDb: 28,
    noiseCategory: "Silent Zone",
    amenities: ["Silent Zone", "Power Sockets"],
    holdExpiresAt: null,
    reservedBy: null
  }
];

export const INITIAL_SQUADS = [
  {
    id: "sq-201",
    title: "Operating Systems Finals Grind",
    subject: "Computer Science",
    topic: "Process Synchronization & Memory Management",
    creator: "Alex Rivers",
    creatorId: "user-101",
    maxMembers: 4,
    members: [
      { id: "user-101", name: "Alex Rivers", role: "Leader", avatar: "👨‍💻" },
      { id: "user-102", name: "Priya Sharma", role: "Member", avatar: "👩‍🔬" },
      { id: "user-103", name: "Marcus Chen", role: "Member", avatar: "👨‍🎓" }
    ],
    scheduleSlot: "Afternoon", // Morning, Afternoon, Late Night
    meetingTime: "14:00 - 16:30",
    assignedRoomId: "rm-101",
    assignedRoomName: "Engineering Pod #3",
    streakDays: 4,
    goals: [
      { id: "g1", text: "Solve Dining Philosophers problem", completed: true },
      { id: "g2", text: "Review Page Replacement Algorithms", completed: false },
      { id: "g3", text: "Complete 2 Pomodoro focus blocks", completed: true }
    ]
  },
  {
    id: "sq-202",
    title: "Linear Algebra Exam Prep",
    subject: "Mathematics",
    topic: "Eigenvalues, Eigenvectors & SVD",
    creator: "Sarah Jenkins",
    creatorId: "user-104",
    maxMembers: 5,
    members: [
      { id: "user-104", name: "Sarah Jenkins", role: "Leader", avatar: "👩‍🏫" },
      { id: "user-105", name: "David Kim", role: "Member", avatar: "👨‍💻" }
    ],
    scheduleSlot: "Morning",
    meetingTime: "09:30 - 11:30",
    assignedRoomId: "rm-105",
    assignedRoomName: "Math & Stats Alcove #2",
    streakDays: 7,
    goals: [
      { id: "g4", text: "Derive Diagonalization formulas", completed: true },
      { id: "g5", text: "Practice past exam paper 2023", completed: false }
    ]
  },
  {
    id: "sq-203",
    title: "Organic Chemistry Synthesis Group",
    subject: "Chemistry",
    topic: "Retrosynthetic Analysis & Reaction Mechanisms",
    creator: "Elena Rostova",
    creatorId: "user-106",
    maxMembers: 4,
    members: [
      { id: "user-106", name: "Elena Rostova", role: "Leader", avatar: "👩‍⚕️" }
    ],
    scheduleSlot: "Late Night",
    meetingTime: "20:00 - 22:30",
    assignedRoomId: "rm-108",
    assignedRoomName: "Bio-Med Research Hub #1",
    streakDays: 2,
    goals: [
      { id: "g6", text: "Map out 15 synthesis pathways", completed: false }
    ]
  }
];
