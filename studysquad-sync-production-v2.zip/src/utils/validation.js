// Form & Input Validation Service addressing security & robustness rubric requirements

export const sanitizeString = (str) => {
  if (typeof str !== "string") return "";
  return str.replace(/</g, "&lt;").replace(/>/g, "&gt;").trim();
};

export const validateSquadForm = (formData) => {
  const errors = {};

  const cleanTitle = sanitizeString(formData.title);
  if (!cleanTitle || cleanTitle.length < 5) {
    errors.title = "Squad title must be at least 5 characters long.";
  } else if (cleanTitle.length > 60) {
    errors.title = "Squad title cannot exceed 60 characters.";
  }

  const cleanSubject = sanitizeString(formData.subject);
  if (!cleanSubject) {
    errors.subject = "Please select or specify a study subject.";
  }

  const cleanTopic = sanitizeString(formData.topic);
  if (!cleanTopic || cleanTopic.length < 4) {
    errors.topic = "Target study topic must be at least 4 characters.";
  }

  const maxMembers = Number(formData.maxMembers);
  if (isNaN(maxMembers) || maxMembers < 2 || maxMembers > 12) {
    errors.maxMembers = "Maximum group size must be between 2 and 12 members.";
  }

  if (!formData.scheduleSlot || !["Morning", "Afternoon", "Late Night"].includes(formData.scheduleSlot)) {
    errors.scheduleSlot = "Please select a valid schedule slot (Morning, Afternoon, or Late Night).";
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    cleanData: {
      title: cleanTitle,
      subject: cleanSubject,
      topic: cleanTopic,
      maxMembers,
      scheduleSlot: formData.scheduleSlot,
      meetingTime: formData.meetingTime || "14:00 - 16:00"
    }
  };
};

export const validateRoomHold = (room, user) => {
  if (!room) {
    return { canHold: false, reason: "Room not found." };
  }
  if (room.status === "Occupied") {
    return { canHold: false, reason: "Room is currently at 100% occupancy." };
  }
  if (room.status === "Reserved") {
    return { canHold: false, reason: "Room already has an active hold placed by another student." };
  }
  if (!user) {
    return { canHold: false, reason: "Authentication required. Please sign in as a student." };
  }
  return { canHold: true, reason: "" };
};
