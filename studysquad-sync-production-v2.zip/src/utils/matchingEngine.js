// Heuristic matching algorithm pairing students by subject relevance, topic similarity & schedule compatibility

export const calculateMatchScore = (squad, userPreferences) => {
  let score = 0;
  const maxScore = 100;

  // 1. Subject match (40 points)
  if (userPreferences.subject && squad.subject.toLowerCase() === userPreferences.subject.toLowerCase()) {
    score += 40;
  } else if (userPreferences.subject && squad.subject.toLowerCase().includes(userPreferences.subject.toLowerCase())) {
    score += 25;
  }

  // 2. Schedule slot match (35 points)
  if (userPreferences.scheduleSlot && squad.scheduleSlot === userPreferences.scheduleSlot) {
    score += 35;
  }

  // 3. Room amenity preference match (15 points)
  if (userPreferences.preferredAmenity) {
    if (squad.assignedRoomAmenities && squad.assignedRoomAmenities.includes(userPreferences.preferredAmenity)) {
      score += 15;
    }
  } else {
    score += 10;
  }

  // 4. Group availability headroom (10 points)
  if (squad.members.length < squad.maxMembers) {
    score += 10;
  }

  return Math.min(score, maxScore);
};

export const findBestMatchingSquads = (squads, userPreferences) => {
  return squads.map(squad => {
    const matchPercentage = calculateMatchScore(squad, userPreferences);
    return {
      ...squad,
      matchPercentage
    };
  }).sort((a, b) => b.matchPercentage - a.matchPercentage);
};
