import { useState, useEffect } from 'react';

export const useHoldTimer = (expiresAt, onExpire) => {
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(0);

  useEffect(() => {
    if (!expiresAt) {
      setTimeLeftSeconds(0);
      return;
    }

    const updateTimer = () => {
      const now = Date.now();
      const diff = Math.max(0, Math.floor((expiresAt - now) / 1000));
      setTimeLeftSeconds(diff);

      if (diff <= 0) {
        if (onExpire) onExpire();
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, [expiresAt, onExpire]);

  const minutes = Math.floor(timeLeftSeconds / 60);
  const seconds = timeLeftSeconds % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  const percentage = Math.max(0, Math.min(100, (timeLeftSeconds / (20 * 60)) * 100));

  return {
    timeLeftSeconds,
    minutes,
    seconds,
    formattedTime,
    percentage,
    isExpired: timeLeftSeconds <= 0 && Boolean(expiresAt)
  };
};
