import { useState, useMemo } from 'react';

export const useRoomFilter = (rooms) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBuilding, setSelectedBuilding] = useState("All");
  const [selectedAmenities, setSelectedAmenities] = useState([]);
  const [maxNoiseDb, setMaxNoiseDb] = useState(70);
  const [statusFilter, setStatusFilter] = useState("All");
  const [sortBy, setSortBy] = useState("name"); // name, noiseDb, availableSeats
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  const toggleAmenity = (amenity) => {
    setSelectedAmenities(prev =>
      prev.includes(amenity) ? prev.filter(a => a !== amenity) : [...prev, amenity]
    );
    setCurrentPage(1);
  };

  const filteredRooms = useMemo(() => {
    return rooms.filter(room => {
      // Search
      const matchesSearch = room.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            room.building.toLowerCase().includes(searchTerm.toLowerCase());
      if (!matchesSearch) return false;

      // Building
      if (selectedBuilding !== "All" && room.building !== selectedBuilding) return false;

      // Status
      if (statusFilter !== "All" && room.status !== statusFilter) return false;

      // Noise level
      if (room.noiseDb > maxNoiseDb) return false;

      // Amenities
      if (selectedAmenities.length > 0) {
        const hasAllAmenities = selectedAmenities.every(a => room.amenities.includes(a));
        if (!hasAllAmenities) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === "noiseDb") return a.noiseDb - b.noiseDb;
      if (sortBy === "availableSeats") {
        const availA = a.capacity - a.occupiedChairs;
        const availB = b.capacity - b.occupiedChairs;
        return availB - availA;
      }
      return a.name.localeCompare(b.name);
    });
  }, [rooms, searchTerm, selectedBuilding, selectedAmenities, maxNoiseDb, statusFilter, sortBy]);

  // Pagination calculation
  const totalPages = Math.ceil(filteredRooms.length / itemsPerPage) || 1;
  const paginatedRooms = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredRooms.slice(start, start + itemsPerPage);
  }, [filteredRooms, currentPage]);

  return {
    searchTerm,
    setSearchTerm,
    selectedBuilding,
    setSelectedBuilding,
    selectedAmenities,
    toggleAmenity,
    maxNoiseDb,
    setMaxNoiseDb,
    statusFilter,
    setStatusFilter,
    sortBy,
    setSortBy,
    currentPage,
    setCurrentPage,
    totalPages,
    paginatedRooms,
    totalCount: filteredRooms.length
  };
};
