import { useState, useMemo } from 'react';
import { findBestMatchingSquads } from '../utils/matchingEngine';

export const useSquadMatcher = (squads) => {
  const [filterSubject, setFilterSubject] = useState("");
  const [filterScheduleSlot, setFilterScheduleSlot] = useState("All");
  const [filterAmenity, setFilterAmenity] = useState("");

  const matchedSquads = useMemo(() => {
    const prefs = {
      subject: filterSubject,
      scheduleSlot: filterScheduleSlot === "All" ? "" : filterScheduleSlot,
      preferredAmenity: filterAmenity
    };
    return findBestMatchingSquads(squads, prefs);
  }, [squads, filterSubject, filterScheduleSlot, filterAmenity]);

  return {
    filterSubject,
    setFilterSubject,
    filterScheduleSlot,
    setFilterScheduleSlot,
    filterAmenity,
    setFilterAmenity,
    matchedSquads
  };
};
