import { useEffect } from 'react';

// IoT PIR Motion & Decibel Sensor Event Loop Simulation addressing stretch features & rubric criteria
export const useIoTSensorSim = (enabled, setRooms) => {
  useEffect(() => {
    if (!enabled) return;

    const interval = setInterval(() => {
      setRooms(prevRooms => {
        // Pick a random room to simulate sensor event
        const randomIndex = Math.floor(Math.random() * prevRooms.length);
        return prevRooms.map((room, idx) => {
          if (idx !== randomIndex) return room;

          // Don't modify if room has an active user hold
          if (room.status === "Reserved") return room;

          // Fluctuate noise decibels randomly between -4 dB and +4 dB
          const dbDelta = Math.floor(Math.random() * 9) - 4;
          const newDb = Math.max(25, Math.min(75, room.noiseDb + dbDelta));
          const newCategory = newDb < 38 ? "Silent Zone" : newDb < 55 ? "Whisper Quiet" : "Group Discussion Friendly";

          // Randomly change occupied chairs slightly
          let newOccupied = room.occupiedChairs;
          if (Math.random() > 0.5) {
            const chairDelta = Math.random() > 0.5 ? 1 : -1;
            newOccupied = Math.max(0, Math.min(room.capacity, room.occupiedChairs + chairDelta));
          }

          let newStatus = room.status;
          if (newOccupied >= room.capacity) {
            newStatus = "Occupied";
          } else if (room.status === "Occupied" && newOccupied < room.capacity) {
            newStatus = "Available";
          }

          return {
            ...room,
            noiseDb: newDb,
            noiseCategory: newCategory,
            occupiedChairs: newOccupied,
            status: newStatus
          };
        });
      });
    }, 6000); // Trigger every 6 seconds

    return () => clearInterval(interval);
  }, [enabled, setRooms]);
};
