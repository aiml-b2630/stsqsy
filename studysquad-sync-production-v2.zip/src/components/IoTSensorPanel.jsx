import React from 'react';
import { useSquad } from '../context/SquadContext';
import { Activity, Radio, Volume2, ShieldCheck } from 'lucide-react';

export const IoTSensorPanel = () => {
  const { iotSimEnabled, setIotSimEnabled } = useSquad();

  return (
    <div className="glass-panel p-5 border-emerald-500/30 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
          <h4 className="text-xs font-bold text-slate-200">IoT Physical Sensor Telemetry Loop</h4>
        </div>
        <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${
          iotSimEnabled ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-slate-800 text-slate-400"
        }`}>
          {iotSimEnabled ? "Simulating Live Events" : "Paused"}
        </span>
      </div>

      <p className="text-[11px] text-slate-400 leading-relaxed">
        Simulates hardware IoT ceiling PIR motion sensors and digital sound decibel meters without physical hardware setup. Updates room occupancy states dynamically every 6 seconds.
      </p>

      <button
        onClick={() => setIotSimEnabled(!iotSimEnabled)}
        className="w-full py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 font-semibold rounded-xl text-xs transition"
      >
        {iotSimEnabled ? "Pause Sensor Event Loop" : "Resume Sensor Telemetry"}
      </button>
    </div>
  );
};
