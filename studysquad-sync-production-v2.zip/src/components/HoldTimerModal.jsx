import React from 'react';
import { useSquad } from '../context/SquadContext';
import { useHoldTimer } from '../hooks/useHoldTimer';
import { Clock, X, CheckCircle2, AlertTriangle, MapPin } from 'lucide-react';

export const HoldTimerModal = ({ isOpen, onClose, selectedRoom }) => {
  const { activeHold, placeHold, cancelHold, confirmArrival } = useSquad();
  const targetRoom = selectedRoom || (activeHold ? { id: activeHold.roomId, name: activeHold.roomName } : null);

  const { formattedTime, percentage, isExpired } = useHoldTimer(
    activeHold?.expiresAt,
    () => {
      if (activeHold) cancelHold(activeHold.roomId);
    }
  );

  if (!isOpen || !targetRoom) return null;

  const handleStartHold = () => {
    placeHold(targetRoom.id, "user-101");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="glass-panel max-w-md w-full p-6 relative shadow-2xl border-indigo-500/30">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white">
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-12 h-12 bg-amber-500/20 text-amber-400 rounded-full flex items-center justify-center mx-auto mb-3">
            <Clock className="w-6 h-6 animate-pulse" />
          </div>
          <h2 className="text-lg font-bold text-slate-100">20-Minute Space Hold</h2>
          <p className="text-xs text-slate-400 mt-1 flex items-center justify-center space-x-1">
            <MapPin className="w-3.5 h-3.5 text-indigo-400" />
            <span>{targetRoom.name}</span>
          </p>
        </div>

        {activeHold && activeHold.roomId === targetRoom.id ? (
          <div className="space-y-6">
            {/* Live Countdown Clock */}
            <div className="text-center py-6 bg-slate-900/90 rounded-2xl border border-slate-800">
              <span className="text-4xl font-extrabold font-mono text-amber-400 tracking-wider">
                {formattedTime}
              </span>
              <p className="text-xs text-slate-400 mt-2">Time remaining to arrive at facility</p>
              
              {/* Progress Bar */}
              <div className="w-3/4 mx-auto bg-slate-800 h-2 rounded-full mt-4 overflow-hidden">
                <div
                  className="bg-amber-400 h-full transition-all duration-1000"
                  style={{ width: `${percentage}%` }}
                ></div>
              </div>
            </div>

            <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/50 text-xs text-slate-300 space-y-1">
              <p className="font-semibold text-amber-300">⚠️ Anti-Ghost Booking Protocol:</p>
              <p className="text-slate-400">If unconfirmed before countdown hits zero, this reservation will automatically expire and release back to public availability.</p>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => {
                  cancelHold(targetRoom.id);
                  onClose();
                }}
                className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-xs transition"
              >
                Cancel Hold
              </button>
              <button
                onClick={() => {
                  confirmArrival(targetRoom.id);
                  onClose();
                }}
                className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-emerald-600/20 transition flex items-center justify-center space-x-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirm Arrival</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-5">
            <p className="text-xs text-slate-300 leading-relaxed text-center">
              Placing a hold locks this room for <strong>20 minutes</strong> while you walk over across campus.
            </p>
            <button
              onClick={handleStartHold}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-indigo-600/30 transition"
            >
              Confirm & Start 20m Hold Countdown
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
