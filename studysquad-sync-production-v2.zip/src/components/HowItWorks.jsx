import React from 'react';
import { CheckCircle2, MapPin, Users, Clock, ShieldCheck, Cpu } from 'lucide-react';

export const HowItWorks = () => {
  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="glass-panel p-8 text-center space-y-3">
        <h1 className="text-2xl font-extrabold text-slate-100">StudySquad Sync Architecture</h1>
        <p className="text-xs text-slate-400 max-w-2xl mx-auto">
          Built to solve the campus space hunting struggle and pair students into high-focus peer squads.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="glass-panel p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
            01
          </div>
          <h3 className="text-sm font-bold text-slate-200">RoomRadar Occupancy Telemetry</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Displays real-time occupancy across 12 library and engineering facility pods. Includes sound decibel (dB) meters and amenity filtering.
          </p>
        </div>

        <div className="glass-panel p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
            02
          </div>
          <h3 className="text-sm font-bold text-slate-200">20-Minute Temporary Hold Timer</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Prevents ghost bookings by reserving study desks for 20 minutes while students are en route across campus. Automatically expires if unconfirmed.
          </p>
        </div>

        <div className="glass-panel p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
            03
          </div>
          <h3 className="text-sm font-bold text-slate-200">Heuristic Peer Matcher</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Pairs students into study squads based on shared subjects, exam targets, and discrete time slot compatibility (Morning, Afternoon, Late Night).
          </p>
        </div>

        <div className="glass-panel p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
            04
          </div>
          <h3 className="text-sm font-bold text-slate-200">Squad Workspace & Focus Timer</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Synchronized 25-minute Pomodoro focus cycles, daily study streak badge tracker, and interactive session goal checklist.
          </p>
        </div>
      </div>
    </div>
  );
};
