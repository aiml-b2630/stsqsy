import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useSquad } from '../context/SquadContext';
import { validateRoomHold } from '../utils/validation';
import { MapPin, Volume2, ShieldAlert, CheckCircle2, Clock, Users } from 'lucide-react';

export const RoomCard = ({ room, onHoldRequested }) => {
  const { user } = useAuth();
  const { activeHold } = useSquad();
  const availableSeats = room.capacity - room.occupiedChairs;
  const isHeldByMe = activeHold && activeHold.roomId === room.id;

  const { canHold, reason } = validateRoomHold(room, user);

  // Status color styles
  const statusStyles = {
    Available: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
    Reserved: "bg-amber-500/10 text-amber-400 border-amber-500/30",
    Occupied: "bg-rose-500/10 text-rose-400 border-rose-500/30"
  };

  return (
    <div className="glass-panel p-5 flex flex-col justify-between hover:border-indigo-500/40 transition duration-300 group">
      <div>
        {/* Header & Status */}
        <div className="flex items-start justify-between gap-2 mb-3">
          <div>
            <h3 className="font-bold text-slate-100 group-hover:text-indigo-300 transition">{room.name}</h3>
            <p className="text-xs text-slate-400 flex items-center space-x-1 mt-0.5">
              <MapPin className="w-3 h-3 text-slate-500" />
              <span>{room.building} ({room.floor})</span>
            </p>
          </div>
          <span className={`px-2.5 py-1 text-xs font-semibold rounded-full border ${statusStyles[room.status]}`}>
            {room.status}
          </span>
        </div>

        {/* Capacity Progress Gauge */}
        <div className="my-4">
          <div className="flex items-center justify-between text-xs text-slate-300 mb-1.5">
            <span className="flex items-center space-x-1">
              <Users className="w-3.5 h-3.5 text-indigo-400" />
              <span>Occupancy Telemetry</span>
            </span>
            <span className="font-semibold">{room.occupiedChairs} / {room.capacity} Chairs</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${
                availableSeats === 0 ? "bg-rose-500" : availableSeats <= 2 ? "bg-amber-500" : "bg-emerald-500"
              }`}
              style={{ width: `${(room.occupiedChairs / room.capacity) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Noise Decibel Meter */}
        <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/40 mb-4">
          <div className="flex items-center space-x-2 text-xs">
            <Volume2 className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-300 font-medium">{room.noiseCategory}</span>
          </div>
          <span className="text-xs font-mono font-bold text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800">
            {room.noiseDb} dB
          </span>
        </div>

        {/* Amenities Badges */}
        <div className="flex flex-wrap gap-1.5 mb-5">
          {room.amenities.map(a => (
            <span key={a} className="px-2 py-0.5 bg-slate-800/80 border border-slate-700/60 text-slate-300 text-[11px] rounded-lg">
              {a}
            </span>
          ))}
        </div>
      </div>

      {/* Action Button */}
      <div>
        {isHeldByMe ? (
          <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold text-center flex items-center justify-center space-x-2">
            <Clock className="w-4 h-4 text-amber-400 animate-spin" />
            <span>Active Hold Placed</span>
          </div>
        ) : (
          <button
            onClick={() => onHoldRequested(room)}
            disabled={!canHold || Boolean(activeHold)}
            title={reason}
            className={`w-full py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-2 ${
              canHold && !activeHold
                ? "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/20"
                : "bg-slate-800 text-slate-500 border border-slate-700/50 cursor-not-allowed"
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>{activeHold ? "Hold Active Elsewhere" : canHold ? "Place 20-Min Hold" : reason}</span>
          </button>
        )}
      </div>
    </div>
  );
};
