import React from 'react';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("ErrorBoundary caught an exception:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-8 max-w-lg mx-auto my-12 bg-rose-950/40 border border-rose-500/50 rounded-2xl text-center backdrop-blur-md">
          <div className="w-12 h-12 bg-rose-500/20 text-rose-400 rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-xl">⚠️</div>
          <h2 className="text-xl font-bold text-rose-200 mb-2">Something went wrong in this module.</h2>
          <p className="text-sm text-rose-300/80 mb-6">{this.state.error?.toString()}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-semibold rounded-xl text-sm transition"
          >
            Reload Application
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
