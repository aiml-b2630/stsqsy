import React from 'react';
import { useSquad } from '../context/SquadContext';
import { useRoomFilter } from '../hooks/useRoomFilter';
import { RoomCard } from './RoomCard';
import { Search, Filter, SlidersHorizontal, ChevronLeft, ChevronRight, Volume2, Building } from 'lucide-react';

export const RoomVisualizer = ({ onSelectRoomForHold }) => {
  const { rooms } = useSquad();
  const filterState = useRoomFilter(rooms);

  const availableAmenities = ["Whiteboard", "Power Sockets", "Silent Zone", "Group Discussion Friendly", "Dual Monitors"];
  const buildings = ["All", "Central Library", "Engineering Block B", "Student Center", "Technology Wing", "Science Complex", "Humanities Hall"];

  return (
    <div className="space-y-6">
      {/* Title & Filter Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 glass-panel p-6">
        <div>
          <h2 className="text-xl font-extrabold text-slate-100 flex items-center space-x-2">
            <span>Campus Study Space Radar</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">Real-time availability, decibel telemetry, and temporary hold holds across 12 campus spaces.</p>
        </div>

        {/* Search Bar */}
        <div className="relative min-w-[260px]">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Search facility name or location..."
            value={filterState.searchTerm}
            onChange={(e) => filterState.setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Filter Controls Bar */}
      <div className="glass-panel p-5 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Building Filter */}
          <div>
            <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1 mb-1.5">
              <Building className="w-3.5 h-3.5 text-indigo-400" />
              <span>Campus Facility</span>
            </label>
            <select
              value={filterState.selectedBuilding}
              onChange={(e) => filterState.setSelectedBuilding(e.target.value)}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              {buildings.map(b => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1 mb-1.5">
              <Filter className="w-3.5 h-3.5 text-indigo-400" />
              <span>Occupancy Status</span>
            </label>
            <select
              value={filterState.statusFilter}
              onChange={(e) => filterState.setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              <option value="All">All Statuses</option>
              <option value="Available">Available</option>
              <option value="Reserved">Reserved (Hold)</option>
              <option value="Occupied">Occupied (Full)</option>
            </select>
          </div>

          {/* Sort By */}
          <div>
            <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1 mb-1.5">
              <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-400" />
              <span>Sort Grid By</span>
            </label>
            <select
              value={filterState.sortBy}
              onChange={(e) => filterState.setSortBy(e.target.value)}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              <option value="name">Room Name (A-Z)</option>
              <option value="noiseDb">Quietness (Lowest dB)</option>
              <option value="availableSeats">Available Seats (Highest)</option>
            </select>
          </div>

          {/* Max Noise dB Slider */}
          <div>
            <div className="flex justify-between items-center text-xs font-semibold text-slate-300 mb-1.5">
              <span className="flex items-center space-x-1">
                <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Max Noise Level</span>
              </span>
              <span className="text-cyan-400 font-mono">{filterState.maxNoiseDb} dB</span>
            </div>
            <input
              type="range"
              min="25"
              max="70"
              value={filterState.maxNoiseDb}
              onChange={(e) => filterState.setMaxNoiseDb(Number(e.target.value))}
              className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Amenity Filter Buttons */}
        <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-medium mr-2">Filter Amenities:</span>
          {availableAmenities.map(amenity => {
            const isSelected = filterState.selectedAmenities.includes(amenity);
            return (
              <button
                key={amenity}
                onClick={() => filterState.toggleAmenity(amenity)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                  isSelected
                    ? "bg-indigo-600 text-white border border-indigo-400"
                    : "bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700"
                }`}
              >
                {amenity}
              </button>
            );
          })}
        </div>
      </div>

      {/* Room Grid */}
      {filterState.paginatedRooms.length === 0 ? (
        <div className="glass-panel p-12 text-center text-slate-400">
          <p className="text-base font-semibold">No study rooms match your current filters.</p>
          <p className="text-xs text-slate-500 mt-1">Try relaxing your noise threshold or clearing amenity filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filterState.paginatedRooms.map(room => (
            <RoomCard key={room.id} room={room} onHoldRequested={onSelectRoomForHold} />
          ))}
        </div>
      )}

      {/* Pagination Controls addressing system design scalability */}
      {filterState.totalPages > 1 && (
        <div className="flex items-center justify-between glass-panel px-6 py-4">
          <span className="text-xs text-slate-400">
            Showing {filterState.paginatedRooms.length} of {filterState.totalCount} spaces (Page {filterState.currentPage} of {filterState.totalPages})
          </span>
          <div className="flex items-center space-x-2">
            <button
              disabled={filterState.currentPage === 1}
              onClick={() => filterState.setCurrentPage(p => p - 1)}
              className="p-2 rounded-xl bg-slate-800 disabled:opacity-40 text-slate-200 hover:bg-slate-700 transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              disabled={filterState.currentPage === filterState.totalPages}
              onClick={() => filterState.setCurrentPage(p => p + 1)}
              className="p-2 rounded-xl bg-slate-800 disabled:opacity-40 text-slate-200 hover:bg-slate-700 transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
