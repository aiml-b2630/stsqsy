import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import { useAuth } from '../context/AuthContext';
import { validateSquadForm } from '../utils/validation';
import { X, Users, BookOpen, Clock, AlertCircle } from 'lucide-react';

export const CreateSquadModal = ({ isOpen, onClose }) => {
  const { createSquad, rooms } = useSquad();
  const { user } = useAuth();

  const [formData, setFormData] = useState({
    title: "",
    subject: "Computer Science",
    topic: "",
    maxMembers: 4,
    scheduleSlot: "Afternoon",
    meetingTime: "14:00 - 16:00",
    assignedRoomId: rooms[0]?.id || "rm-101"
  });

  const [errors, setErrors] = useState({});

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    const result = validateSquadForm(formData);

    if (!result.isValid) {
      setErrors(result.errors);
      return;
    }

    const selectedRoomObj = rooms.find(r => r.id === formData.assignedRoomId);

    createSquad({
      ...result.cleanData,
      creator: user.name,
      creatorId: user.id,
      assignedRoomId: formData.assignedRoomId,
      assignedRoomName: selectedRoomObj ? selectedRoomObj.name : "Engineering Pod #3",
      assignedRoomAmenities: selectedRoomObj ? selectedRoomObj.amenities : []
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="glass-panel max-w-lg w-full p-6 relative shadow-2xl border-indigo-500/30">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white">
          <X className="w-5 h-5" />
        </button>

        <div className="mb-5">
          <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
            <Users className="w-5 h-5 text-indigo-400" />
            <span>Launch a New Study Squad</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">Form a focused group, set your target goals, and assign a campus room.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Squad Title */}
          <div>
            <label className="block font-semibold text-slate-300 mb-1">Squad Title *</label>
            <input
              type="text"
              placeholder="e.g. Operating Systems Final Review"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500"
            />
            {errors.title && <p className="text-rose-400 text-[11px] mt-1 flex items-center space-x-1"><AlertCircle className="w-3 h-3" /><span>{errors.title}</span></p>}
          </div>

          {/* Subject & Topic */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-300 mb-1">Subject *</label>
              <select
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="Computer Science">Computer Science</option>
                <option value="Mathematics">Mathematics</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Physics">Physics</option>
                <option value="Electrical Engineering">Electrical Engineering</option>
                <option value="Economics">Economics</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-300 mb-1">Target Group Size</label>
              <input
                type="number"
                min="2"
                max="12"
                value={formData.maxMembers}
                onChange={(e) => setFormData({ ...formData, maxMembers: e.target.value })}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500"
              />
              {errors.maxMembers && <p className="text-rose-400 text-[11px] mt-1">{errors.maxMembers}</p>}
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-300 mb-1">Target Topic / Goal *</label>
            <input
              type="text"
              placeholder="e.g. Process Sync & Semaphore Algorithms"
              value={formData.topic}
              onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500"
            />
            {errors.topic && <p className="text-rose-400 text-[11px] mt-1">{errors.topic}</p>}
          </div>

          {/* Schedule & Room */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-300 mb-1">Time Block</label>
              <select
                value={formData.scheduleSlot}
                onChange={(e) => setFormData({ ...formData, scheduleSlot: e.target.value })}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="Morning">Morning (08:00 - 12:00)</option>
                <option value="Afternoon">Afternoon (12:00 - 17:00)</option>
                <option value="Late Night">Late Night (17:00 - 23:00)</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-300 mb-1">Assign Room Space</label>
              <select
                value={formData.assignedRoomId}
                onChange={(e) => setFormData({ ...formData, assignedRoomId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                {rooms.map(r => (
                  <option key={r.id} value={r.id}>{r.name} ({r.building})</option>
                ))}
              </select>
            </div>
          </div>

          <div className="pt-3">
            <button
              type="submit"
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-indigo-600/30 transition"
            >
              Create Study Squad
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
