import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useSquad } from '../context/SquadContext';
import { Users, Clock, Flame, Sparkles, BookOpen, MapPin } from 'lucide-react';

export const SquadCard = ({ squad, onJoin, onViewWorkspace }) => {
  const { user } = useAuth();
  const { activeSquadId } = useSquad();
  const isMember = squad.members.some(m => m.id === user.id);
  const isFull = squad.members.length >= squad.maxMembers;
  const isActive = activeSquadId === squad.id;

  return (
    <div className={`glass-panel p-5 flex flex-col justify-between transition duration-300 hover:border-indigo-500/50 ${
      isActive ? "border-indigo-500 shadow-lg shadow-indigo-500/10" : ""
    }`}>
      <div>
        {/* Header */}
        <div className="flex items-start justify-between gap-2 mb-2">
          <div>
            <span className="px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-md">
              {squad.subject}
            </span>
            <h3 className="font-bold text-slate-100 text-base mt-2">{squad.title}</h3>
            <p className="text-xs text-slate-400 mt-1 flex items-center space-x-1">
              <BookOpen className="w-3 h-3 text-slate-500" />
              <span>{squad.topic}</span>
            </p>
          </div>

          {squad.matchPercentage !== undefined && (
            <div className="flex flex-col items-end">
              <span className="text-xs font-extrabold text-cyan-400 font-mono bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800">
                {squad.matchPercentage}% Match
              </span>
            </div>
          )}
        </div>

        {/* Schedule & Location */}
        <div className="grid grid-cols-2 gap-2 my-4 text-xs">
          <div className="p-2 rounded-lg bg-slate-800/60 border border-slate-700/40 flex items-center space-x-2">
            <Clock className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-slate-300">{squad.scheduleSlot} ({squad.meetingTime})</span>
          </div>
          <div className="p-2 rounded-lg bg-slate-800/60 border border-slate-700/40 flex items-center space-x-2">
            <MapPin className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-300 truncate">{squad.assignedRoomName}</span>
          </div>
        </div>

        {/* Members Roster & Streak */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 mb-5">
          <div className="flex items-center space-x-1">
            <div className="flex -space-x-2 overflow-hidden">
              {squad.members.map((m, idx) => (
                <span
                  key={m.id || idx}
                  className="inline-block w-7 h-7 rounded-full bg-slate-800 border-2 border-slate-900 flex items-center justify-center text-xs"
                  title={`${m.name} (${m.role})`}
                >
                  {m.avatar || "👨‍🎓"}
                </span>
              ))}
            </div>
            <span className="text-xs text-slate-400 ml-2 font-medium">
              {squad.members.length} / {squad.maxMembers} Members
            </span>
          </div>

          <div className="flex items-center space-x-1 text-xs font-bold text-amber-400 bg-amber-950/50 px-2.5 py-1 rounded-lg border border-amber-800/60">
            <Flame className="w-3.5 h-3.5 fill-amber-400" />
            <span>{squad.streakDays}d Streak</span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-2">
        {isMember ? (
          <button
            onClick={() => onViewWorkspace(squad.id)}
            className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition flex items-center justify-center space-x-1.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>Open Squad Workspace</span>
          </button>
        ) : (
          <button
            onClick={() => onJoin(squad.id)}
            disabled={isFull}
            className={`w-full py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1.5 ${
              isFull
                ? "bg-slate-800 text-slate-500 border border-slate-700/50 cursor-not-allowed"
                : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/20"
            }`}
          >
            <Users className="w-4 h-4" />
            <span>{isFull ? "Squad Full" : "Join Study Squad"}</span>
          </button>
        )}
      </div>
    </div>
  );
};
