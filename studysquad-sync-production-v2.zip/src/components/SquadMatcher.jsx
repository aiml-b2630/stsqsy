import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import { useAuth } from '../context/AuthContext';
import { useSquadMatcher } from '../hooks/useSquadMatcher';
import { SquadCard } from './SquadCard';
import { CreateSquadModal } from './CreateSquadModal';
import { Users, Search, Plus, Filter, Calendar, BookOpen } from 'lucide-react';

export const SquadMatcher = ({ onViewWorkspace }) => {
  const { squads, joinSquad } = useSquad();
  const { user } = useAuth();
  const matcher = useSquadMatcher(squads);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const subjects = ["All Subjects", "Computer Science", "Mathematics", "Chemistry", "Physics", "Electrical Engineering", "Economics"];

  return (
    <div className="space-y-6">
      {/* Header & Create Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 glass-panel p-6">
        <div>
          <h2 className="text-xl font-extrabold text-slate-100 flex items-center space-x-2">
            <span>Peer Study Squad Matcher</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">Connect with compatible peers based on subject, target goals, and schedule blocks.</p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-indigo-600/30 transition flex items-center space-x-2 self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Launch New Squad</span>
        </button>
      </div>

      {/* Match Filters */}
      <div className="glass-panel p-5 grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Subject Filter */}
        <div>
          <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1 mb-1.5">
            <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
            <span>Target Subject</span>
          </label>
          <select
            value={matcher.filterSubject}
            onChange={(e) => matcher.setFilterSubject(e.target.value === "All Subjects" ? "" : e.target.value)}
            className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
          >
            {subjects.map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>

        {/* Schedule Block */}
        <div>
          <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1 mb-1.5">
            <Calendar className="w-3.5 h-3.5 text-indigo-400" />
            <span>Study Time Block</span>
          </label>
          <select
            value={matcher.filterScheduleSlot}
            onChange={(e) => matcher.setFilterScheduleSlot(e.target.value)}
            className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
          >
            <option value="All">All Schedule Blocks</option>
            <option value="Morning">Morning (08:00 - 12:00)</option>
            <option value="Afternoon">Afternoon (12:00 - 17:00)</option>
            <option value="Late Night">Late Night (17:00 - 23:00)</option>
          </select>
        </div>

        {/* Preferred Amenity */}
        <div>
          <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1 mb-1.5">
            <Filter className="w-3.5 h-3.5 text-cyan-400" />
            <span>Preferred Facility Amenity</span>
          </label>
          <select
            value={matcher.filterAmenity}
            onChange={(e) => matcher.setFilterAmenity(e.target.value)}
            className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
          >
            <option value="">Any Amenity</option>
            <option value="Whiteboard">Whiteboard Required</option>
            <option value="Dual Monitors">Dual Monitors</option>
            <option value="Silent Zone">Silent Zone</option>
            <option value="Group Discussion Friendly">Group Discussion Friendly</option>
          </select>
        </div>
      </div>

      {/* Squad Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {matcher.matchedSquads.map(squad => (
          <SquadCard
            key={squad.id}
            squad={squad}
            onJoin={(sqId) => joinSquad(sqId, user)}
            onViewWorkspace={onViewWorkspace}
          />
        ))}
      </div>

      {/* Create Squad Form Modal */}
      <CreateSquadModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
      />
    </div>
  );
};
