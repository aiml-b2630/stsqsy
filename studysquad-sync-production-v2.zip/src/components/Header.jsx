import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useSquad } from '../context/SquadContext';
import { MapPin, Users, BookOpen, Clock, Activity, Sun, Moon, Shield, Sparkles } from 'lucide-react';

export const Header = ({ activeTab, setActiveTab, onOpenHoldModal }) => {
  const { user, theme, toggleTheme, toggleRole } = useAuth();
  const { activeHold, iotSimEnabled, setIotSimEnabled } = useSquad();

  return (
    <header className="sticky top-0 z-40 bg-slate-900/80 backdrop-blur-xl border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab("rooms")}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-indigo-500/25">
              <MapPin className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-lg text-slate-100 tracking-tight">StudySquad <span className="text-cyan-400">Sync</span></span>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full">v2.0</span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">Smart Campus Space & Peer Matching Engine</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1 bg-slate-800/60 p-1.5 rounded-xl border border-slate-700/50">
            <button
              onClick={() => setActiveTab("rooms")}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === "rooms" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <MapPin className="w-3.5 h-3.5" />
              <span>RoomRadar</span>
            </button>
            <button
              onClick={() => setActiveTab("squads")}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === "squads" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Study Squads</span>
            </button>
            <button
              onClick={() => setActiveTab("workspace")}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === "workspace" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Squad Workspace</span>
            </button>
            <button
              onClick={() => setActiveTab("how-it-works")}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === "how-it-works" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>How It Works</span>
            </button>
          </nav>

          {/* Controls & Badges */}
          <div className="flex items-center space-x-3">
            {/* Active Hold Pill Badge */}
            {activeHold && (
              <button
                onClick={onOpenHoldModal}
                className="flex items-center space-x-2 px-3 py-1.5 bg-amber-500/20 border border-amber-500/40 text-amber-300 rounded-xl text-xs font-semibold animate-pulse"
              >
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>Active 20m Hold</span>
              </button>
            )}

            {/* IoT Sensor Sim Toggle */}
            <button
              onClick={() => setIotSimEnabled(!iotSimEnabled)}
              title="Toggle Live IoT Sensor Event Loop Simulation"
              className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-medium transition ${
                iotSimEnabled
                  ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                  : "bg-slate-800 border-slate-700 text-slate-400"
              }`}
            >
              <Activity className={`w-3.5 h-3.5 ${iotSimEnabled ? "animate-pulse" : ""}`} />
              <span className="hidden lg:inline">{iotSimEnabled ? "IoT Active" : "IoT Off"}</span>
            </button>

            {/* Role Switcher */}
            <button
              onClick={toggleRole}
              title="Switch user role for evaluation simulation"
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-xs text-slate-300 flex items-center space-x-1 transition"
            >
              <Shield className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">{user.role}</span>
            </button>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 text-slate-400 hover:text-white bg-slate-800 border border-slate-700 rounded-xl transition"
            >
              {theme === "dark" ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-400" />}
            </button>

            {/* User Avatar */}
            <div className="flex items-center space-x-2 pl-2 border-l border-slate-800">
              <span className="text-xl" title={user.name}>{user.avatar}</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
