import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Flame, Bell, Coffee } from 'lucide-react';

export const PomodoroTimer = ({ onSessionComplete }) => {
  const WORK_TIME = 25 * 60; // 25 minutes
  const BREAK_TIME = 5 * 60;  // 5 minutes

  const [timeLeft, setTimeLeft] = useState(WORK_TIME);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState("work"); // work or break
  const [completedSessions, setCompletedSessions] = useState(0);

  useEffect(() => {
    let interval = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(t => t - 1);
      }, 1000);
    } else if (isRunning && timeLeft === 0) {
      if (mode === "work") {
        setCompletedSessions(c => c + 1);
        setMode("break");
        setTimeLeft(BREAK_TIME);
        if (onSessionComplete) onSessionComplete();
      } else {
        setMode("work");
        setTimeLeft(WORK_TIME);
      }
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft, mode, onSessionComplete]);

  const toggleTimer = () => setIsRunning(!isRunning);

  const resetTimer = () => {
    setIsRunning(false);
    setMode("work");
    setTimeLeft(WORK_TIME);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formatted = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  const totalDuration = mode === "work" ? WORK_TIME : BREAK_TIME;
  const progressPercent = ((totalDuration - timeLeft) / totalDuration) * 100;

  return (
    <div className="glass-panel p-6 text-center border-indigo-500/30">
      <div className="flex items-center justify-between mb-4">
        <span className={`px-2.5 py-1 text-xs font-bold rounded-full border ${
          mode === "work" ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/40" : "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
        }`}>
          {mode === "work" ? "🧠 Focus Block (25m)" : "☕ Break Time (5m)"}
        </span>

        <div className="flex items-center space-x-1 text-xs text-amber-400 font-bold bg-amber-950/40 px-2.5 py-1 rounded-lg border border-amber-800">
          <Flame className="w-3.5 h-3.5 fill-amber-400" />
          <span>{completedSessions} Sessions Done</span>
        </div>
      </div>

      {/* Clock Display */}
      <div className="py-6">
        <div className="text-5xl font-extrabold font-mono tracking-widest text-slate-100">
          {formatted}
        </div>
        
        {/* Progress gauge */}
        <div className="w-48 mx-auto bg-slate-800 h-2 rounded-full mt-4 overflow-hidden">
          <div
            className={`h-full transition-all duration-1000 ${mode === "work" ? "bg-indigo-500" : "bg-emerald-400"}`}
            style={{ width: `${progressPercent}%` }}
          ></div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex justify-center space-x-3 pt-2">
        <button
          onClick={toggleTimer}
          className={`px-5 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-2 shadow-lg transition ${
            isRunning
              ? "bg-amber-600 hover:bg-amber-500 text-white shadow-amber-600/20"
              : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20"
          }`}
        >
          {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          <span>{isRunning ? "Pause Timer" : "Start Focus Cycle"}</span>
        </button>

        <button
          onClick={resetTimer}
          className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
