import React, { useState } from 'react';
import { useSquad } from '../context/SquadContext';
import { useAuth } from '../context/AuthContext';
import { PomodoroTimer } from './PomodoroTimer';
import { IoTSensorPanel } from './IoTSensorPanel';
import { Users, CheckSquare, Plus, Flame, MapPin, Clock, Shield, Sparkles } from 'lucide-react';

export const SquadWorkspace = () => {
  const { squads, activeSquadId, toggleSquadGoal, addSquadGoal, incrementSquadStreak } = useSquad();
  const { user } = useAuth();
  const [newGoalText, setNewGoalText] = useState("");

  const activeSquad = squads.find(s => s.id === activeSquadId) || squads[0];

  if (!activeSquad) {
    return (
      <div className="glass-panel p-12 text-center text-slate-400">
        <p className="text-base font-semibold">No active Study Squad selected.</p>
        <p className="text-xs text-slate-500 mt-1">Join or create a squad from the Study Squads tab.</p>
      </div>
    );
  }

  const handleAddGoal = (e) => {
    e.preventDefault();
    if (!newGoalText.trim()) return;
    addSquadGoal(activeSquad.id, newGoalText);
    setNewGoalText("");
  };

  return (
    <div className="space-y-6">
      {/* Workspace Header */}
      <div className="glass-panel p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 mb-2">
              <span className="px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-md">
                {activeSquad.subject}
              </span>
              <span className="text-xs text-slate-400 flex items-center space-x-1">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                <span>{activeSquad.assignedRoomName}</span>
              </span>
            </div>
            <h1 className="text-2xl font-extrabold text-slate-100">{activeSquad.title}</h1>
            <p className="text-xs text-slate-400 mt-1">Goal Topic: {activeSquad.topic}</p>
          </div>

          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2 px-3 py-2 bg-amber-950/60 border border-amber-800 rounded-xl text-amber-300 text-xs font-bold">
              <Flame className="w-4 h-4 fill-amber-400" />
              <span>{activeSquad.streakDays}-Day Study Streak</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Pomodoro & IoT Live Telemetry */}
        <div className="space-y-6">
          <PomodoroTimer onSessionComplete={() => incrementSquadStreak(activeSquad.id)} />
          <IoTSensorPanel />
        </div>

        {/* Right Column (2 cols): Member Roster & Goals */}
        <div className="lg:col-span-2 space-y-6">
          {/* Member Roster Card */}
          <div className="glass-panel p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-slate-100 text-sm flex items-center space-x-2">
                <Users className="w-4 h-4 text-indigo-400" />
                <span>Squad Member Roster ({activeSquad.members.length} / {activeSquad.maxMembers})</span>
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {activeSquad.members.map(member => (
                <div key={member.id} className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/50 flex items-center space-x-3">
                  <span className="text-2xl">{member.avatar || "👨‍🎓"}</span>
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">{member.name}</h4>
                    <span className="text-[10px] text-slate-400 flex items-center space-x-1">
                      <Shield className="w-3 h-3 text-indigo-400" />
                      <span>{member.role}</span>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Session Goals & Agenda */}
          <div className="glass-panel p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-slate-100 text-sm flex items-center space-x-2">
                <CheckSquare className="w-4 h-4 text-cyan-400" />
                <span>Target Study Goals for Today's Session</span>
              </h3>
            </div>

            {/* Goals List */}
            <div className="space-y-2">
              {activeSquad.goals.map(goal => (
                <div
                  key={goal.id}
                  onClick={() => toggleSquadGoal(activeSquad.id, goal.id)}
                  className={`p-3 rounded-xl border text-xs flex items-center space-x-3 cursor-pointer transition ${
                    goal.completed
                      ? "bg-emerald-950/20 border-emerald-500/30 text-emerald-300 line-through opacity-80"
                      : "bg-slate-800/80 border-slate-700/60 text-slate-200 hover:border-indigo-500/50"
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={goal.completed}
                    onChange={() => {}}
                    className="accent-indigo-500 rounded cursor-pointer"
                  />
                  <span className="flex-1 font-medium">{goal.text}</span>
                </div>
              ))}
            </div>

            {/* Add Goal Form */}
            <form onSubmit={handleAddGoal} className="flex space-x-2 pt-2">
              <input
                type="text"
                placeholder="Add new squad study goal..."
                value={newGoalText}
                onChange={(e) => setNewGoalText(e.target.value)}
                className="flex-1 px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs transition flex items-center space-x-1"
              >
                <Plus className="w-4 h-4" />
                <span>Add Goal</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
