import { describe, it, expect } from 'vitest';
import { calculateMatchScore, findBestMatchingSquads } from '../utils/matchingEngine';

describe('Heuristic Peer Matcher Engine', () => {
  const sampleSquads = [
    {
      id: 's1',
      subject: 'Computer Science',
      scheduleSlot: 'Afternoon',
      assignedRoomAmenities: ['Whiteboard'],
      members: ['m1'],
      maxMembers: 4
    },
    {
      id: 's2',
      subject: 'Mathematics',
      scheduleSlot: 'Morning',
      assignedRoomAmenities: ['Silent Zone'],
      members: ['m1', 'm2'],
      maxMembers: 4
    }
  ];

  it('scores high compatibility when subject and schedule match', () => {
    const score = calculateMatchScore(sampleSquads[0], {
      subject: 'Computer Science',
      scheduleSlot: 'Afternoon',
      preferredAmenity: 'Whiteboard'
    });
    expect(score).toBeGreaterThanOrEqual(90);
  });

  it('ranks best matching squads first', () => {
    const ranked = findBestMatchingSquads(sampleSquads, {
      subject: 'Computer Science',
      scheduleSlot: 'Afternoon'
    });
    expect(ranked[0].id).toBe('s1');
  });
});
