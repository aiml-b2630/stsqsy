import { describe, it, expect } from 'vitest';
import { validateSquadForm, validateRoomHold, sanitizeString } from '../utils/validation';

describe('Validation Utility Suite', () => {
  it('sanitizes input against script injection tags', () => {
    const raw = "<script>alert('xss')</script>";
    const clean = sanitizeString(raw);
    expect(clean).not.toContain('<script>');
    expect(clean).toContain('&lt;script&gt;');
  });

  it('validates squad creation form correctly', () => {
    const invalidForm = { title: "CS", subject: "", topic: "", maxMembers: 1, scheduleSlot: "Invalid" };
    const res = validateSquadForm(invalidForm);
    expect(res.isValid).toBe(false);
    expect(res.errors.title).toBeDefined();
    expect(res.errors.subject).toBeDefined();

    const validForm = { title: "Operating Systems Finals", subject: "Computer Science", topic: "Process Sync", maxMembers: 4, scheduleSlot: "Afternoon" };
    const validRes = validateSquadForm(validForm);
    expect(validRes.isValid).toBe(true);
  });

  it('enforces room hold rules', () => {
    const roomOccupied = { status: "Occupied" };
    const check = validateRoomHold(roomOccupied, { id: "u1" });
    expect(check.canHold).toBe(false);
    expect(check.reason).toContain("occupied");
  });
});
