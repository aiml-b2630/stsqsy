import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { SquadProvider, useSquad } from './context/SquadContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Header } from './components/Header';
import { RoomVisualizer } from './components/RoomVisualizer';
import { SquadMatcher } from './components/SquadMatcher';
import { SquadWorkspace } from './components/SquadWorkspace';
import { HowItWorks } from './components/HowItWorks';
import { HoldTimerModal } from './components/HoldTimerModal';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

const MainContent = () => {
  const [activeTab, setActiveTab] = useState("rooms");
  const [isHoldModalOpen, setIsHoldModalOpen] = useState(false);
  const [selectedRoomForHold, setSelectedRoomForHold] = useState(null);
  const { notification, setActiveSquadId } = useSquad();

  const handleSelectRoomForHold = (room) => {
    setSelectedRoomForHold(room);
    setIsHoldModalOpen(true);
  };

  const handleViewWorkspace = (squadId) => {
    if (squadId) setActiveSquadId(squadId);
    setActiveTab("workspace");
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-900 text-slate-100">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenHoldModal={() => setIsHoldModalOpen(true)}
      />

      {/* Global Toast Notification */}
      {notification && (
        <div className="fixed top-20 right-6 z-50 animate-bounce">
          <div className={`px-4 py-3 rounded-xl shadow-2xl border text-xs font-bold flex items-center space-x-2 backdrop-blur-md ${
            notification.type === "error"
              ? "bg-rose-950/80 border-rose-500/50 text-rose-200"
              : notification.type === "success"
              ? "bg-emerald-950/80 border-emerald-500/50 text-emerald-200"
              : "bg-indigo-950/80 border-indigo-500/50 text-indigo-200"
          }`}>
            {notification.type === "error" ? <AlertCircle className="w-4 h-4 text-rose-400" /> : <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
            <span>{notification.msg}</span>
          </div>
        </div>
      )}

      {/* Main Body View */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <ErrorBoundary>
          {activeTab === "rooms" && (
            <RoomVisualizer onSelectRoomForHold={handleSelectRoomForHold} />
          )}

          {activeTab === "squads" && (
            <SquadMatcher onViewWorkspace={handleViewWorkspace} />
          )}

          {activeTab === "workspace" && (
            <SquadWorkspace />
          )}

          {activeTab === "how-it-works" && (
            <HowItWorks />
          )}
        </ErrorBoundary>
      </main>

      {/* Hold Timer Modal */}
      <HoldTimerModal
        isOpen={isHoldModalOpen}
        onClose={() => setIsHoldModalOpen(false)}
        selectedRoom={selectedRoomForHold}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800 py-6 text-center text-xs text-slate-500">
        <p>StudySquad Sync v2.0 — Production Release Candidate Addressing SRS & Project Rubric Criteria</p>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <SquadProvider>
        <MainContent />
      </SquadProvider>
    </AuthProvider>
  );
}
