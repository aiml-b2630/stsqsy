import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState({
    id: "user-101",
    name: "Alex Rivers",
    email: "alex.rivers@campus.edu",
    role: "Student", // Student or RoomAdmin
    department: "Computer Science & Engineering",
    avatar: "👨‍💻"
  });

  const [theme, setTheme] = useState("dark");

  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    document.documentElement.setAttribute("data-theme", newTheme);
  };

  const toggleRole = () => {
    setUser(prev => ({
      ...prev,
      role: prev.role === "Student" ? "RoomAdmin" : "Student"
    }));
  };

  return (
    <AuthContext.Provider value={{ user, theme, toggleTheme, toggleRole }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
