import React, { createContext, useContext, useState, useEffect } from 'react';
import { INITIAL_ROOMS, INITIAL_SQUADS } from '../utils/mockData';
import { loadRoomsFromStorage, saveRoomsToStorage, loadSquadsFromStorage, saveSquadsToStorage, loadActiveHold, saveActiveHold } from '../utils/storage';

const SquadContext = createContext();

export const SquadProvider = ({ children }) => {
  const [rooms, setRooms] = useState(() => loadRoomsFromStorage(INITIAL_ROOMS));
  const [squads, setSquads] = useState(() => loadSquadsFromStorage(INITIAL_SQUADS));
  const [activeHold, setActiveHold] = useState(() => loadActiveHold());
  const [activeSquadId, setActiveSquadId] = useState("sq-201");
  const [iotSimEnabled, setIotSimEnabled] = useState(true);
  const [notification, setNotification] = useState(null);

  // Sync rooms & squads to storage
  useEffect(() => {
    saveRoomsToStorage(rooms);
  }, [rooms]);

  useEffect(() => {
    saveSquadsToStorage(squads);
  }, [squads]);

  useEffect(() => {
    saveActiveHold(activeHold);
  }, [activeHold]);

  const showNotification = (msg, type = "info") => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 4000);
  };

  // Action: Place 20-min hold on a room
  const placeHold = (roomId, userId) => {
    const targetRoom = rooms.find(r => r.id === roomId);
    if (!targetRoom) return false;
    if (targetRoom.status === "Occupied") {
      showNotification("Cannot hold a fully occupied room.", "error");
      return false;
    }

    const expiresAt = Date.now() + 20 * 60 * 1000; // 20 minutes from now
    const holdObj = {
      roomId,
      roomName: targetRoom.name,
      userId,
      expiresAt
    };

    const updatedRooms = rooms.map(r => {
      if (r.id === roomId) {
        return {
          ...r,
          status: "Reserved",
          holdExpiresAt: expiresAt,
          reservedBy: userId
        };
      }
      return r;
    });

    setRooms(updatedRooms);
    setActiveHold(holdObj);
    showNotification(`20-Minute Hold placed on ${targetRoom.name}!`, "success");
    return true;
  };

  // Action: Release / Cancel Hold
  const cancelHold = (roomId) => {
    const updatedRooms = rooms.map(r => {
      if (r.id === roomId || (activeHold && r.id === activeHold.roomId)) {
        return {
          ...r,
          status: "Available",
          holdExpiresAt: null,
          reservedBy: null
        };
      }
      return r;
    });
    setRooms(updatedRooms);
    setActiveHold(null);
    showNotification("Room hold released back to public campus availability.", "info");
  };

  // Action: Confirm arrival at room
  const confirmArrival = (roomId) => {
    const updatedRooms = rooms.map(r => {
      if (r.id === roomId) {
        return {
          ...r,
          status: "Occupied",
          occupiedChairs: Math.min(r.capacity, r.occupiedChairs + 1),
          holdExpiresAt: null,
          reservedBy: null
        };
      }
      return r;
    });
    setRooms(updatedRooms);
    setActiveHold(null);
    showNotification("Arrival confirmed! Room status updated to Occupied.", "success");
  };

  // Action: Create Squad
  const createSquad = (squadData) => {
    const newSquad = {
      id: `sq-${Date.now()}`,
      ...squadData,
      members: [
        { id: squadData.creatorId, name: squadData.creator, role: "Leader", avatar: "👨‍💻" }
      ],
      streakDays: 1,
      goals: [
        { id: `g-${Date.now()}-1`, text: "Review core lecture concepts", completed: false },
        { id: `g-${Date.now()}-2`, text: "Complete 1 Pomodoro session", completed: false }
      ]
    };
    setSquads(prev => [newSquad, ...prev]);
    setActiveSquadId(newSquad.id);
    showNotification(`New Study Squad "${newSquad.title}" created successfully!`, "success");
  };

  // Action: Join Squad
  const joinSquad = (squadId, user) => {
    const squad = squads.find(s => s.id === squadId);
    if (!squad) return;
    if (squad.members.length >= squad.maxMembers) {
      showNotification("Squad is already full.", "error");
      return;
    }
    if (squad.members.some(m => m.id === user.id)) {
      showNotification("You are already a member of this squad.", "info");
      return;
    }

    const updatedSquads = squads.map(s => {
      if (s.id === squadId) {
        return {
          ...s,
          members: [...s.members, { id: user.id, name: user.name, role: "Member", avatar: user.avatar || "👨‍🎓" }]
        };
      }
      return s;
    });
    setSquads(updatedSquads);
    setActiveSquadId(squadId);
    showNotification(`Joined "${squad.title}" squad!`, "success");
  };

  // Action: Toggle Squad Goal
  const toggleSquadGoal = (squadId, goalId) => {
    setSquads(prev => prev.map(s => {
      if (s.id === squadId) {
        return {
          ...s,
          goals: s.goals.map(g => g.id === goalId ? { ...g, completed: !g.completed } : g)
        };
      }
      return s;
    }));
  };

  // Action: Add Squad Goal
  const addSquadGoal = (squadId, goalText) => {
    if (!goalText.trim()) return;
    setSquads(prev => prev.map(s => {
      if (s.id === squadId) {
        return {
          ...s,
          goals: [...s.goals, { id: `g-${Date.now()}`, text: goalText, completed: false }]
        };
      }
      return s;
    }));
  };

  // Action: Increment Streak
  const incrementSquadStreak = (squadId) => {
    setSquads(prev => prev.map(s => {
      if (s.id === squadId) {
        return { ...s, streakDays: s.streakDays + 1 };
      }
      return s;
    }));
    showNotification("Study Streak increased! 🔥 Keep up the focus!", "success");
  };

  return (
    <SquadContext.Provider value={{
      rooms,
      setRooms,
      squads,
      activeHold,
      activeSquadId,
      setActiveSquadId,
      iotSimEnabled,
      setIotSimEnabled,
      notification,
      placeHold,
      cancelHold,
      confirmArrival,
      createSquad,
      joinSquad,
      toggleSquadGoal,
      addSquadGoal,
      incrementSquadStreak,
      showNotification
    }}>
      {children}
    </SquadContext.Provider>
  );
};

export const useSquad = () => useContext(SquadContext);
